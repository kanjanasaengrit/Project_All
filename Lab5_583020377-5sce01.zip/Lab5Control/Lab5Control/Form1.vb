﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MyDateTimePicker.Format = DateTimePickerFormat.Custom
        MyDateTimePicker.CustomFormat = "dd/MM/yyyy"

        NumericUpDown_Day.Minimum = 1
        NumericUpDown_Day.Maximum = 31

        Dim localDate = DateTime.Now.Year
        For i = -10 To 10
            With ComboBox_year
                .Items.Add(CStr(localDate + 543 + i))
            End With
        Next

        With ComboBox_month
            .Items.Insert(0, ("มกราคม"))
            .Items.Insert(1, ("กุมภาพันธ์"))
            .Items.Insert(2, ("มีนาคม"))
            .Items.Insert(3, ("เมษายน"))
            .Items.Insert(4, ("พฤษภาคม"))
            .Items.Insert(5, ("มิถุนายน"))
            .Items.Insert(6, ("กรกฎาคม"))
            .Items.Insert(7, ("สิงหาคม"))
            .Items.Insert(8, ("กันยายน"))
            .Items.Insert(9, ("ตุลาคม"))
            .Items.Insert(10, ("พฤศจิกายน"))
            .Items.Insert(11, ("ธันวาคม"))
        End With

        DataGridView_data.ColumnCount = 3

        DataGridView_data.Columns(0).Width = 30
        DataGridView_data.Columns(1).Width = 110
        DataGridView_data.Columns(2).Width = 200

        DataGridView_data.Columns(0).Name = "No."
        DataGridView_data.Columns(1).Name = "Date"
        DataGridView_data.Columns(2).Name = "File Path"
    End Sub

    Private Sub MyDateTimePicker_ValueChanged(sender As Object, e As EventArgs) Handles MyDateTimePicker.ValueChanged
        NumericUpDown_Day.Value = MyDateTimePicker.Value.Day
        ComboBox_month.SelectedIndex() = MyDateTimePicker.Value.Month - 1
        ComboBox_year.Text = CStr(CDbl(MyDateTimePicker.Value.Year) + 543)

    End Sub

    Private Sub Btn_OpenFile_Click(sender As Object, e As EventArgs) Handles Btn_OpenFile.Click
        Dim img As String = ""
        OpenImageDialog.Filter = "Picture |*.bmp;*.jpg;*.gif| All Files|*.*"
        OpenImageDialog.FileName = ""

        If OpenImageDialog.ShowDialog(Me) = DialogResult.OK Then
            img = OpenImageDialog.FileName
            MyPictureBox.SizeMode = PictureBoxSizeMode.StretchImage
            MyPictureBox.Image = System.Drawing.Bitmap.FromFile(img)
        End If

        Lb_filePath.Text = "File Path : " + img
    End Sub

    Private Sub Btn_AddData_Click(sender As Object, e As EventArgs) Handles Btn_AddData.Click
        Dim num As Integer
        Dim dateT As String

        num = DataGridView_data.RowCount
        dateT = NumericUpDown_Day.Value.ToString + " " + ComboBox_month.Text + " " + ComboBox_year.Text

        Dim row As String() = New String() {num, dateT, Lb_filePath.Text}
        DataGridView_data.Rows.Add(row)
    End Sub
End Class
