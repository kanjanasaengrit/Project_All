﻿Public Class StudentData

    Private Sub StudentData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DateTimePicker_Birthday.Format = DateTimePickerFormat.Custom
        DateTimePicker_Birthday.CustomFormat = "dd/MM/yyyy"

        NumericUpDown_year.Minimum = 1
        NumericUpDown_year.Maximum = 4

        DataGridView_show.ColumnCount = 6

        With ComboBox_major
            .Items.Insert(0, ("Computer Science"))
            .Items.Insert(1, ("Information Technology"))
            .Items.Insert(2, ("Geographic Information System"))
        End With

        DataGridView_show.Columns(0).Width = 30
        DataGridView_show.Columns(1).Width = 100
        DataGridView_show.Columns(2).Width = 100
        DataGridView_show.Columns(3).Width = 100
        DataGridView_show.Columns(4).Width = 50
        DataGridView_show.Columns(5).Width = 50

        DataGridView_show.Columns(0).Name = "No."
        DataGridView_show.Columns(1).Name = "FirstName"
        DataGridView_show.Columns(2).Name = "LastName"
        DataGridView_show.Columns(3).Name = "Major"
        DataGridView_show.Columns(4).Name = "Year"
        DataGridView_show.Columns(5).Name = "Birthday"
    End Sub

    Private Sub Btn_add_Click(sender As Object, e As EventArgs) Handles Btn_add.Click
        Dim num As Integer

        num = DataGridView_show.RowCount
        Dim row As String() = New String() {num, Txt_fname.Text, Txt_lname.Text, ComboBox_major.SelectedItem, CStr(NumericUpDown_year.Value.ToString), DateTimePicker_Birthday.Value}
        DataGridView_show.Rows.Add(row)
    End Sub
End Class