﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MyDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ComboBox_month = New System.Windows.Forms.ComboBox()
        Me.ComboBox_year = New System.Windows.Forms.ComboBox()
        Me.Btn_OpenFile = New System.Windows.Forms.Button()
        Me.Btn_AddData = New System.Windows.Forms.Button()
        Me.NumericUpDown_Day = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Lb_filePath = New System.Windows.Forms.Label()
        Me.MyPictureBox = New System.Windows.Forms.PictureBox()
        Me.DataGridView_data = New System.Windows.Forms.DataGridView()
        Me.OpenImageDialog = New System.Windows.Forms.OpenFileDialog()
        CType(Me.NumericUpDown_Day, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MyPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView_data, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(480, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Year"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(367, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Month"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(287, 33)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(26, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Day"
        '
        'MyDateTimePicker
        '
        Me.MyDateTimePicker.Location = New System.Drawing.Point(41, 49)
        Me.MyDateTimePicker.Name = "MyDateTimePicker"
        Me.MyDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MyDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.MyDateTimePicker.TabIndex = 4
        '
        'ComboBox_month
        '
        Me.ComboBox_month.FormattingEnabled = True
        Me.ComboBox_month.Location = New System.Drawing.Point(370, 48)
        Me.ComboBox_month.Name = "ComboBox_month"
        Me.ComboBox_month.Size = New System.Drawing.Size(88, 21)
        Me.ComboBox_month.TabIndex = 6
        '
        'ComboBox_year
        '
        Me.ComboBox_year.FormattingEnabled = True
        Me.ComboBox_year.Location = New System.Drawing.Point(483, 48)
        Me.ComboBox_year.Name = "ComboBox_year"
        Me.ComboBox_year.Size = New System.Drawing.Size(86, 21)
        Me.ComboBox_year.TabIndex = 7
        '
        'Btn_OpenFile
        '
        Me.Btn_OpenFile.Location = New System.Drawing.Point(41, 90)
        Me.Btn_OpenFile.Name = "Btn_OpenFile"
        Me.Btn_OpenFile.Size = New System.Drawing.Size(127, 23)
        Me.Btn_OpenFile.TabIndex = 8
        Me.Btn_OpenFile.Text = "Browse Image"
        Me.Btn_OpenFile.UseVisualStyleBackColor = True
        '
        'Btn_AddData
        '
        Me.Btn_AddData.Location = New System.Drawing.Point(287, 90)
        Me.Btn_AddData.Name = "Btn_AddData"
        Me.Btn_AddData.Size = New System.Drawing.Size(99, 23)
        Me.Btn_AddData.TabIndex = 9
        Me.Btn_AddData.Text = "Add Data"
        Me.Btn_AddData.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Day
        '
        Me.NumericUpDown_Day.Location = New System.Drawing.Point(290, 49)
        Me.NumericUpDown_Day.Name = "NumericUpDown_Day"
        Me.NumericUpDown_Day.Size = New System.Drawing.Size(50, 20)
        Me.NumericUpDown_Day.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(38, 127)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Picture"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(284, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Show Data"
        '
        'Lb_filePath
        '
        Me.Lb_filePath.AutoSize = True
        Me.Lb_filePath.Location = New System.Drawing.Point(38, 302)
        Me.Lb_filePath.Name = "Lb_filePath"
        Me.Lb_filePath.Size = New System.Drawing.Size(57, 13)
        Me.Lb_filePath.TabIndex = 13
        Me.Lb_filePath.Text = "File Path : "
        '
        'MyPictureBox
        '
        Me.MyPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.MyPictureBox.Location = New System.Drawing.Point(41, 144)
        Me.MyPictureBox.Name = "MyPictureBox"
        Me.MyPictureBox.Size = New System.Drawing.Size(200, 149)
        Me.MyPictureBox.TabIndex = 14
        Me.MyPictureBox.TabStop = False
        '
        'DataGridView_data
        '
        Me.DataGridView_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_data.Location = New System.Drawing.Point(287, 143)
        Me.DataGridView_data.Name = "DataGridView_data"
        Me.DataGridView_data.Size = New System.Drawing.Size(443, 150)
        Me.DataGridView_data.TabIndex = 15
        '
        'OpenImageDialog
        '
        Me.OpenImageDialog.FileName = "OpenImageDialog"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 351)
        Me.Controls.Add(Me.DataGridView_data)
        Me.Controls.Add(Me.MyPictureBox)
        Me.Controls.Add(Me.Lb_filePath)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.NumericUpDown_Day)
        Me.Controls.Add(Me.Btn_AddData)
        Me.Controls.Add(Me.Btn_OpenFile)
        Me.Controls.Add(Me.ComboBox_year)
        Me.Controls.Add(Me.ComboBox_month)
        Me.Controls.Add(Me.MyDateTimePicker)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.NumericUpDown_Day, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MyPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView_data, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MyDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ComboBox_month As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_year As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_OpenFile As System.Windows.Forms.Button
    Friend WithEvents Btn_AddData As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_Day As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Lb_filePath As System.Windows.Forms.Label
    Friend WithEvents MyPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents DataGridView_data As System.Windows.Forms.DataGridView
    Friend WithEvents OpenImageDialog As System.Windows.Forms.OpenFileDialog

End Class
