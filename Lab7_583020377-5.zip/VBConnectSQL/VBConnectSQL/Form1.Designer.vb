﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Lbldstudent = New System.Windows.Forms.Label()
        Me.LbName = New System.Windows.Forms.Label()
        Me.LbAddress = New System.Windows.Forms.Label()
        Me.TxtTel = New System.Windows.Forms.Label()
        Me.LbEmail = New System.Windows.Forms.Label()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.BtnUpdate = New System.Windows.Forms.Button()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.LbMajor = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LbLastname = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "รหัสนักศึกษา"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(117, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "ชื่อ"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(265, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "สาขา"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(335, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "ที่อยู่"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(439, 19)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Email"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(552, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "เบอร์โทรศัพท์"
        '
        'Lbldstudent
        '
        Me.Lbldstudent.Location = New System.Drawing.Point(32, 63)
        Me.Lbldstudent.Name = "Lbldstudent"
        Me.Lbldstudent.Size = New System.Drawing.Size(89, 224)
        Me.Lbldstudent.TabIndex = 7
        Me.Lbldstudent.Text = "ผลลัพธ์"
        '
        'LbName
        '
        Me.LbName.Location = New System.Drawing.Point(107, 63)
        Me.LbName.Name = "LbName"
        Me.LbName.Size = New System.Drawing.Size(89, 224)
        Me.LbName.TabIndex = 8
        Me.LbName.Text = "ผลลัพธ์"
        '
        'LbAddress
        '
        Me.LbAddress.Location = New System.Drawing.Point(335, 63)
        Me.LbAddress.Name = "LbAddress"
        Me.LbAddress.Size = New System.Drawing.Size(89, 224)
        Me.LbAddress.TabIndex = 10
        Me.LbAddress.Text = "ผลลัพธ์"
        '
        'TxtTel
        '
        Me.TxtTel.Location = New System.Drawing.Point(552, 63)
        Me.TxtTel.Name = "TxtTel"
        Me.TxtTel.Size = New System.Drawing.Size(105, 224)
        Me.TxtTel.TabIndex = 11
        Me.TxtTel.Text = "ผลลัพธ์"
        '
        'LbEmail
        '
        Me.LbEmail.Location = New System.Drawing.Point(439, 63)
        Me.LbEmail.Name = "LbEmail"
        Me.LbEmail.Size = New System.Drawing.Size(112, 224)
        Me.LbEmail.TabIndex = 12
        Me.LbEmail.Text = "ผลลัพธ์"
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(77, 371)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(98, 43)
        Me.BtnSave.TabIndex = 13
        Me.BtnSave.Text = "Insert"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'BtnUpdate
        '
        Me.BtnUpdate.Location = New System.Drawing.Point(279, 371)
        Me.BtnUpdate.Name = "BtnUpdate"
        Me.BtnUpdate.Size = New System.Drawing.Size(83, 43)
        Me.BtnUpdate.TabIndex = 14
        Me.BtnUpdate.Text = "Update"
        Me.BtnUpdate.UseVisualStyleBackColor = True
        '
        'BtnDelete
        '
        Me.BtnDelete.Location = New System.Drawing.Point(476, 371)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(86, 43)
        Me.BtnDelete.TabIndex = 15
        Me.BtnDelete.Text = "Delete"
        Me.BtnDelete.UseVisualStyleBackColor = True
        '
        'LbMajor
        '
        Me.LbMajor.Location = New System.Drawing.Point(265, 63)
        Me.LbMajor.Name = "LbMajor"
        Me.LbMajor.Size = New System.Drawing.Size(89, 224)
        Me.LbMajor.TabIndex = 9
        Me.LbMajor.Text = "ผลลัพธ์"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(634, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = resources.GetString("Label7.Text")
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(176, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "นามสกุล"
        '
        'LbLastname
        '
        Me.LbLastname.Location = New System.Drawing.Point(176, 63)
        Me.LbLastname.Name = "LbLastname"
        Me.LbLastname.Size = New System.Drawing.Size(89, 224)
        Me.LbLastname.TabIndex = 18
        Me.LbLastname.Text = "ผลลัพธ์"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(661, 453)
        Me.Controls.Add(Me.LbLastname)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.BtnDelete)
        Me.Controls.Add(Me.BtnUpdate)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.LbEmail)
        Me.Controls.Add(Me.TxtTel)
        Me.Controls.Add(Me.LbAddress)
        Me.Controls.Add(Me.LbMajor)
        Me.Controls.Add(Me.LbName)
        Me.Controls.Add(Me.Lbldstudent)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "ทะเบียนนักศึกษา"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Lbldstudent As System.Windows.Forms.Label
    Friend WithEvents LbName As System.Windows.Forms.Label
    Friend WithEvents LbAddress As System.Windows.Forms.Label
    Friend WithEvents TxtTel As System.Windows.Forms.Label
    Friend WithEvents LbEmail As System.Windows.Forms.Label
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents BtnUpdate As System.Windows.Forms.Button
    Friend WithEvents BtnDelete As System.Windows.Forms.Button
    Friend WithEvents LbMajor As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents LbLastname As Label
End Class
