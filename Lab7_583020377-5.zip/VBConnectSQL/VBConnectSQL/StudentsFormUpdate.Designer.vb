﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentsFormUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtlastname = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtMajor = New System.Windows.Forms.ComboBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtTel = New System.Windows.Forms.TextBox()
        Me.TxtAddress = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtldStudent = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txtlasname_up = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txtmajor_up = New System.Windows.Forms.ComboBox()
        Me.Txtmail_up = New System.Windows.Forms.TextBox()
        Me.Txttel_up = New System.Windows.Forms.TextBox()
        Me.Txtadd_up = New System.Windows.Forms.TextBox()
        Me.Txtname_up = New System.Windows.Forms.TextBox()
        Me.Txtid_up = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Txtlastname
        '
        Me.Txtlastname.Location = New System.Drawing.Point(98, 129)
        Me.Txtlastname.Name = "Txtlastname"
        Me.Txtlastname.Size = New System.Drawing.Size(177, 20)
        Me.Txtlastname.TabIndex = 37
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(46, 132)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "นามสกุล"
        '
        'TxtMajor
        '
        Me.TxtMajor.FormattingEnabled = True
        Me.TxtMajor.Location = New System.Drawing.Point(98, 153)
        Me.TxtMajor.Name = "TxtMajor"
        Me.TxtMajor.Size = New System.Drawing.Size(178, 21)
        Me.TxtMajor.TabIndex = 35
        '
        'TxtEmail
        '
        Me.TxtEmail.Location = New System.Drawing.Point(98, 207)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(177, 20)
        Me.TxtEmail.TabIndex = 34
        '
        'TxtTel
        '
        Me.TxtTel.Location = New System.Drawing.Point(98, 233)
        Me.TxtTel.Name = "TxtTel"
        Me.TxtTel.Size = New System.Drawing.Size(177, 20)
        Me.TxtTel.TabIndex = 33
        '
        'TxtAddress
        '
        Me.TxtAddress.Location = New System.Drawing.Point(98, 181)
        Me.TxtAddress.Name = "TxtAddress"
        Me.TxtAddress.Size = New System.Drawing.Size(177, 20)
        Me.TxtAddress.TabIndex = 32
        '
        'TxtName
        '
        Me.TxtName.Location = New System.Drawing.Point(98, 103)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(177, 20)
        Me.TxtName.TabIndex = 31
        '
        'TxtldStudent
        '
        Me.TxtldStudent.Location = New System.Drawing.Point(98, 77)
        Me.TxtldStudent.Name = "TxtldStudent"
        Me.TxtldStudent.Size = New System.Drawing.Size(177, 20)
        Me.TxtldStudent.TabIndex = 30
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(71, 43)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(520, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "---------------------------------------------------------------------------------" &
    "--------------------------------------------------------------------------------" &
    "----------"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(412, 18)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(258, 20)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(148, 20)
        Me.TxtSearch.TabIndex = 26
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(19, 236)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 13)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "เบอร์โทรศัพท์"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(59, 210)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(64, 184)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "ที่อยู่"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(61, 156)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "สาขา"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(71, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "ชื่อ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "รหัสนักศึกษา"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(188, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "รหัสนักศึกษา"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(324, 72)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(9, 182)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Txtlasname_up
        '
        Me.Txtlasname_up.Location = New System.Drawing.Point(435, 129)
        Me.Txtlasname_up.Name = "Txtlasname_up"
        Me.Txtlasname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtlasname_up.TabIndex = 52
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(383, 132)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 51
        Me.Label11.Text = "นามสกุล"
        '
        'Txtmajor_up
        '
        Me.Txtmajor_up.FormattingEnabled = True
        Me.Txtmajor_up.Location = New System.Drawing.Point(435, 153)
        Me.Txtmajor_up.Name = "Txtmajor_up"
        Me.Txtmajor_up.Size = New System.Drawing.Size(178, 21)
        Me.Txtmajor_up.TabIndex = 50
        '
        'Txtmail_up
        '
        Me.Txtmail_up.Location = New System.Drawing.Point(435, 207)
        Me.Txtmail_up.Name = "Txtmail_up"
        Me.Txtmail_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtmail_up.TabIndex = 49
        '
        'Txttel_up
        '
        Me.Txttel_up.Location = New System.Drawing.Point(435, 233)
        Me.Txttel_up.Name = "Txttel_up"
        Me.Txttel_up.Size = New System.Drawing.Size(177, 20)
        Me.Txttel_up.TabIndex = 48
        '
        'Txtadd_up
        '
        Me.Txtadd_up.Location = New System.Drawing.Point(435, 181)
        Me.Txtadd_up.Name = "Txtadd_up"
        Me.Txtadd_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtadd_up.TabIndex = 47
        '
        'Txtname_up
        '
        Me.Txtname_up.Location = New System.Drawing.Point(435, 103)
        Me.Txtname_up.Name = "Txtname_up"
        Me.Txtname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtname_up.TabIndex = 46
        '
        'Txtid_up
        '
        Me.Txtid_up.Location = New System.Drawing.Point(435, 77)
        Me.Txtid_up.Name = "Txtid_up"
        Me.Txtid_up.ReadOnly = True
        Me.Txtid_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtid_up.TabIndex = 45
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(356, 236)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(72, 13)
        Me.Label12.TabIndex = 44
        Me.Label12.Text = "เบอร์โทรศัพท์"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(396, 210)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "Email"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(401, 184)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(27, 13)
        Me.Label14.TabIndex = 42
        Me.Label14.Text = "ที่อยู่"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(398, 156)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "สาขา"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(408, 106)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 13)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "ชื่อ"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(359, 77)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 13)
        Me.Label17.TabIndex = 39
        Me.Label17.Text = "รหัสนักศึกษา"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(538, 269)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 53
        Me.Button2.Text = "Update"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'StudentsFormUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(649, 304)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Txtlasname_up)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txtmajor_up)
        Me.Controls.Add(Me.Txtmail_up)
        Me.Controls.Add(Me.Txttel_up)
        Me.Controls.Add(Me.Txtadd_up)
        Me.Controls.Add(Me.Txtname_up)
        Me.Controls.Add(Me.Txtid_up)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Txtlastname)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TxtMajor)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtTel)
        Me.Controls.Add(Me.TxtAddress)
        Me.Controls.Add(Me.TxtName)
        Me.Controls.Add(Me.TxtldStudent)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtSearch)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "StudentsFormUpdate"
        Me.Text = "StudentsFormUpdate"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txtlastname As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtMajor As ComboBox
    Friend WithEvents TxtEmail As TextBox
    Friend WithEvents TxtTel As TextBox
    Friend WithEvents TxtAddress As TextBox
    Friend WithEvents TxtName As TextBox
    Friend WithEvents TxtldStudent As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents TxtSearch As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Txtlasname_up As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Txtmajor_up As ComboBox
    Friend WithEvents Txtmail_up As TextBox
    Friend WithEvents Txttel_up As TextBox
    Friend WithEvents Txtadd_up As TextBox
    Friend WithEvents Txtname_up As TextBox
    Friend WithEvents Txtid_up As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Button2 As Button
End Class
