﻿Imports System.Data.SqlClient
Public Class Form1
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.show_data()
    End Sub

    Public Sub show_data()
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        Lbldstudent.Text = ""
        LbName.Text = ""
        LbLastname.Text = ""
        LbMajor.Text = ""
        LbAddress.Text = ""
        LbEmail.Text = ""
        TxtTel.Text = ""

        Dim Str As String = "SELECT Student.std_id,Student.std_name,Student.std_lastname,Department.dept_name,Student.std_address,
        Student.std_mail,Student.std_tel"
        Str &= " FROM Student INNER JOIN Department on (Student.dept_id = Department.dept_id);"

        Dim cmd As New SqlCommand(Str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read
                Lbldstudent.Text += dr.Item(0) + vbCrLf + vbCrLf
                LbName.Text += dr.Item(1) + vbCrLf + vbCrLf
                LbLastname.Text += dr.Item(2) + vbCrLf + vbCrLf
                LbMajor.Text += dr.Item(3) + vbCrLf + vbCrLf
                LbAddress.Text += dr.Item(4) + vbCrLf + vbCrLf
                LbEmail.Text += dr.Item(5) + vbCrLf + vbCrLf
                TxtTel.Text += dr.Item(6) + vbCrLf + vbCrLf
            End While
            dr.Close()
        End If
        connection.Close()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim Form As New StudentsFormSave()
        Form.Show()
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click
        Dim Form As New StudentsFormUpdate()
        Form.Show()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        Dim Form As New StudentsDelete()
        Form.Show()
    End Sub
End Class
