﻿Imports System.Data.SqlClient
Public Class StudentsFormUpdate
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Private Sub StudentsFormUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        Dim Str As String = "SELECT Department.dept_id,Department.dept_name FROM Department"
        Dim com As New SqlCommand(Str, connection)
        Dim dr As SqlDataReader = com.ExecuteReader()

        Dim comboSource As New Dictionary(Of String, String)()
        comboSource.Add(0, "--เลือกสาขา--")
        If dr.HasRows Then
            While dr.Read
                comboSource.Add(dr.Item(0), dr.Item(1))
            End While
            dr.Close()
        End If
        TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        TxtMajor.DisplayMember = "Value"
        TxtMajor.ValueMember = "Key"

        TxtldStudent.Enabled = False
        TxtName.Enabled = False
        Txtlastname.Enabled = False
        TxtMajor.Enabled = False
        TxtAddress.Enabled = False
        TxtEmail.Enabled = False
        TxtTel.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str As String
        str = "select * from Student where std_id = '" + TxtSearch.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read
                TxtldStudent.Text = dr.Item(0)
                TxtName.Text = dr.Item(1)
                Txtlastname.Text = dr.Item(2)
                TxtMajor.SelectedIndex = dr.Item(3)
                TxtAddress.Text = dr.Item(4)
                TxtEmail.Text = dr.Item(5)
                TxtTel.Text = dr.Item(6)

                Txtid_up.Text = dr.Item(0)
                Txtname_up.Text = dr.Item(1)
                Txtlasname_up.Text = dr.Item(2)
                'Txtmajor_up.SelectedIndex = dr.Item(3)
                Txtadd_up.Text = dr.Item(4)
                Txtmail_up.Text = dr.Item(5)
                Txttel_up.Text = dr.Item(6)
            End While
        Else
            MessageBox.Show("ไม่มีข้อมูล", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        dr.Close()
        Dim selec As String = "SELECT Department.dept_id,Department.dept_name FROM Department"
        Dim cmd2 = New SqlClient.SqlCommand(selec, connection)
        Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        Dim comboSource As New Dictionary(Of String, String)()
        comboSource.Add(0, "--เลือกสาขา--")
        If dr2.HasRows Then
            While dr2.Read
                comboSource.Add(dr2.Item(0), dr2.Item(1))
            End While
            dr2.Close()
        End If
        Txtmajor_up.DataSource = New BindingSource(comboSource, Nothing)
        Txtmajor_up.DisplayMember = "Value"
        Txtmajor_up.ValueMember = "Key"

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim str As String
        str = "update Student set std_name = '" + Txtname_up.Text + "', std_lastname = '" + Txtlasname_up.Text + "',"
        str &= " dept_id = '" + Txtmajor_up.SelectedValue.ToString() + "', std_address = '" + Txtadd_up.Text + "', 
        std_mail = '" + Txtmail_up.Text + "', std_tel = '" + Txttel_up.Text + "'"
        str &= " where std_id = '" + TxtSearch.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("แก้ไขข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form1.show_data()
        Me.Close()
    End Sub
End Class