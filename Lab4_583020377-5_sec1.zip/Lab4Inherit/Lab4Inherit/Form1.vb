﻿Public Class Form1

    Private Sub Btn_square_Click(sender As Object, e As EventArgs) Handles Btn_square.Click
        Dim MySquare As Square_Class
        MySquare = New Square_Class()
        MySquare.width_p = TxtB_Square_width.Text
        Lb_square_area.Text = "Area :" + CStr(MySquare.Area(MySquare.width_p))
        Lb_square_perimeter.Text = "Perimeter :" + CStr(MySquare.Perimeter())
        MySquare.Draw_square()
        Lb_count_square.Text = "Count Square Object :" + CStr(MySquare.squareCount_p())
    End Sub

    Private Sub Btn_rectangle_Click(sender As Object, e As EventArgs) Handles Btn_rectangle.Click
        Dim MyRectangle As Rectangle_Class
        MyRectangle = New Rectangle_Class()
        MyRectangle.width_p = TxtB_rectangle_width.Text
        MyRectangle.length_p = TxtB_rectangle_length.Text
        Lb_rectangle_area.Text = "Area :" + CStr(MyRectangle.Area(MyRectangle.width_p, MyRectangle.length_p))
        Lb_rectangle_perimeter.Text = "Perimeter :" + CStr(MyRectangle.Perimeter())
        MyRectangle.Draw_Rectangle()
        Lb_count_rectangle.Text = "Count Rectangle Object :" + CStr(MyRectangle.rectangleCount_p())
    End Sub
End Class
