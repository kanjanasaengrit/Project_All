﻿Public Class Rectangle_Class
    Inherits Square_Class
    Private length As Double
    Private Shared rectangleCount As Integer
    Public Property length_p() As String
        Get
            Return length
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                length = value
            Else
                MessageBox.Show("length Value is 0", "Error!!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                length = 0
            End If
        End Set
    End Property
    Public Property rectangleCount_p As Integer
        Get
            Return rectangleCount
        End Get
        Set(value As Integer)
            rectangleCount = value
        End Set
    End Property

    Public Overloads Function Area(w As Double, ByVal l As Double) As Double
        Dim area_rectangle As Double
        area_rectangle = w * l
        Return area_rectangle
    End Function

    Public Overloads Function Perimeter() As Double
        Dim Perimeter_rectangle As Double
        Perimeter_rectangle = (2 * width_p) + (2 * length)
        Return Perimeter_rectangle
    End Function

    Public Sub Draw_Rectangle()
        Dim g_Draw As Graphics = Form1.CreateGraphics
        Dim Pen As Pen = New Pen(Color.Green, 3)
        g_Draw.DrawRectangle(Pen, 20, 20, Convert.ToInt32(length_p), Convert.ToInt32(length_p))

    End Sub


    Public Sub New()
        rectangleCount += 1
    End Sub





End Class
