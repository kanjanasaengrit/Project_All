﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lb_square_area = New System.Windows.Forms.Label()
        Me.Lb_square_perimeter = New System.Windows.Forms.Label()
        Me.Lb_count_square = New System.Windows.Forms.Label()
        Me.TxtB_Square_width = New System.Windows.Forms.TextBox()
        Me.Btn_square = New System.Windows.Forms.Button()
        Me.Btn_rectangle = New System.Windows.Forms.Button()
        Me.TxtB_rectangle_width = New System.Windows.Forms.TextBox()
        Me.Lb_count_rectangle = New System.Windows.Forms.Label()
        Me.Lb_rectangle_perimeter = New System.Windows.Forms.Label()
        Me.Lb_rectangle_area = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtB_rectangle_length = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 260)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Parent Class : Square"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 296)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Width"
        '
        'Lb_square_area
        '
        Me.Lb_square_area.AutoSize = True
        Me.Lb_square_area.Location = New System.Drawing.Point(44, 327)
        Me.Lb_square_area.Name = "Lb_square_area"
        Me.Lb_square_area.Size = New System.Drawing.Size(35, 13)
        Me.Lb_square_area.TabIndex = 2
        Me.Lb_square_area.Text = "Area :"
        '
        'Lb_square_perimeter
        '
        Me.Lb_square_perimeter.AutoSize = True
        Me.Lb_square_perimeter.Location = New System.Drawing.Point(44, 357)
        Me.Lb_square_perimeter.Name = "Lb_square_perimeter"
        Me.Lb_square_perimeter.Size = New System.Drawing.Size(57, 13)
        Me.Lb_square_perimeter.TabIndex = 3
        Me.Lb_square_perimeter.Text = "Perimeter :"
        '
        'Lb_count_square
        '
        Me.Lb_count_square.AutoSize = True
        Me.Lb_count_square.Location = New System.Drawing.Point(265, 357)
        Me.Lb_count_square.Name = "Lb_count_square"
        Me.Lb_count_square.Size = New System.Drawing.Size(75, 13)
        Me.Lb_count_square.TabIndex = 4
        Me.Lb_count_square.Text = "Count Object :"
        '
        'TxtB_Square_width
        '
        Me.TxtB_Square_width.Location = New System.Drawing.Point(119, 288)
        Me.TxtB_Square_width.Multiline = True
        Me.TxtB_Square_width.Name = "TxtB_Square_width"
        Me.TxtB_Square_width.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_Square_width.TabIndex = 5
        '
        'Btn_square
        '
        Me.Btn_square.Location = New System.Drawing.Point(247, 288)
        Me.Btn_square.Name = "Btn_square"
        Me.Btn_square.Size = New System.Drawing.Size(95, 38)
        Me.Btn_square.TabIndex = 6
        Me.Btn_square.Text = "New Square"
        Me.Btn_square.UseVisualStyleBackColor = True
        '
        'Btn_rectangle
        '
        Me.Btn_rectangle.Location = New System.Drawing.Point(455, 438)
        Me.Btn_rectangle.Name = "Btn_rectangle"
        Me.Btn_rectangle.Size = New System.Drawing.Size(95, 42)
        Me.Btn_rectangle.TabIndex = 13
        Me.Btn_rectangle.Text = "New Rectangle"
        Me.Btn_rectangle.UseVisualStyleBackColor = True
        '
        'TxtB_rectangle_width
        '
        Me.TxtB_rectangle_width.Location = New System.Drawing.Point(119, 438)
        Me.TxtB_rectangle_width.Multiline = True
        Me.TxtB_rectangle_width.Name = "TxtB_rectangle_width"
        Me.TxtB_rectangle_width.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_rectangle_width.TabIndex = 12
        '
        'Lb_count_rectangle
        '
        Me.Lb_count_rectangle.AutoSize = True
        Me.Lb_count_rectangle.Location = New System.Drawing.Point(473, 511)
        Me.Lb_count_rectangle.Name = "Lb_count_rectangle"
        Me.Lb_count_rectangle.Size = New System.Drawing.Size(75, 13)
        Me.Lb_count_rectangle.TabIndex = 11
        Me.Lb_count_rectangle.Text = "Count Object :"
        '
        'Lb_rectangle_perimeter
        '
        Me.Lb_rectangle_perimeter.AutoSize = True
        Me.Lb_rectangle_perimeter.Location = New System.Drawing.Point(44, 507)
        Me.Lb_rectangle_perimeter.Name = "Lb_rectangle_perimeter"
        Me.Lb_rectangle_perimeter.Size = New System.Drawing.Size(57, 13)
        Me.Lb_rectangle_perimeter.TabIndex = 10
        Me.Lb_rectangle_perimeter.Text = "Perimeter :"
        '
        'Lb_rectangle_area
        '
        Me.Lb_rectangle_area.AutoSize = True
        Me.Lb_rectangle_area.Location = New System.Drawing.Point(44, 477)
        Me.Lb_rectangle_area.Name = "Lb_rectangle_area"
        Me.Lb_rectangle_area.Size = New System.Drawing.Size(35, 13)
        Me.Lb_rectangle_area.TabIndex = 9
        Me.Lb_rectangle_area.Text = "Area :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(44, 446)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Width"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(44, 410)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(144, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Child Class : Rectangle Class"
        '
        'TxtB_rectangle_length
        '
        Me.TxtB_rectangle_length.Location = New System.Drawing.Point(315, 438)
        Me.TxtB_rectangle_length.Multiline = True
        Me.TxtB_rectangle_length.Name = "TxtB_rectangle_length"
        Me.TxtB_rectangle_length.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_rectangle_length.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(240, 446)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(40, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Length"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(640, 568)
        Me.Controls.Add(Me.TxtB_rectangle_length)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Btn_rectangle)
        Me.Controls.Add(Me.TxtB_rectangle_width)
        Me.Controls.Add(Me.Lb_count_rectangle)
        Me.Controls.Add(Me.Lb_rectangle_perimeter)
        Me.Controls.Add(Me.Lb_rectangle_area)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Btn_square)
        Me.Controls.Add(Me.TxtB_Square_width)
        Me.Controls.Add(Me.Lb_count_square)
        Me.Controls.Add(Me.Lb_square_perimeter)
        Me.Controls.Add(Me.Lb_square_area)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lb_square_area As System.Windows.Forms.Label
    Friend WithEvents Lb_square_perimeter As System.Windows.Forms.Label
    Friend WithEvents Lb_count_square As System.Windows.Forms.Label
    Friend WithEvents TxtB_Square_width As System.Windows.Forms.TextBox
    Friend WithEvents Btn_square As System.Windows.Forms.Button
    Friend WithEvents Btn_rectangle As System.Windows.Forms.Button
    Friend WithEvents TxtB_rectangle_width As System.Windows.Forms.TextBox
    Friend WithEvents Lb_count_rectangle As System.Windows.Forms.Label
    Friend WithEvents Lb_rectangle_perimeter As System.Windows.Forms.Label
    Friend WithEvents Lb_rectangle_area As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TxtB_rectangle_length As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label

End Class
