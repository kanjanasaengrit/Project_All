﻿Public Class Ellipse
    Inherits Circle_Class
    Private xB As Double
    Private yA As Double
    Private PI As Double = 3.14
    Private Shared EllipseCount As Integer

    Public Property xB_p() As String
        Get
            Return xB
        End Get
        Set(value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                xB = value
            Else
                MessageBox.Show("x (b) Value is 0", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                xB = 0
            End If
        End Set
    End Property

    Public Property yA_p() As String
        Get
            Return yA
        End Get
        Set(value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                yA = value
            Else
                MessageBox.Show("y (a) Value is 0", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                yA = 0
            End If
        End Set
    End Property

    Public Property EllipseCount_p() As Integer
        Get
            Return EllipseCount
        End Get
        Set(value As Integer)
            EllipseCount = value
        End Set
    End Property

    Public Overloads Function Area(ByVal a As Double, ByVal b As Double) As Double
        Dim area_Ellipse As Double
        area_Ellipse = (PI / 4) * a * b
        Return area_Ellipse
    End Function

    Public Overrides Function Perimeter() As Double
        Dim perimeter_Ellipse As Double
        perimeter_Ellipse = (PI * (yA_p + xB_p)) / 2
        Return perimeter_Ellipse
    End Function

    Public Overloads Sub Draw_Circle()
        Dim c_DrawR As Graphics = Form2.CreateGraphics
        Dim Pen_green As Pen = New Pen(Color.Green, 3)
        c_DrawR.DrawEllipse(Pen_green, 100, 20, Convert.ToInt32(xB_p), Convert.ToInt32(yA_p))
    End Sub

    Public Sub New()
        EllipseCount += 1
    End Sub
End Class