﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtB_Ca = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btn_elipse = New System.Windows.Forms.Button()
        Me.TxtB_Cb = New System.Windows.Forms.TextBox()
        Me.Lb_count_E = New System.Windows.Forms.Label()
        Me.Lb_EP = New System.Windows.Forms.Label()
        Me.Lb_EA = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Btn_circle = New System.Windows.Forms.Button()
        Me.TxtB_C = New System.Windows.Forms.TextBox()
        Me.Lb_count_C = New System.Windows.Forms.Label()
        Me.Lb_CP = New System.Windows.Forms.Label()
        Me.Lb_CA = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtB_Ca
        '
        Me.TxtB_Ca.Location = New System.Drawing.Point(304, 510)
        Me.TxtB_Ca.Multiline = True
        Me.TxtB_Ca.Name = "TxtB_Ca"
        Me.TxtB_Ca.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_Ca.TabIndex = 31
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(229, 518)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "y-axis (a)"
        '
        'Btn_elipse
        '
        Me.Btn_elipse.Location = New System.Drawing.Point(444, 510)
        Me.Btn_elipse.Name = "Btn_elipse"
        Me.Btn_elipse.Size = New System.Drawing.Size(95, 42)
        Me.Btn_elipse.TabIndex = 29
        Me.Btn_elipse.Text = "New Elipse"
        Me.Btn_elipse.UseVisualStyleBackColor = True
        '
        'TxtB_Cb
        '
        Me.TxtB_Cb.Location = New System.Drawing.Point(108, 510)
        Me.TxtB_Cb.Multiline = True
        Me.TxtB_Cb.Name = "TxtB_Cb"
        Me.TxtB_Cb.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_Cb.TabIndex = 28
        '
        'Lb_count_E
        '
        Me.Lb_count_E.AutoSize = True
        Me.Lb_count_E.Location = New System.Drawing.Point(462, 583)
        Me.Lb_count_E.Name = "Lb_count_E"
        Me.Lb_count_E.Size = New System.Drawing.Size(75, 13)
        Me.Lb_count_E.TabIndex = 27
        Me.Lb_count_E.Text = "Count Object :"
        '
        'Lb_EP
        '
        Me.Lb_EP.AutoSize = True
        Me.Lb_EP.Location = New System.Drawing.Point(33, 579)
        Me.Lb_EP.Name = "Lb_EP"
        Me.Lb_EP.Size = New System.Drawing.Size(57, 13)
        Me.Lb_EP.TabIndex = 26
        Me.Lb_EP.Text = "Perimeter :"
        '
        'Lb_EA
        '
        Me.Lb_EA.AutoSize = True
        Me.Lb_EA.Location = New System.Drawing.Point(33, 549)
        Me.Lb_EA.Name = "Lb_EA"
        Me.Lb_EA.Size = New System.Drawing.Size(35, 13)
        Me.Lb_EA.TabIndex = 25
        Me.Lb_EA.Text = "Area :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 518)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "x-axis (b)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 482)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Child Class : Elipse Class"
        '
        'Btn_circle
        '
        Me.Btn_circle.Location = New System.Drawing.Point(236, 360)
        Me.Btn_circle.Name = "Btn_circle"
        Me.Btn_circle.Size = New System.Drawing.Size(95, 38)
        Me.Btn_circle.TabIndex = 22
        Me.Btn_circle.Text = "New Circle"
        Me.Btn_circle.UseVisualStyleBackColor = True
        '
        'TxtB_C
        '
        Me.TxtB_C.Location = New System.Drawing.Point(108, 360)
        Me.TxtB_C.Multiline = True
        Me.TxtB_C.Name = "TxtB_C"
        Me.TxtB_C.Size = New System.Drawing.Size(96, 35)
        Me.TxtB_C.TabIndex = 21
        '
        'Lb_count_C
        '
        Me.Lb_count_C.AutoSize = True
        Me.Lb_count_C.Location = New System.Drawing.Point(254, 429)
        Me.Lb_count_C.Name = "Lb_count_C"
        Me.Lb_count_C.Size = New System.Drawing.Size(104, 13)
        Me.Lb_count_C.TabIndex = 20
        Me.Lb_count_C.Text = "Count Circle Object :"
        '
        'Lb_CP
        '
        Me.Lb_CP.AutoSize = True
        Me.Lb_CP.Location = New System.Drawing.Point(33, 429)
        Me.Lb_CP.Name = "Lb_CP"
        Me.Lb_CP.Size = New System.Drawing.Size(57, 13)
        Me.Lb_CP.TabIndex = 19
        Me.Lb_CP.Text = "Perimeter :"
        '
        'Lb_CA
        '
        Me.Lb_CA.AutoSize = True
        Me.Lb_CA.Location = New System.Drawing.Point(33, 399)
        Me.Lb_CA.Name = "Lb_CA"
        Me.Lb_CA.Size = New System.Drawing.Size(35, 13)
        Me.Lb_CA.TabIndex = 18
        Me.Lb_CA.Text = "Area :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 368)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Radius"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 332)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Parent Class : Circle Class"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(576, 623)
        Me.Controls.Add(Me.TxtB_Ca)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Btn_elipse)
        Me.Controls.Add(Me.TxtB_Cb)
        Me.Controls.Add(Me.Lb_count_E)
        Me.Controls.Add(Me.Lb_EP)
        Me.Controls.Add(Me.Lb_EA)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Btn_circle)
        Me.Controls.Add(Me.TxtB_C)
        Me.Controls.Add(Me.Lb_count_C)
        Me.Controls.Add(Me.Lb_CP)
        Me.Controls.Add(Me.Lb_CA)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtB_Ca As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Btn_elipse As Button
    Friend WithEvents TxtB_Cb As TextBox
    Friend WithEvents Lb_count_E As Label
    Friend WithEvents Lb_EP As Label
    Friend WithEvents Lb_EA As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Btn_circle As Button
    Friend WithEvents TxtB_C As TextBox
    Friend WithEvents Lb_count_C As Label
    Friend WithEvents Lb_CP As Label
    Friend WithEvents Lb_CA As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
