﻿Public Class Square_Class
    Private width As Double
    Private Shared squareCount As Integer
    Public Property width_p() As String
        Get
            Return width
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                width = value
            Else
                MessageBox.Show("Width Value is 0", "Error!!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                width = 0
            End If
        End Set
    End Property

    Public Property squareCount_p As Integer
        Get
            Return squareCount
        End Get
        Set(value As Integer)
            squareCount = value
        End Set
    End Property

    Public Overridable Function Area(ByVal w As Double) As Double
        Dim area_Square As Double
        area_Square = w * w
        Return area_Square
    End Function

    Public Overridable Function Perimeter() As Double
        Dim Perimeter_Square As Double
        Perimeter_Square = (4 * width)
        Return Perimeter_Square
    End Function

    Public Sub Draw_square()
        Dim g_Draw As Graphics = Form1.CreateGraphics
        Dim Pen As Pen = New Pen(Color.Red, 3)
        g_Draw.DrawRectangle(Pen, 20, 20, Convert.ToInt32(width_p), Convert.ToInt32(width_p))

    End Sub

   
    Public Sub New()
        squareCount_p += 1
    End Sub
End Class
