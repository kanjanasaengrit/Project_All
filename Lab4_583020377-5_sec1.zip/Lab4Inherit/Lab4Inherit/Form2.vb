﻿Public Class Form2
    Private Sub Btn_circle_Click(sender As Object, e As EventArgs) Handles Btn_circle.Click
        Dim MyCircle As Circle_Class
        MyCircle = New Circle_Class()
        MyCircle.radius_p = TxtB_C.Text
        Lb_CA.Text = "Area :" + CStr(MyCircle.Area())
        Lb_CP.Text = "Perimeter :" + CStr(MyCircle.Perimeter())
        MyCircle.Draw_Cicle()
        Lb_count_C.Text = "Count Circle Object :" + CStr(MyCircle.circleCount_p())
    End Sub

    Private Sub Btn_elipse_Click(sender As Object, e As EventArgs) Handles Btn_elipse.Click
        Dim MyEllipse As New Ellipse()
        MyEllipse.xB_p = TxtB_Cb.Text
        MyEllipse.yA_p = TxtB_Ca.Text
        Lb_EA.Text = "Area : " + CStr(MyEllipse.Area(MyEllipse.xB_p, MyEllipse.yA_p))
        Lb_EP.Text = "Perimeter : " + CStr(MyEllipse.Perimeter())
        MyEllipse.Draw_Circle()
        Lb_count_E.Text = "Count Ellipse Object : " + CStr(MyEllipse.EllipseCount_p)
    End Sub
End Class