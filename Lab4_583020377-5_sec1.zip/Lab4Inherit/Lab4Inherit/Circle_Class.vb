﻿Public Class Circle_Class
    Dim Pi As Double = 3.14
    Private radius As Double
    Private Shared circleCount As Integer
    Public Property radius_p() As String
        Get
            Return radius
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                radius = value
            Else
                MessageBox.Show("Radius Value is 0", "Error!!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                radius = 0
            End If
        End Set
    End Property
    Public Property circleCount_p As Integer
        Get
            Return circleCount
        End Get
        Set(value As Integer)
            circleCount = value
        End Set
    End Property

    Public Overridable Function Area() As Double
        Dim area_Cicle As Double
        area_Cicle = Pi * (radius ^ 2)
        Return area_Cicle
    End Function

    Public Overridable Function Perimeter() As Double
        Dim Perimeter_Cicle As Double
        Perimeter_Cicle = 2 * Pi * radius
        Return Perimeter_Cicle
    End Function

    Public Sub Draw_Cicle()
        Dim g_Draw As Graphics = Form2.CreateGraphics
        Dim Pen As Pen = New Pen(Color.Brown, 3)
        g_Draw.DrawEllipse(Pen, 20, 20, Convert.ToInt32(radius_p), Convert.ToInt32(radius_p))

    End Sub
    Public Sub New()
        circleCount_p += 1
    End Sub

End Class
