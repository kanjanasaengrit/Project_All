﻿
Imports System.Data.SqlClient

Public Class login

    Dim cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
    Dim cmd As New SqlCommand
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Dim sql As String
    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub frm_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        If txt_username.Text = "" Or txt_password.Text = "" Then
            MsgBox("กรุณากรอกข้อมูลให้ครบ")
            Return
        End If
        sql = "select * from users where username='" & txt_username.Text & "' AND password='" & txt_password.Text & "'"
        da = New SqlDataAdapter(sql, cn)
        ds = New DataSet
        da.Fill(ds, "datatable")
        If ds.Tables("datatable").Rows.Count <= 0 Then
            MsgBox("คุณกรอก username หรือ password ไม่ถูกต้อง")

            Me.Hide()
        Else
            If ds.Tables("datatable").Rows(0)("class") = "admin" Then
                frm_1.Panel1.Enabled = True
                frm_1.Panel2.Enabled = False
            Else
                frm_1.Panel2.Enabled = True
                frm_1.Panel1.Enabled = False
            End If
            MsgBox("ยินดีต้อนรับเข้าสู่ระบบ")
            frm_1.Show()
            Me.Hide()
        End If

    End Sub
End Class
