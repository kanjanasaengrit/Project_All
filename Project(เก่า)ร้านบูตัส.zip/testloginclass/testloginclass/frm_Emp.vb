﻿Imports System.Data.SqlClient

Public Class frm_Emp

    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub
    Private Sub btn_22_Click(sender As Object, e As EventArgs) Handles btn_22.Click
        'sql = "insert into product values('" & txt_id1.Text & "','" & txt_name1.Text & "','" & txt_add.Text & "')"
        sql = String.Format("insert into Employee values('{0}','{1}','{2}','{3}','{4})",
        txt_id1.Text, txt_name1.Text, txt_add.Text, txt_sl.Text, txt_t.Text)
        If cmd_excuteNonquery() = 0 Then
            MsgBox("เพิ่มข้อมูลไม่สำเร็จ")
        Else
            MsgBox("เพิ่มข้อมูลสำเร็จ")
            txt_id1.Text = ""
            txt_name1.Text = ""
            txt_add.Text = ""
            txt_sl.Text = ""
            txt_t.Text = ""
            Emp()
        End If
    End Sub

    Private Sub btn_23_Click(sender As Object, e As EventArgs) Handles btn_23.Click
        sql = "delete from Employee where Emp_ID='" & txt_d.Text & "'"
        If cmd_excuteNonquery() = 0 Then
            MsgBox("ล้มเหลว")
        Else
            MsgBox("สำเร็จ")
            txt_d.Text = ""
            Emp()

        End If
    End Sub
    Friend Sub Emp()
        open_database()
        sql = "select * from Employee"
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        data_emp.DataSource = Ds.Tables("table")
        change_data_emp()
    End Sub

    Friend Sub change_data_emp()
        Dim new_text() As String = {"รหัสพนักงาน", "ชื่อพนักงาน", "ที่อยู่", "เงินเดือน(บาท)", "เบอร์โทรศัพท์"}
        For i As Integer = 0 To data_emp.ColumnCount - 1
            data_emp.Columns(i).HeaderText = new_text(i)
        Next
    End Sub

    Private Sub frm_Emp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Emp()
    End Sub
End Class