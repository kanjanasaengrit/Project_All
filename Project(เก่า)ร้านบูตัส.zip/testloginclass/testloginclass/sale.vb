﻿Imports System.Data.SqlClient

Public Class sale

        Friend cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
        Friend cmd As New SqlCommand
        Friend DA As New SqlDataAdapter
        Friend Ds As New DataSet
        Friend DR As SqlDataReader
        Friend sql As String
        Dim total As Single


    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub
    Private Sub sale_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim cash As Single
        sql = "select * from product where product_id='" & t4.Text & "'"
        cash = t4.Text
        t6.Text = cash - total
    End Sub

    Private Sub Button1_Click1(sender As Object, e As EventArgs) Handles Button1.Click

        Dim n1, n2, n3, a1, a2, a3 As Single

        n1 = t1.Text
        n2 = t2.Text
        n3 = t3.Text
        a1 = cb4.Text
        a2 = cb5.Text
        a3 = cb6.Text
        total = (n1 * a1) + (n2 * a2) + (n3 * a3)
        t5.Text = total
    End Sub

    Private Sub Button3_Click1(sender As Object, e As EventArgs) Handles Button3.Click
        cb1.Text = ""
        cb2.Text = ""
        cb3.Text = ""
        cb4.Text = ""
        cb5.Text = ""
        cb6.Text = ""
        t1.Text = ""
        t2.Text = "0.00"
        t3.Text = "0.00"
    End Sub

    Friend Sub cmd_sale(obj As Object)
        open_database()
        cmd = New SqlCommand(sql, cn)
        DR = cmd.ExecuteReader
        obj.Items.Clear()
        While DR.Read

            obj.Items.Add(DR(0))
        End While
        DR.Close()
    End Sub


    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles b1.Click
        sql = "select product_name from product"
        cmd_sale(cb1)
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles b2.Click
        sql = "select product_name from product"
        cmd_sale(cb2)
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles b3.Click
        sql = "select product_name from product"
        cmd_sale(cb3)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles b4.Click
        sql = "select product_amount from product"
        cmd_sale(cb4)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles b5.Click
        sql = "select product_amount from product"
        cmd_sale(cb5)
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles b6.Click
        sql = "select product_amount from product"
        cmd_sale(cb6)
    End Sub
End Class