﻿Imports System.Data.SqlClient
Public Class teststock
    Friend cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
    Friend cmd As New SqlCommand
    Friend DA As New SqlDataAdapter
    Friend Ds As New DataSet
    Friend sql As String
    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Friend Sub keep_log(log_work As String) 
        open_database()
        Dim i As Integer = DataGridView1.CurrentRow.Index
        Dim product_id As String = DataGridView1.Item(0, i).Value
        Dim product_amount As Integer
        If log_work = "exit" Then
            product_amount = num_exit.Value
        Else
            product_amount = num_enter.Value
        End If

        sql = "insert into log_product(log_product_id, log_amount, log_work) values(" &
            "'" & product_id & "','" & product_amount & "','" & log_work & "')"
        cmd = New SqlCommand(sql, cn)
        cmd.ExecuteNonQuery()
    End Sub

    Friend Sub load_log()
        open_database()
        Dim i As Integer = DataGridView1.CurrentRow.Index
        Dim product_id As String = DataGridView1.Item(0, i).Value
        sql = "select * from log_product where log_product_id='" & product_id & "'"
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        DataGridView2.DataSource = Ds.Tables("table")
        change_datagrid_log()
    End Sub

    Friend Sub alert_product()
        open_database()
        sql = "select * from product where product_amount<3 "
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        datagrid_alert.DataSource = Ds.Tables("table")
        change_datagrid_alert()
    End Sub
    'Friend Sub data_exp1()
    'open_database()
    ' sql = "select product_Exp from product "
    'DA = New SqlDataAdapter(sql, cn)
    'Ds = New DataSet
    'DA.Fill(Ds, "table")
    'datagrid_alert.DataSource = Ds.Tables("table")
    'change_data_exp()
    ' End Sub
    Friend Sub load_custom_alert()
        open_database()
        sql = "select * from product where product_amount<=status"
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        datagrid_custom_alert.DataSource = Ds.Tables("table")
        change_datagrid_custom_alert()

    End Sub




    Friend Sub change_datagrid_alert()
        Dim new_text() As String = {"รหัสสินค้า", "ชื่อสินค้า", "จำนวนสินค้า", "หน่วย", "แจ้งเตือน", "วันหมดอายุ", "ราคาขาย", "ราคาทุน"}
        For i As Integer = 0 To DataGridView1.ColumnCount - 1
            datagrid_alert.Columns(i).HeaderText = new_text(i)
        Next
    End Sub

    Friend Sub change_datagrid_custom_alert()
        Dim new_text() As String = {"รหัสสินค้า", "ชื่อสินค้า", "จำนวนสินค้า", "หน่วย", "แจ้งเตือน", "วันหมดอายุ", "ราคาขาย", "ราคาทุน"}
        For i As Integer = 0 To DataGridView1.ColumnCount - 1
            datagrid_custom_alert.Columns(i).HeaderText = new_text(i)
        Next
    End Sub
    Friend Sub change_datagrid_column1()
        Dim new_text() As String = {"รหัสสินค้า", "ชื่อสินค้า", "จำนวนสินค้า", "หน่วย", "แจ้งเตือน", "วันหมดอายุ", "ราคาขาย", "ราคาทุน"}
        For i As Integer = 0 To DataGridView1.ColumnCount - 1
            DataGridView1.Columns(i).HeaderText = new_text(i)
        Next


    End Sub

    'Friend Sub change_data_exp()
    'Dim new_text() As String = {"รหัสสินค้า", "ชื่อสินค้า", "จำนวนสินค้า", "หน่วย", "แจ้งเตือน", "วันหมดอายุ"}
    'For i As Integer = 0 To data_exp.ColumnCount - 1
    'data_exp.Columns(i).HeaderText = new_text(i)
    'Next


    'End Sub

    Friend Sub change_datagrid_log()
        Dim new_text() As String = {"รหัส log", "รหัสสินค้า", "จำนวนสินค้า", "งาน"}
        For i As Integer = 0 To DataGridView2.ColumnCount - 1
            DataGridView2.Columns(i).HeaderText = new_text(i)
        Next
    End Sub
    Friend Sub load_product()
        open_database()
        sql = "select * from product"
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        DataGridView1.DataSource = Ds.Tables("table")
        change_datagrid_column1()

    End Sub

    Private Sub teststock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_product()
        alert_product()
        load_custom_alert()
        'data_exp1()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        open_database()
        sql = "update product set product_amount=product_amount-" & num_exit.Value & "where product_id='" &
            DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value & "'"
        cmd = New SqlCommand(sql, cn)
        If cmd.ExecuteNonQuery = 0 Then
            MsgBox("ผิดพลาด")
        Else
            MsgBox("สำเร็จ")
            keep_log("exit")
            load_product()
            alert_product()
            load_custom_alert()
        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim i As Integer = DataGridView1.CurrentRow.Index
        Dim amount As Integer = DataGridView1.Item(2, i).Value
        num_exit.Maximum = amount
        load_log()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        num_exit.Value = num_exit.Maximum
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        open_database()
        sql = "update product set product_amount=product_amount+" & num_enter.Value & "where product_id='" &
            DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value & "'"
        cmd = New SqlCommand(sql, cn)
        If cmd.ExecuteNonQuery = 0 Then
            MsgBox("ผิดพลาด")
        Else
            MsgBox("สำเร็จ")

            keep_log("enter")
            load_product()
            alert_product()
            load_custom_alert()

        End If
    End Sub

    Private Sub btn_คืน_Click(sender As Object, e As EventArgs) Handles btn_คืน.Click
        Dim i As Integer = DataGridView2.CurrentRow.Index
        Dim log_work As String = DataGridView2.Item(3, i).Value
        Dim product_id As String = DataGridView2.Item(1, i).Value
        Dim log_id As String = DataGridView2.Item(0, i).Value
        Dim product_amount As String = DataGridView2.Item(2, i).Value
        If log_work = "exit" Then
            sql = "update product set product_amount=product_amount+" & product_amount & "where product_id='" & product_id & "'"
        Else
            sql = "update product set product_amount=product_amount-" & product_amount & "where product_id='" & product_id & "'"
        End If
        cmd = New SqlCommand(sql, cn)
        If cmd.ExecuteNonQuery > 0 Then
            MsgBox("สำเร็จ")
            sql = " delete from log_product where log_id='" & log_id & "'"
            cmd = New SqlCommand(sql, cn)
            cmd.ExecuteNonQuery()
            load_product()
            load_log()
            alert_product()
            load_custom_alert()
        Else
            MsgBox("ผิดพลาด")
        End If



    End Sub

End Class