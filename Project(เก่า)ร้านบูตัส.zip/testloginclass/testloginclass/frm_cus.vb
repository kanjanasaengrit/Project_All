﻿
Imports System.Data.SqlClient

Public Class frm_cus

    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub
    Private Sub btn_22_Click(sender As Object, e As EventArgs) Handles btn_22.Click
        'sql = "insert into product values('" & txt_id1.Text & "','" & txt_name1.Text & "','" & txt_add.Text & "')"
        sql = String.Format("insert into customer values('{0}','{1}','{2}')",
        txt_id2.Text, txt_name2.Text, txt_add1.Text)
        If cmd_excuteNonquery() = 0 Then
            MsgBox("เพิ่มข้อมูลไม่สำเร็จ")
        Else
            MsgBox("เพิ่มข้อมูลสำเร็จ")
            txt_id2.Text = ""
            txt_name2.Text = ""
            txt_add1.Text = ""
            Cus()
            Me.Hide()
        End If
    End Sub

    Private Sub btn_23_Click(sender As Object, e As EventArgs) Handles btn_23.Click
        sql = "delete from Employee where Emp_ID='" & txt_dd.Text & "'"
        If cmd_excuteNonquery() = 0 Then
            MsgBox("ล้มเหลว")
        Else
            MsgBox("สำเร็จ")
            txt_dd.Text = ""
            Me.Hide()
        End If
    End Sub
    Friend Sub Cus()
        open_database()
        sql = "select * from customer"
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        data_cus.DataSource = Ds.Tables("table")
        change_data_cus()
    End Sub

    Friend Sub change_data_cus()
        Dim new_text() As String = {"รหัสลูกค้า", "ชื่อลูกค้า", "เบอร์โทรศัพท์"}
        For i As Integer = 0 To data_cus.ColumnCount - 1
            data_cus.Columns(i).HeaderText = new_text(i)
        Next
    End Sub

    Private Sub frm_Emp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Cus()
    End Sub
End Class