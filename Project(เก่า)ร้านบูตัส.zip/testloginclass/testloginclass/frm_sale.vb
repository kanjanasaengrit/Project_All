﻿Imports System.Data.SqlClient
Public Class frm_sale
    Friend cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
    Friend cmd As New SqlCommand
    Friend DA As New SqlDataAdapter
    Friend Ds As New DataSet
    Friend DR As SqlDataReader
    Friend sql As String
    Dim total As Single
    Private Sub frm_sale_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_change.Click
        Dim cash As Single
        sql = "select * from product where product_id='" & TextBox12.Text & "'"
        cash = TextBox12.Text
        lbl_change.Text = cash - total
    End Sub

    Private Sub btn_sum_Click(sender As Object, e As EventArgs) Handles btn_sum.Click
        Dim n1, n2, n3, a1, a2, a3 As Single

        n1 = txt_n1.Text
        n2 = txt_n2.Text
        n3 = txt_n3.Text
        a1 = cb_4.Text
        a2 = cb_5.Text
        a3 = cb_6.Text
        total = (n1 * a1) + (n2 * a2) + (n3 * a3)
        lbl_total.Text = total
    End Sub

    Private Sub btn_dear_Click(sender As Object, e As EventArgs) Handles btn_dear.Click

        cb_1.Text = ""
        cb_2.Text = ""
        cb_3.Text = ""
        cb_4.Text = ""
        cb_5.Text = ""
        cb_6.Text = ""
        TextBox12.Text = ""
        lbl_total.Text = "0.00"
        lbl_change.Text = "0.00"
    End Sub

    Friend Sub cmd_sale(obj As Object)
        open_database()
        cmd = New SqlCommand(sql, cn)
        DR = cmd.ExecuteReader
        obj.Items.Clear()
        While DR.Read

            obj.Items.Add(DR(0))
        End While
        DR.Close()
    End Sub


    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        sql = "select product_name from product"
        cmd_sale(cb_1)
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        sql = "select product_name from product"
        cmd_sale(cb_2)
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        sql = "select product_name from product"
        cmd_sale(cb_3)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sql = "select product_amount from product"
        cmd_sale(cb_4)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        sql = "select product_amount from product"
        cmd_sale(cb_5)
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        sql = "select product_amount from product"
        cmd_sale(cb_6)
    End Sub
End Class