﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_cus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_22 = New System.Windows.Forms.Button()
        Me.txt_add1 = New System.Windows.Forms.TextBox()
        Me.txt_name2 = New System.Windows.Forms.TextBox()
        Me.txt_id2 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txt_dd = New System.Windows.Forms.TextBox()
        Me.btn_23 = New System.Windows.Forms.Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.data_cus = New System.Windows.Forms.DataGridView()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.data_cus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(45, 44)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(682, 418)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.btn_22)
        Me.TabPage2.Controls.Add(Me.txt_add1)
        Me.TabPage2.Controls.Add(Me.txt_name2)
        Me.TabPage2.Controls.Add(Me.txt_id2)
        Me.TabPage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(674, 392)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "เพิ่ม"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(98, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "เบอร์โทร"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(98, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 20)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "ชื่อลูกค้า"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(98, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 20)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "รหัสลูกค้า"
        '
        'btn_22
        '
        Me.btn_22.Location = New System.Drawing.Point(294, 182)
        Me.btn_22.Name = "btn_22"
        Me.btn_22.Size = New System.Drawing.Size(86, 30)
        Me.btn_22.TabIndex = 6
        Me.btn_22.Text = "เพิ่ม"
        Me.btn_22.UseVisualStyleBackColor = True
        '
        'txt_add1
        '
        Me.txt_add1.Location = New System.Drawing.Point(262, 113)
        Me.txt_add1.Name = "txt_add1"
        Me.txt_add1.Size = New System.Drawing.Size(156, 26)
        Me.txt_add1.TabIndex = 2
        '
        'txt_name2
        '
        Me.txt_name2.Location = New System.Drawing.Point(262, 71)
        Me.txt_name2.Name = "txt_name2"
        Me.txt_name2.Size = New System.Drawing.Size(156, 26)
        Me.txt_name2.TabIndex = 1
        '
        'txt_id2
        '
        Me.txt_id2.Location = New System.Drawing.Point(262, 27)
        Me.txt_id2.Name = "txt_id2"
        Me.txt_id2.Size = New System.Drawing.Size(156, 26)
        Me.txt_id2.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txt_dd)
        Me.TabPage3.Controls.Add(Me.btn_23)
        Me.TabPage3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(674, 392)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "ลบ"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'txt_dd
        '
        Me.txt_dd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_dd.Location = New System.Drawing.Point(135, 172)
        Me.txt_dd.Multiline = True
        Me.txt_dd.Name = "txt_dd"
        Me.txt_dd.Size = New System.Drawing.Size(203, 35)
        Me.txt_dd.TabIndex = 1
        '
        'btn_23
        '
        Me.btn_23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btn_23.Location = New System.Drawing.Point(414, 172)
        Me.btn_23.Name = "btn_23"
        Me.btn_23.Size = New System.Drawing.Size(90, 36)
        Me.btn_23.TabIndex = 0
        Me.btn_23.Text = "ลบ"
        Me.btn_23.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.data_cus)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(674, 392)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "ข้อมูลลูกค้า"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'data_cus
        '
        Me.data_cus.AllowUserToAddRows = False
        Me.data_cus.AllowUserToDeleteRows = False
        Me.data_cus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_cus.Location = New System.Drawing.Point(121, 39)
        Me.data_cus.Name = "data_cus"
        Me.data_cus.ReadOnly = True
        Me.data_cus.Size = New System.Drawing.Size(461, 272)
        Me.data_cus.TabIndex = 0
        '
        'frm_cus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(779, 488)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frm_cus"
        Me.Text = "จัดการลูกค้า"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        CType(Me.data_cus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_22 As Button
    Friend WithEvents txt_add1 As TextBox
    Friend WithEvents txt_name2 As TextBox
    Friend WithEvents txt_id2 As TextBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents txt_dd As TextBox
    Friend WithEvents btn_23 As Button
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents data_cus As DataGridView
End Class
