﻿'Imports System.Data.SqlClient
'Module code1

'Friend cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
'Friend cc As New SqlCommand
'Friend DA As New SqlDataAdapter
'Friend Ds As New DataSet
'Friend sql As String
'Public Sub open_database()
'If cn.State = ConnectionState.Closed Then cn.Open()
'End Sub
'Friend Function cc_EEexcuteNonquery()
'open_database()
'cc = New SqlCommand(sql, cn)
'Return cc.ExecuteNonQuery()
'End Function
'Friend Function cmd_DataTable()
'open_database()
'DA = New SqlDataAdapter(sql, cn)
'Ds = New Da'taSet
'DA.Fill(Ds, "table")
'Return Ds.Tables("table")
'End Function
'End Module