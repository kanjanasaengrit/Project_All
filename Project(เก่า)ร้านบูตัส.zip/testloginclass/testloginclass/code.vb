﻿
Imports System.Data.SqlClient

Module code
    Friend cn As New SqlConnection("data source =.\SQLEXPRESS; Initial catalog=stocktest; Integrated security=sspi;")
    Friend cmd As New SqlCommand
    Friend DA As New SqlDataAdapter
    Friend Ds As New DataSet
    Friend sql As String
    Public Sub open_database()
        If cn.State = ConnectionState.Closed Then cn.Open()
    End Sub

    Friend Function cmd_excuteNonquery()
        open_database()
        cmd = New SqlCommand(sql, cn)
        Return cmd.ExecuteNonQuery()
    End Function
    Friend Function cmd_DataTable()
        open_database()
        DA = New SqlDataAdapter(sql, cn)
        Ds = New DataSet
        DA.Fill(Ds, "table")
        Return Ds.Tables("table")
    End Function
End Module
