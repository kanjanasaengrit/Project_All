﻿Public Class frm_Emp1
    Private Sub ToolStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub

    Private Sub frm_Emp1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub e1_Click(sender As Object, e As EventArgs) Handles e1.Click
        teststock.Show()
    End Sub

    Private Sub e2_Click(sender As Object, e As EventArgs) Handles e2.Click
        frm_insert_delete.Show()
    End Sub

    Private Sub e3_Click(sender As Object, e As EventArgs) Handles e3.Click
        frm_cus.Show()
    End Sub

    Private Sub e4_Click(sender As Object, e As EventArgs) Handles e4.Click
        Me.Close()
        login.Show()
        With login
            .txt_username.Text = ""
            .txt_password.Text = ""
        End With
    End Sub

    Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs) Handles ToolStripButton5.Click
        sale.show
    End Sub
End Class