﻿
Public Class frm_insert_delete

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'sql = "insert into product values('" & txt_ID.Text & "','" & txt_name.Text & "','" & txt_amt.Text & "','" & txt_5.Text & "','" & txt_6.Text & "')"
        sql = String.Format("insert into product values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')",
                            txt_ID.Text, txt_name.Text, txt_amt.Text, txt_5.Text, txt_6.Text, txt_7.Text, txt_s.Text, txt_p.Text)
        If cmd_excuteNonquery() = 0 Then
            MsgBox("เพิ่มข้อมูลไม่สำเร็จ")

        Else
            MsgBox("เพิ่มข้อมูลสำเร็จ")
            Me.Hide()
        End If
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        sql = "delete from product where product_id='" & txt_delete.Text & "'"
        If cmd_excuteNonquery() = 0 Then
            MsgBox("ล้มเหลว")
        Else
            MsgBox("สำเร็จ")
            Me.Hide()
        End If
    End Sub

    Private Sub frm_insert_delete_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txt_ID_TextChanged(sender As Object, e As EventArgs) Handles txt_ID.TextChanged

    End Sub
End Class