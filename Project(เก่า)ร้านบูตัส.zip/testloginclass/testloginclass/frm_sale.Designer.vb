﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_sale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_n3 = New System.Windows.Forms.TextBox()
        Me.txt_n2 = New System.Windows.Forms.TextBox()
        Me.txt_n1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lbl_total = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lbl_change = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.btn_sum = New System.Windows.Forms.Button()
        Me.btn_change = New System.Windows.Forms.Button()
        Me.btn_dear = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.cb_1 = New System.Windows.Forms.ComboBox()
        Me.cb_2 = New System.Windows.Forms.ComboBox()
        Me.cb_3 = New System.Windows.Forms.ComboBox()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.cb_4 = New System.Windows.Forms.ComboBox()
        Me.cb_6 = New System.Windows.Forms.ComboBox()
        Me.cb_5 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(97, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "รหัสสินค้า"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.Location = New System.Drawing.Point(317, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "จำนวน"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.Location = New System.Drawing.Point(334, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "รวมทั้งหมด"
        '
        'txt_n3
        '
        Me.txt_n3.Location = New System.Drawing.Point(432, 176)
        Me.txt_n3.Multiline = True
        Me.txt_n3.Name = "txt_n3"
        Me.txt_n3.Size = New System.Drawing.Size(92, 30)
        Me.txt_n3.TabIndex = 9
        '
        'txt_n2
        '
        Me.txt_n2.Location = New System.Drawing.Point(432, 130)
        Me.txt_n2.Multiline = True
        Me.txt_n2.Name = "txt_n2"
        Me.txt_n2.Size = New System.Drawing.Size(92, 30)
        Me.txt_n2.TabIndex = 10
        '
        'txt_n1
        '
        Me.txt_n1.Location = New System.Drawing.Point(432, 70)
        Me.txt_n1.Multiline = True
        Me.txt_n1.Name = "txt_n1"
        Me.txt_n1.Size = New System.Drawing.Size(92, 30)
        Me.txt_n1.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.Location = New System.Drawing.Point(467, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "ราคา"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.Location = New System.Drawing.Point(385, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 20)
        Me.Label5.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label8.Location = New System.Drawing.Point(541, 74)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 20)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "บาท"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label9.Location = New System.Drawing.Point(541, 177)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(35, 20)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "บาท"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label10.Location = New System.Drawing.Point(541, 130)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 20)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "บาท"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.Location = New System.Drawing.Point(130, 235)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 20)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "เงินสด"
        '
        'lbl_total
        '
        Me.lbl_total.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lbl_total.Location = New System.Drawing.Point(333, 262)
        Me.lbl_total.Multiline = True
        Me.lbl_total.Name = "lbl_total"
        Me.lbl_total.Size = New System.Drawing.Size(116, 57)
        Me.lbl_total.TabIndex = 22
        Me.lbl_total.Text = "0.00"
        Me.lbl_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label12.Location = New System.Drawing.Point(354, 322)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 20)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "เงินทอน"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label13.Location = New System.Drawing.Point(467, 376)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 20)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "บาท"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label14.Location = New System.Drawing.Point(467, 287)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 20)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "บาท"
        '
        'lbl_change
        '
        Me.lbl_change.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lbl_change.Location = New System.Drawing.Point(333, 356)
        Me.lbl_change.Multiline = True
        Me.lbl_change.Name = "lbl_change"
        Me.lbl_change.Size = New System.Drawing.Size(116, 57)
        Me.lbl_change.TabIndex = 26
        Me.lbl_change.Text = "0.00"
        Me.lbl_change.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.White
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(47, 271)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(116, 53)
        Me.TextBox12.TabIndex = 27
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_sum
        '
        Me.btn_sum.Location = New System.Drawing.Point(214, 235)
        Me.btn_sum.Name = "btn_sum"
        Me.btn_sum.Size = New System.Drawing.Size(81, 38)
        Me.btn_sum.TabIndex = 28
        Me.btn_sum.Text = "รวมเงิน"
        Me.btn_sum.UseVisualStyleBackColor = True
        '
        'btn_change
        '
        Me.btn_change.Location = New System.Drawing.Point(214, 287)
        Me.btn_change.Name = "btn_change"
        Me.btn_change.Size = New System.Drawing.Size(81, 41)
        Me.btn_change.TabIndex = 29
        Me.btn_change.Text = "ทอนเงิน"
        Me.btn_change.UseVisualStyleBackColor = True
        '
        'btn_dear
        '
        Me.btn_dear.Location = New System.Drawing.Point(214, 345)
        Me.btn_dear.Name = "btn_dear"
        Me.btn_dear.Size = New System.Drawing.Size(81, 37)
        Me.btn_dear.TabIndex = 30
        Me.btn_dear.Text = "เคลียร์"
        Me.btn_dear.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label15.Location = New System.Drawing.Point(117, 331)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 20)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "บาท"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label16.Location = New System.Drawing.Point(12, 74)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(65, 20)
        Me.Label16.TabIndex = 32
        Me.Label16.Text = "ลำดับที่ 1"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label17.Location = New System.Drawing.Point(12, 128)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 20)
        Me.Label17.TabIndex = 33
        Me.Label17.Text = "ลำดับที่ 2"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label18.Location = New System.Drawing.Point(12, 177)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(65, 20)
        Me.Label18.TabIndex = 34
        Me.Label18.Text = "ลำดับที่ 3"
        '
        'cb_1
        '
        Me.cb_1.FormattingEnabled = True
        Me.cb_1.Location = New System.Drawing.Point(83, 76)
        Me.cb_1.Name = "cb_1"
        Me.cb_1.Size = New System.Drawing.Size(121, 21)
        Me.cb_1.TabIndex = 35
        '
        'cb_2
        '
        Me.cb_2.FormattingEnabled = True
        Me.cb_2.Location = New System.Drawing.Point(83, 128)
        Me.cb_2.Name = "cb_2"
        Me.cb_2.Size = New System.Drawing.Size(121, 21)
        Me.cb_2.TabIndex = 36
        '
        'cb_3
        '
        Me.cb_3.FormattingEnabled = True
        Me.cb_3.Location = New System.Drawing.Point(83, 179)
        Me.cb_3.Name = "cb_3"
        Me.cb_3.Size = New System.Drawing.Size(121, 21)
        Me.cb_3.TabIndex = 37
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(214, 71)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(75, 26)
        Me.btn1.TabIndex = 38
        Me.btn1.Text = "เลือก"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(214, 125)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(75, 23)
        Me.btn2.TabIndex = 39
        Me.btn2.Text = "เลือก"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(214, 174)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(75, 23)
        Me.btn3.TabIndex = 40
        Me.btn3.Text = "เลือก"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'cb_4
        '
        Me.cb_4.FormattingEnabled = True
        Me.cb_4.Location = New System.Drawing.Point(311, 76)
        Me.cb_4.Name = "cb_4"
        Me.cb_4.Size = New System.Drawing.Size(68, 21)
        Me.cb_4.TabIndex = 41
        '
        'cb_6
        '
        Me.cb_6.FormattingEnabled = True
        Me.cb_6.Location = New System.Drawing.Point(311, 176)
        Me.cb_6.Name = "cb_6"
        Me.cb_6.Size = New System.Drawing.Size(68, 21)
        Me.cb_6.TabIndex = 42
        '
        'cb_5
        '
        Me.cb_5.FormattingEnabled = True
        Me.cb_5.Location = New System.Drawing.Point(311, 127)
        Me.cb_5.Name = "cb_5"
        Me.cb_5.Size = New System.Drawing.Size(68, 21)
        Me.cb_5.TabIndex = 43
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(385, 72)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(43, 26)
        Me.Button1.TabIndex = 44
        Me.Button1.Text = "เลือก"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(385, 175)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(43, 26)
        Me.Button2.TabIndex = 45
        Me.Button2.Text = "เลือก"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(385, 124)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(43, 26)
        Me.Button3.TabIndex = 46
        Me.Button3.Text = "เลือก"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'frm_sale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 425)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.cb_5)
        Me.Controls.Add(Me.cb_6)
        Me.Controls.Add(Me.cb_4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.cb_3)
        Me.Controls.Add(Me.cb_2)
        Me.Controls.Add(Me.cb_1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.btn_dear)
        Me.Controls.Add(Me.btn_change)
        Me.Controls.Add(Me.btn_sum)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.lbl_change)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lbl_total)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_n1)
        Me.Controls.Add(Me.txt_n2)
        Me.Controls.Add(Me.txt_n3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frm_sale"
        Me.Text = "ขายสินค้า"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_n3 As TextBox
    Friend WithEvents txt_n2 As TextBox
    Friend WithEvents txt_n1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lbl_total As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents lbl_change As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents btn_sum As Button
    Friend WithEvents btn_change As Button
    Friend WithEvents btn_dear As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents cb_1 As ComboBox
    Friend WithEvents cb_2 As ComboBox
    Friend WithEvents cb_3 As ComboBox
    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents cb_4 As ComboBox
    Friend WithEvents cb_6 As ComboBox
    Friend WithEvents cb_5 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
