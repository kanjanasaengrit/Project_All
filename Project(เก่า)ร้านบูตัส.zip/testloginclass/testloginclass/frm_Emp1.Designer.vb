﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Emp1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.e1 = New System.Windows.Forms.ToolStripButton()
        Me.e2 = New System.Windows.Forms.ToolStripButton()
        Me.e3 = New System.Windows.Forms.ToolStripButton()
        Me.e4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.e1, Me.ToolStripButton5, Me.e2, Me.e3, Me.e4})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.ToolStrip1.Size = New System.Drawing.Size(765, 108)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'e1
        '
        Me.e1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.e1.Image = Global.testloginclass.My.Resources.Resources._12
        Me.e1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.e1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.e1.Name = "e1"
        Me.e1.Size = New System.Drawing.Size(84, 105)
        Me.e1.Text = "สินค้า"
        Me.e1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'e2
        '
        Me.e2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.e2.Image = Global.testloginclass.My.Resources.Resources.eee
        Me.e2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.e2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.e2.Name = "e2"
        Me.e2.Size = New System.Drawing.Size(101, 105)
        Me.e2.Text = "เพิ่ม/ลบ สินค้า"
        Me.e2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'e3
        '
        Me.e3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.e3.Image = Global.testloginclass.My.Resources.Resources._13
        Me.e3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.e3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.e3.Name = "e3"
        Me.e3.Size = New System.Drawing.Size(88, 105)
        Me.e3.Text = "จัดการลูกค้า"
        Me.e3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'e4
        '
        Me.e4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.e4.Image = Global.testloginclass.My.Resources.Resources._16
        Me.e4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.e4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.e4.Name = "e4"
        Me.e4.Size = New System.Drawing.Size(93, 105)
        Me.e4.Text = "ออกจากระบบ"
        Me.e4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripButton5.Image = Global.testloginclass.My.Resources.Resources._11
        Me.ToolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(84, 105)
        Me.ToolStripButton5.Text = "ขายสินค้า"
        Me.ToolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'frm_Emp1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(765, 519)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "frm_Emp1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "หน้าแรก"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents e1 As ToolStripButton
    Friend WithEvents e2 As ToolStripButton
    Friend WithEvents e3 As ToolStripButton
    Friend WithEvents e4 As ToolStripButton
    Friend WithEvents ToolStripButton5 As ToolStripButton
End Class
