﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Emp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.data_emp = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btn_23 = New System.Windows.Forms.Button()
        Me.txt_d = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txt_id1 = New System.Windows.Forms.TextBox()
        Me.txt_name1 = New System.Windows.Forms.TextBox()
        Me.txt_add = New System.Windows.Forms.TextBox()
        Me.btn_22 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_t = New System.Windows.Forms.TextBox()
        Me.txt_sl = New System.Windows.Forms.TextBox()
        Me.TabPage1.SuspendLayout()
        CType(Me.data_emp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.data_emp)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(664, 382)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "ข้อมูลพนักงาน"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'data_emp
        '
        Me.data_emp.AllowUserToAddRows = False
        Me.data_emp.AllowUserToDeleteRows = False
        Me.data_emp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_emp.Location = New System.Drawing.Point(121, 39)
        Me.data_emp.Name = "data_emp"
        Me.data_emp.ReadOnly = True
        Me.data_emp.Size = New System.Drawing.Size(461, 272)
        Me.data_emp.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txt_d)
        Me.TabPage3.Controls.Add(Me.btn_23)
        Me.TabPage3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(664, 382)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "ลบ"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btn_23
        '
        Me.btn_23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btn_23.Location = New System.Drawing.Point(414, 172)
        Me.btn_23.Name = "btn_23"
        Me.btn_23.Size = New System.Drawing.Size(90, 36)
        Me.btn_23.TabIndex = 0
        Me.btn_23.Text = "ลบ"
        Me.btn_23.UseVisualStyleBackColor = True
        '
        'txt_d
        '
        Me.txt_d.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_d.Location = New System.Drawing.Point(135, 172)
        Me.txt_d.Multiline = True
        Me.txt_d.Name = "txt_d"
        Me.txt_d.Size = New System.Drawing.Size(203, 35)
        Me.txt_d.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.txt_t)
        Me.TabPage2.Controls.Add(Me.txt_sl)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.btn_22)
        Me.TabPage2.Controls.Add(Me.txt_add)
        Me.TabPage2.Controls.Add(Me.txt_name1)
        Me.TabPage2.Controls.Add(Me.txt_id1)
        Me.TabPage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(664, 382)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "เพิ่ม"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txt_id1
        '
        Me.txt_id1.Location = New System.Drawing.Point(262, 27)
        Me.txt_id1.Name = "txt_id1"
        Me.txt_id1.Size = New System.Drawing.Size(156, 26)
        Me.txt_id1.TabIndex = 0
        '
        'txt_name1
        '
        Me.txt_name1.Location = New System.Drawing.Point(262, 71)
        Me.txt_name1.Name = "txt_name1"
        Me.txt_name1.Size = New System.Drawing.Size(156, 26)
        Me.txt_name1.TabIndex = 1
        '
        'txt_add
        '
        Me.txt_add.Location = New System.Drawing.Point(262, 113)
        Me.txt_add.Name = "txt_add"
        Me.txt_add.Size = New System.Drawing.Size(156, 26)
        Me.txt_add.TabIndex = 2
        '
        'btn_22
        '
        Me.btn_22.Location = New System.Drawing.Point(280, 270)
        Me.btn_22.Name = "btn_22"
        Me.btn_22.Size = New System.Drawing.Size(86, 30)
        Me.btn_22.TabIndex = 6
        Me.btn_22.Text = "เพิ่ม"
        Me.btn_22.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(98, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 20)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "รหัสพนักงาน"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(98, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 20)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "ชื่อพนักงาน"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(98, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 20)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "ที่อยู่"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(37, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(672, 408)
        Me.TabControl1.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(98, 199)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "เบอร์โทรศัพท์"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(98, 154)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 20)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "เงินเดือน"
        '
        'txt_t
        '
        Me.txt_t.Location = New System.Drawing.Point(262, 196)
        Me.txt_t.Name = "txt_t"
        Me.txt_t.Size = New System.Drawing.Size(156, 26)
        Me.txt_t.TabIndex = 11
        '
        'txt_sl
        '
        Me.txt_sl.Location = New System.Drawing.Point(262, 154)
        Me.txt_sl.Name = "txt_sl"
        Me.txt_sl.Size = New System.Drawing.Size(156, 26)
        Me.txt_sl.TabIndex = 10
        '
        'frm_Emp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(737, 423)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frm_Emp"
        Me.Text = "จัดการพนักงาน"
        Me.TabPage1.ResumeLayout(False)
        CType(Me.data_emp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents data_emp As DataGridView
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents txt_d As TextBox
    Friend WithEvents btn_23 As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_22 As Button
    Friend WithEvents txt_add As TextBox
    Friend WithEvents txt_name1 As TextBox
    Friend WithEvents txt_id1 As TextBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_t As TextBox
    Friend WithEvents txt_sl As TextBox
End Class
