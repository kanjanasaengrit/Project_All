﻿Imports System.Data.Linq
Public Class UpdateSubjForm
    Dim db As New DataClassesStudentDataContext()

    Private Sub UpdateSubjForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim query_subj_id = From subj1 In db.Subjects
                            Select subj1.subj_id

        Combo_subj.DataSource = query_subj_id.ToList
        Combo_subj.DisplayMember = "subj_id"

        'ดึงรหัสวิชามาใส่ใน combobox
    End Sub

    Private Sub ComboBoxSubj(sender As Object, e As EventArgs) Handles Combo_subj.SelectionChangeCommitted
        Dim query_subj = From subj1 In db.Subjects Where subj1.subj_id = Combo_subj.SelectedValue.ToString()
                         Select subj1.subj_name

        Txt_subj_name.Text = query_subj.FirstOrDefault()
        'ดึงชื่อที่ตรงกับรายการ
        Dim query_subj_unit = From subj1 In db.Subjects Where subj1.subj_id = Combo_subj.SelectedValue.ToString()
                              Select subj1.unit

        Txt_subj_unit.Text = query_subj_unit.FirstOrDefault()
        'ดึงหน่วยกิตที่ตรงกับรายการ
        'เมื่อมีการเลือกรายการใน combobox จะเอาข้อมูลมาแสดงตาม Textbox แต่ละช่อง
    End Sub

    Private Sub Bt_updateSubj_Click(sender As Object, e As EventArgs) Handles Bt_updateSubj.Click

        Dim query = (From e1 In db.Subjects
                     Where e1.subj_id = Combo_subj.SelectedValue.ToString()
                     Select e1).SingleOrDefault

        query.subj_id = Combo_subj.SelectedValue.ToString()
        query.subj_name = Txt_subj_name.Text
        query.unit = Txt_subj_unit.Text
        'อัพเดทข้อมูลโดยการให้แต่ละคอลัมน์มันเท่ากับอะไรใน Textbox
        Try
            db.SubmitChanges()
        Catch er As Exception
            MessageBox.Show("กรุณากรอกข้อมูลใหม่อีกครั้ง " + ControlChars.CrLf + "แจ้งข้อความผิดพลาด: " + er.Message, "ผิดพลาด", MessageBoxButtons.OK, MessageBoxIcon.Error)
            db.Subjects.DeleteOnSubmit(query)
            Exit Sub
        End Try

        MessageBox.Show("แก้ไขข้อมูลเรียบร้อย", "ผลการดำเนินการ")
        Me.Close()
        Form1.show_data()
    End Sub
End Class