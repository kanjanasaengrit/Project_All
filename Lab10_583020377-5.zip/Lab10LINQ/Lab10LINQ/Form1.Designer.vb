﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Combo_name = New System.Windows.Forms.ComboBox()
        Me.Bt_show = New System.Windows.Forms.Button()
        Me.DataGridViewEnroll = New System.Windows.Forms.DataGridView()
        Me.Bt_Delete = New System.Windows.Forms.Button()
        Me.Bt_Insert = New System.Windows.Forms.Button()
        Me.Bt_Update = New System.Windows.Forms.Button()
        CType(Me.DataGridViewEnroll, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(119, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ขื่อนักศึกษา"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 132)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "ข้อมูลการลงทะเบียน"
        '
        'Combo_name
        '
        Me.Combo_name.FormattingEnabled = True
        Me.Combo_name.Location = New System.Drawing.Point(267, 26)
        Me.Combo_name.Name = "Combo_name"
        Me.Combo_name.Size = New System.Drawing.Size(182, 21)
        Me.Combo_name.TabIndex = 2
        '
        'Bt_show
        '
        Me.Bt_show.Location = New System.Drawing.Point(504, 20)
        Me.Bt_show.Name = "Bt_show"
        Me.Bt_show.Size = New System.Drawing.Size(94, 31)
        Me.Bt_show.TabIndex = 3
        Me.Bt_show.Text = "แสดงข้อมูล"
        Me.Bt_show.UseVisualStyleBackColor = True
        '
        'DataGridViewEnroll
        '
        Me.DataGridViewEnroll.AllowUserToOrderColumns = True
        Me.DataGridViewEnroll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewEnroll.Location = New System.Drawing.Point(74, 170)
        Me.DataGridViewEnroll.Name = "DataGridViewEnroll"
        Me.DataGridViewEnroll.Size = New System.Drawing.Size(620, 190)
        Me.DataGridViewEnroll.TabIndex = 4
        '
        'Bt_Delete
        '
        Me.Bt_Delete.Location = New System.Drawing.Point(109, 411)
        Me.Bt_Delete.Name = "Bt_Delete"
        Me.Bt_Delete.Size = New System.Drawing.Size(146, 33)
        Me.Bt_Delete.TabIndex = 5
        Me.Bt_Delete.Text = "ลบข้อมูลลงทะเบียน"
        Me.Bt_Delete.UseVisualStyleBackColor = True
        '
        'Bt_Insert
        '
        Me.Bt_Insert.Location = New System.Drawing.Point(322, 411)
        Me.Bt_Insert.Name = "Bt_Insert"
        Me.Bt_Insert.Size = New System.Drawing.Size(146, 31)
        Me.Bt_Insert.TabIndex = 6
        Me.Bt_Insert.Text = "เพิ่มข้อมูลลงทะเบียน"
        Me.Bt_Insert.UseVisualStyleBackColor = True
        '
        'Bt_Update
        '
        Me.Bt_Update.Location = New System.Drawing.Point(530, 410)
        Me.Bt_Update.Name = "Bt_Update"
        Me.Bt_Update.Size = New System.Drawing.Size(146, 32)
        Me.Bt_Update.TabIndex = 7
        Me.Bt_Update.Text = "แก้ไขรายวิชา"
        Me.Bt_Update.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(801, 489)
        Me.Controls.Add(Me.Bt_Update)
        Me.Controls.Add(Me.Bt_Insert)
        Me.Controls.Add(Me.Bt_Delete)
        Me.Controls.Add(Me.DataGridViewEnroll)
        Me.Controls.Add(Me.Bt_show)
        Me.Controls.Add(Me.Combo_name)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "การลงทะเบียน"
        CType(Me.DataGridViewEnroll, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Combo_name As System.Windows.Forms.ComboBox
    Friend WithEvents Bt_show As System.Windows.Forms.Button
    Friend WithEvents DataGridViewEnroll As System.Windows.Forms.DataGridView
    Friend WithEvents Bt_Delete As System.Windows.Forms.Button
    Friend WithEvents Bt_Insert As System.Windows.Forms.Button
    Friend WithEvents Bt_Update As System.Windows.Forms.Button

End Class
