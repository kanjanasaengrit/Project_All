﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InsertForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Combo_name = New System.Windows.Forms.ComboBox()
        Me.Combo_subj = New System.Windows.Forms.ComboBox()
        Me.NumericUpDown_term = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_year = New System.Windows.Forms.NumericUpDown()
        Me.Bt_insert = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.NumericUpDown_term, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_year, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Combo_name
        '
        Me.Combo_name.FormattingEnabled = True
        Me.Combo_name.Location = New System.Drawing.Point(175, 52)
        Me.Combo_name.Name = "Combo_name"
        Me.Combo_name.Size = New System.Drawing.Size(173, 21)
        Me.Combo_name.TabIndex = 0
        '
        'Combo_subj
        '
        Me.Combo_subj.FormattingEnabled = True
        Me.Combo_subj.Location = New System.Drawing.Point(175, 98)
        Me.Combo_subj.Name = "Combo_subj"
        Me.Combo_subj.Size = New System.Drawing.Size(173, 21)
        Me.Combo_subj.TabIndex = 1
        '
        'NumericUpDown_term
        '
        Me.NumericUpDown_term.Location = New System.Drawing.Point(175, 148)
        Me.NumericUpDown_term.Name = "NumericUpDown_term"
        Me.NumericUpDown_term.Size = New System.Drawing.Size(81, 20)
        Me.NumericUpDown_term.TabIndex = 2
        '
        'NumericUpDown_year
        '
        Me.NumericUpDown_year.Location = New System.Drawing.Point(175, 200)
        Me.NumericUpDown_year.Name = "NumericUpDown_year"
        Me.NumericUpDown_year.Size = New System.Drawing.Size(81, 20)
        Me.NumericUpDown_year.TabIndex = 3
        '
        'Bt_insert
        '
        Me.Bt_insert.Location = New System.Drawing.Point(174, 267)
        Me.Bt_insert.Name = "Bt_insert"
        Me.Bt_insert.Size = New System.Drawing.Size(121, 35)
        Me.Bt_insert.TabIndex = 4
        Me.Bt_insert.Text = "เพิ่มข้อมูลการลงทะเบียน"
        Me.Bt_insert.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "ชื่อนักศึกษา"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "รายวิชา"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "เทอม"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(40, 200)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "ปีการศึกษา"
        '
        'InsertForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 323)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Bt_insert)
        Me.Controls.Add(Me.NumericUpDown_year)
        Me.Controls.Add(Me.NumericUpDown_term)
        Me.Controls.Add(Me.Combo_subj)
        Me.Controls.Add(Me.Combo_name)
        Me.Name = "InsertForm"
        Me.Text = "เพิ่มข้อมูลการลงทะเบียน"
        CType(Me.NumericUpDown_term, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_year, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Combo_name As System.Windows.Forms.ComboBox
    Friend WithEvents Combo_subj As System.Windows.Forms.ComboBox
    Friend WithEvents NumericUpDown_term As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_year As System.Windows.Forms.NumericUpDown
    Friend WithEvents Bt_insert As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
