﻿Public Class Form2
    Dim MyCicle As Cicle_class
    Private Sub btn_cicle_Click(sender As Object, e As EventArgs) Handles btn_cicle.Click
        MyCicle = New Cicle_class()
        MyCicle.myradius = txtB_cicle.Text
        Lb_cicle_area.Text = "Area :" + CStr(MyCicle.Area())
        Lb_cicle_perimeter.Text = "Perimeter :" + CStr(MyCicle.Perimeter())
        MyCicle.Draw_Cicle()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_edit_cicle_Click(sender As Object, e As EventArgs) Handles btn_edit_cicle.Click
        MyCicle.Clear_Cicle()
        MyCicle.myradius = txtB_cicle.Text
        Lb_cicle_area.Text = "Area :" + CStr(MyCicle.Area())
        Lb_cicle_perimeter.Text = "Perimeter :" + CStr(MyCicle.Perimeter())
        MyCicle.Draw_Cicle()
    End Sub
End Class