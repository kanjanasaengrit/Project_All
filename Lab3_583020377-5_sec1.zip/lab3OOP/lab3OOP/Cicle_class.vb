﻿Public Class Cicle_class
    Dim Pi As Double = 3.14
    Private radius As Double
    Public Property myradius() As String
        Get
            Return radius
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                radius = value
            Else
                MessageBox.Show("Radius Value is 0", "Error!!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                radius = 0
            End If
        End Set
    End Property

    Public Function Area() As Double
        Dim area_Cicle As Double
        area_Cicle = Pi * (radius ^ 2)
        Return area_Cicle
    End Function

    Public Function Perimeter() As Double
        Dim Perimeter_Cicle As Double
        Perimeter_Cicle = 2 * Pi * radius
        Return Perimeter_Cicle
    End Function

    Public Sub Draw_Cicle()
        Dim g_Draw As Graphics = Form2.CreateGraphics
        Dim Pen As Pen = New Pen(Color.Red, 3)
        g_Draw.DrawEllipse(Pen, 20, 20, Convert.ToInt32(myradius), Convert.ToInt32(myradius))

    End Sub

    Public Sub Clear_Cicle()
        Dim g_Clear As Graphics = Form2.CreateGraphics
        Dim Pen As Pen = New Pen(Color.FromArgb(Form2.BackColor.ToArgb), 3)
        g_Clear.DrawEllipse(Pen, 20, 20, Convert.ToInt32(myradius), Convert.ToInt32(myradius))

    End Sub

End Class
