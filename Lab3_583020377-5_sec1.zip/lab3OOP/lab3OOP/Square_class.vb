﻿Public Class Square_class
    Private width As Double
    Public Property mywidth() As String
        Get
            Return width
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value <> String.Empty And IsNumeric(value) Then
                width = value
            Else
                MessageBox.Show("Width Value is 0", "Error!!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                width = 0
            End If
        End Set
    End Property

    Public Function Area(ByVal w As Double) As Double
        Dim area_Square As Double
        area_Square = w + w
        Return area_Square
    End Function

    Public Function Perimeter() As Double
        Dim Perimeter_Square As Double
        Perimeter_Square = (4 * width)
        Return Perimeter_Square
    End Function

    Public Sub Draw_square()
        Dim g_Draw As Graphics = Form1.CreateGraphics
        Dim Pen As Pen = New Pen(Color.Red, 3)
        g_Draw.DrawRectangle(Pen, 20, 20, Convert.ToInt32(mywidth), Convert.ToInt32(mywidth))

    End Sub

    Public Sub Clear_square()
        Dim g_Clear As Graphics = Form1.CreateGraphics
        Dim Pen As Pen = New Pen(Color.FromArgb(Form1.BackColor.ToArgb), 3)
        g_Clear.DrawRectangle(Pen, 20, 20, Convert.ToInt32(mywidth), Convert.ToInt32(mywidth))

    End Sub




End Class
