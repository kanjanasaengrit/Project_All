﻿Public Class Main

    Private Sub CalMatixToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalMatixToolStripMenuItem.Click
        Form1.MdiParent = Me
        Form1.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub
End Class
