﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtB_A1 = New System.Windows.Forms.TextBox()
        Me.TxtB_A2 = New System.Windows.Forms.TextBox()
        Me.TxtB_A3 = New System.Windows.Forms.TextBox()
        Me.TxtB_A4 = New System.Windows.Forms.TextBox()
        Me.TxtB_A5 = New System.Windows.Forms.TextBox()
        Me.TxtB_A6 = New System.Windows.Forms.TextBox()
        Me.TxtB_A7 = New System.Windows.Forms.TextBox()
        Me.TxtB_A8 = New System.Windows.Forms.TextBox()
        Me.TxtB_A9 = New System.Windows.Forms.TextBox()
        Me.TxtB_B1 = New System.Windows.Forms.TextBox()
        Me.TxtB_B2 = New System.Windows.Forms.TextBox()
        Me.TxtB_B3 = New System.Windows.Forms.TextBox()
        Me.TxtB_B4 = New System.Windows.Forms.TextBox()
        Me.TxtB_B5 = New System.Windows.Forms.TextBox()
        Me.TxtB_B6 = New System.Windows.Forms.TextBox()
        Me.TxtB_B7 = New System.Windows.Forms.TextBox()
        Me.TxtB_B8 = New System.Windows.Forms.TextBox()
        Me.TxtB_B9 = New System.Windows.Forms.TextBox()
        Me.RadioBtn_add = New System.Windows.Forms.RadioButton()
        Me.RadioBtn_sub = New System.Windows.Forms.RadioButton()
        Me.btn_max = New System.Windows.Forms.Button()
        Me.btn_min = New System.Windows.Forms.Button()
        Me.btn_calculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(103, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Matix A"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.Location = New System.Drawing.Point(385, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Matix B"
        '
        'TxtB_A1
        '
        Me.TxtB_A1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A1.Location = New System.Drawing.Point(51, 59)
        Me.TxtB_A1.Multiline = True
        Me.TxtB_A1.Name = "TxtB_A1"
        Me.TxtB_A1.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A1.TabIndex = 2
        Me.TxtB_A1.Text = "1"
        Me.TxtB_A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A2
        '
        Me.TxtB_A2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A2.Location = New System.Drawing.Point(107, 59)
        Me.TxtB_A2.Multiline = True
        Me.TxtB_A2.Name = "TxtB_A2"
        Me.TxtB_A2.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A2.TabIndex = 3
        Me.TxtB_A2.Text = "2"
        Me.TxtB_A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A3
        '
        Me.TxtB_A3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A3.Location = New System.Drawing.Point(167, 59)
        Me.TxtB_A3.Multiline = True
        Me.TxtB_A3.Name = "TxtB_A3"
        Me.TxtB_A3.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A3.TabIndex = 4
        Me.TxtB_A3.Text = "3"
        Me.TxtB_A3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A4
        '
        Me.TxtB_A4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A4.Location = New System.Drawing.Point(51, 104)
        Me.TxtB_A4.Multiline = True
        Me.TxtB_A4.Name = "TxtB_A4"
        Me.TxtB_A4.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A4.TabIndex = 5
        Me.TxtB_A4.Text = "4"
        Me.TxtB_A4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A5
        '
        Me.TxtB_A5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A5.Location = New System.Drawing.Point(107, 104)
        Me.TxtB_A5.Multiline = True
        Me.TxtB_A5.Name = "TxtB_A5"
        Me.TxtB_A5.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A5.TabIndex = 6
        Me.TxtB_A5.Text = "5"
        Me.TxtB_A5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A6
        '
        Me.TxtB_A6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A6.Location = New System.Drawing.Point(167, 104)
        Me.TxtB_A6.Multiline = True
        Me.TxtB_A6.Name = "TxtB_A6"
        Me.TxtB_A6.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A6.TabIndex = 7
        Me.TxtB_A6.Text = "6"
        Me.TxtB_A6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A7
        '
        Me.TxtB_A7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A7.Location = New System.Drawing.Point(51, 150)
        Me.TxtB_A7.Multiline = True
        Me.TxtB_A7.Name = "TxtB_A7"
        Me.TxtB_A7.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A7.TabIndex = 8
        Me.TxtB_A7.Text = "7"
        Me.TxtB_A7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A8
        '
        Me.TxtB_A8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A8.Location = New System.Drawing.Point(107, 150)
        Me.TxtB_A8.Multiline = True
        Me.TxtB_A8.Name = "TxtB_A8"
        Me.TxtB_A8.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A8.TabIndex = 9
        Me.TxtB_A8.Text = "8"
        Me.TxtB_A8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_A9
        '
        Me.TxtB_A9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_A9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_A9.Location = New System.Drawing.Point(167, 150)
        Me.TxtB_A9.Multiline = True
        Me.TxtB_A9.Name = "TxtB_A9"
        Me.TxtB_A9.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_A9.TabIndex = 10
        Me.TxtB_A9.Text = "9"
        Me.TxtB_A9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B1
        '
        Me.TxtB_B1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B1.Location = New System.Drawing.Point(330, 59)
        Me.TxtB_B1.Multiline = True
        Me.TxtB_B1.Name = "TxtB_B1"
        Me.TxtB_B1.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B1.TabIndex = 11
        Me.TxtB_B1.Text = "1"
        Me.TxtB_B1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B2
        '
        Me.TxtB_B2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B2.Location = New System.Drawing.Point(389, 59)
        Me.TxtB_B2.Multiline = True
        Me.TxtB_B2.Name = "TxtB_B2"
        Me.TxtB_B2.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B2.TabIndex = 12
        Me.TxtB_B2.Text = "2"
        Me.TxtB_B2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B3
        '
        Me.TxtB_B3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B3.Location = New System.Drawing.Point(450, 59)
        Me.TxtB_B3.Multiline = True
        Me.TxtB_B3.Name = "TxtB_B3"
        Me.TxtB_B3.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B3.TabIndex = 13
        Me.TxtB_B3.Text = "3"
        Me.TxtB_B3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B4
        '
        Me.TxtB_B4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B4.Location = New System.Drawing.Point(330, 104)
        Me.TxtB_B4.Multiline = True
        Me.TxtB_B4.Name = "TxtB_B4"
        Me.TxtB_B4.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B4.TabIndex = 14
        Me.TxtB_B4.Text = "4"
        Me.TxtB_B4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B5
        '
        Me.TxtB_B5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B5.Location = New System.Drawing.Point(389, 104)
        Me.TxtB_B5.Multiline = True
        Me.TxtB_B5.Name = "TxtB_B5"
        Me.TxtB_B5.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B5.TabIndex = 15
        Me.TxtB_B5.Text = "5"
        Me.TxtB_B5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B6
        '
        Me.TxtB_B6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B6.Location = New System.Drawing.Point(450, 104)
        Me.TxtB_B6.Multiline = True
        Me.TxtB_B6.Name = "TxtB_B6"
        Me.TxtB_B6.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B6.TabIndex = 16
        Me.TxtB_B6.Text = "6"
        Me.TxtB_B6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B7
        '
        Me.TxtB_B7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B7.Location = New System.Drawing.Point(330, 150)
        Me.TxtB_B7.Multiline = True
        Me.TxtB_B7.Name = "TxtB_B7"
        Me.TxtB_B7.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B7.TabIndex = 17
        Me.TxtB_B7.Text = "7"
        Me.TxtB_B7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B8
        '
        Me.TxtB_B8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B8.Location = New System.Drawing.Point(389, 150)
        Me.TxtB_B8.Multiline = True
        Me.TxtB_B8.Name = "TxtB_B8"
        Me.TxtB_B8.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B8.TabIndex = 18
        Me.TxtB_B8.Text = "8"
        Me.TxtB_B8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtB_B9
        '
        Me.TxtB_B9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TxtB_B9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TxtB_B9.Location = New System.Drawing.Point(450, 150)
        Me.TxtB_B9.Multiline = True
        Me.TxtB_B9.Name = "TxtB_B9"
        Me.TxtB_B9.Size = New System.Drawing.Size(45, 29)
        Me.TxtB_B9.TabIndex = 19
        Me.TxtB_B9.Text = "9"
        Me.TxtB_B9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RadioBtn_add
        '
        Me.RadioBtn_add.AutoSize = True
        Me.RadioBtn_add.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RadioBtn_add.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RadioBtn_add.Location = New System.Drawing.Point(235, 87)
        Me.RadioBtn_add.Name = "RadioBtn_add"
        Me.RadioBtn_add.Size = New System.Drawing.Size(34, 20)
        Me.RadioBtn_add.TabIndex = 20
        Me.RadioBtn_add.TabStop = True
        Me.RadioBtn_add.Text = "+"
        Me.RadioBtn_add.UseVisualStyleBackColor = False
        '
        'RadioBtn_sub
        '
        Me.RadioBtn_sub.AutoSize = True
        Me.RadioBtn_sub.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RadioBtn_sub.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RadioBtn_sub.Location = New System.Drawing.Point(238, 128)
        Me.RadioBtn_sub.Name = "RadioBtn_sub"
        Me.RadioBtn_sub.Size = New System.Drawing.Size(31, 20)
        Me.RadioBtn_sub.TabIndex = 21
        Me.RadioBtn_sub.TabStop = True
        Me.RadioBtn_sub.Text = "-"
        Me.RadioBtn_sub.UseVisualStyleBackColor = False
        '
        'btn_max
        '
        Me.btn_max.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_max.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btn_max.Location = New System.Drawing.Point(51, 221)
        Me.btn_max.Name = "btn_max"
        Me.btn_max.Size = New System.Drawing.Size(161, 34)
        Me.btn_max.TabIndex = 22
        Me.btn_max.Text = "Max of Matix A and B"
        Me.btn_max.UseVisualStyleBackColor = False
        '
        'btn_min
        '
        Me.btn_min.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_min.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btn_min.Location = New System.Drawing.Point(330, 221)
        Me.btn_min.Name = "btn_min"
        Me.btn_min.Size = New System.Drawing.Size(165, 34)
        Me.btn_min.TabIndex = 23
        Me.btn_min.Text = "Min of Matix A and B"
        Me.btn_min.UseVisualStyleBackColor = False
        '
        'btn_calculate
        '
        Me.btn_calculate.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_calculate.Location = New System.Drawing.Point(539, 104)
        Me.btn_calculate.Name = "btn_calculate"
        Me.btn_calculate.Size = New System.Drawing.Size(89, 29)
        Me.btn_calculate.TabIndex = 24
        Me.btn_calculate.Text = "Calculate"
        Me.btn_calculate.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(640, 309)
        Me.Controls.Add(Me.btn_calculate)
        Me.Controls.Add(Me.btn_min)
        Me.Controls.Add(Me.btn_max)
        Me.Controls.Add(Me.RadioBtn_sub)
        Me.Controls.Add(Me.RadioBtn_add)
        Me.Controls.Add(Me.TxtB_B9)
        Me.Controls.Add(Me.TxtB_B8)
        Me.Controls.Add(Me.TxtB_B7)
        Me.Controls.Add(Me.TxtB_B6)
        Me.Controls.Add(Me.TxtB_B5)
        Me.Controls.Add(Me.TxtB_B4)
        Me.Controls.Add(Me.TxtB_B3)
        Me.Controls.Add(Me.TxtB_B2)
        Me.Controls.Add(Me.TxtB_B1)
        Me.Controls.Add(Me.TxtB_A9)
        Me.Controls.Add(Me.TxtB_A8)
        Me.Controls.Add(Me.TxtB_A7)
        Me.Controls.Add(Me.TxtB_A6)
        Me.Controls.Add(Me.TxtB_A5)
        Me.Controls.Add(Me.TxtB_A4)
        Me.Controls.Add(Me.TxtB_A3)
        Me.Controls.Add(Me.TxtB_A2)
        Me.Controls.Add(Me.TxtB_A1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtB_A1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A3 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A4 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A5 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A6 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A7 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A8 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_A9 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B3 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B4 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B5 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B6 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B7 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B8 As System.Windows.Forms.TextBox
    Friend WithEvents TxtB_B9 As System.Windows.Forms.TextBox
    Friend WithEvents RadioBtn_add As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn_sub As System.Windows.Forms.RadioButton
    Friend WithEvents btn_max As System.Windows.Forms.Button
    Friend WithEvents btn_min As System.Windows.Forms.Button
    Friend WithEvents btn_calculate As System.Windows.Forms.Button
End Class
