﻿Imports System.Data.SqlClient
Public Class Edit_Cus
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)

    Private Sub Edit_Cus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        'Dim Str As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
        'Dim com As New SqlCommand(Str, connection)
        'Dim dr As SqlDataReader = com.ExecuteReader()

        'Dim comboSource As New Dictionary(Of String, String)()
        'comboSource.Add(0, "--เลือกประเภทสินค้า--")
        'If dr.HasRows Then
        'While dr.Read
        'comboSource.Add(dr.Item(0), dr.Item(1))
        'End While
        'dr.Close()
        'End If
        'TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        'TxtMajor.DisplayMember = "Value"
        'TxtMajor.ValueMember = "Key"

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim str As String
        str = "update customer set cus_name = '" + Txtname_up.Text + "', cus_tel = '" + Txtamount_up.Text + "'"
        str &= " where cus_id = '" + TxtSearch.Text + "';"

        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("แก้ไขข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form_Customer.show_data()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str As String
        str = "select * from customer where cus_id = '" + TxtSearch.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read

                Txtid_up.Text = dr.Item(0)
                Txtname_up.Text = dr.Item(1)
                Txtamount_up.Text = dr.Item(2)
                'Txtmajor_up.SelectedIndex = dr.Item(3)
                'Txtstatus_up.Text = dr.Item(3)
                'Txtexp_up.Text = dr.Item(4)
                'Txtprice1_up.Text = dr.Item(5)

            End While
        Else
            MessageBox.Show("ไม่มีข้อมูล", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        dr.Close()
        'Dim selec As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
        'Dim cmd2 = New SqlClient.SqlCommand(selec, connection)
        'Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        'Dim comboSource As New Dictionary(Of String, String)()
        'comboSource.Add(0, "--เลือกประเภทสินค้า--")
        'If dr2.HasRows Then
        'While dr2.Read
        'comboSource.Add(dr2.Item(0), dr2.Item(1))
        'End While
        'dr2.Close()
        'End If
        ''TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        'TxtMajor.DisplayMember = "Value"
        'TxtMajor.ValueMember = "Key"
    End Sub


End Class