﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Form_Bill
    Dim strConn As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim objConn As New SqlConnection(strConn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Friend cmd As New SqlCommand
    Friend Str As String

    Dim strcell As String

    'Private Property DataKeyNames As String

    Public Sub show_data()
        Dim Strquery As String
        Strquery = "Select Bill.Bill_id,Bill.Bill_No,Product.product_name,Product.product_amount,Product.price_1,Bill.Pro_am,Bill.Price_Am,customer.cus_name From Bill INNER JOIN customer ON(Bill.cus_id=customer.cus_id) INNER JOIN Product ON(Bill.product_id=Product.product_id);"
        da = New SqlDataAdapter(Strquery, objConn)
        ds = New DataSet
        da.Fill(ds, "bill_TB")
        DataGrid_Bill.DataMember = "bill_TB"
        DataGrid_Bill.DataSource = ds

    End Sub
    Private Sub Form_Bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If objConn.State = ConnectionState.Closed Then
            objConn.Open()
            'MessageBox.Show("Sql Connent")
        End If
        txtStdID.Text = ""
        txtName.Text = ""
        show_data()
        DataGrid_Bill.Columns(0).HeaderText = "รหัสรายการสั่งซื้อ"
        DataGrid_Bill.Columns(1).HeaderText = "ลำดับที่"
        DataGrid_Bill.Columns(2).HeaderText = "ชื่อสินค้า"
        DataGrid_Bill.Columns(3).HeaderText = "จำนวน"
        DataGrid_Bill.Columns(4).HeaderText = "ราคาขายต่อชิ้น"
        DataGrid_Bill.Columns(5).HeaderText = "จำนวนที่สั่งซื้อ"
        DataGrid_Bill.Columns(6).HeaderText = "ราคารวม"
        DataGrid_Bill.Columns(7).HeaderText = "ชื่อลูกค้า"
    End Sub

    'Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
    'FormReport.Show()
    'End Sub

    'Private Sub btnInsert_Click(sender As Object, e As EventArgs)

    'End Sub

    ' Private Sub btnUpdate_Click(sender As Object, e As EventArgs)

    'End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim Strq As String
        Strq = "select * from Bill"
        If txtStdID.Text <> "" Then
            Strq = "select * from Bill WHERE Bill_id like '%" + txtStdID.Text + "%';"
        End If
        'If Txt_emp.Text <> "" Then
        'Strq = "select * from Bill  WHERE Emp_id like '%" + txtName.Text + "%';"
        'End If
        da = New SqlDataAdapter(Strq, objConn)
        ds = New DataSet
        da.Fill(ds, "bill_TB")
        DataGrid_Bill.DataMember = "bill_TB"
        DataGrid_Bill.DataSource = ds
        DataGrid_Bill.Columns(0).HeaderText = "เลขที่ใบเสร็จ"
        DataGrid_Bill.Columns(1).HeaderText = "ลำดับที่"
        DataGrid_Bill.Columns(2).HeaderText = "จำนวนที่สั่งซื้อ"
        DataGrid_Bill.Columns(3).HeaderText = "ราคารวม"
        DataGrid_Bill.Columns(4).HeaderText = "รหัสสินค้า"
        DataGrid_Bill.Columns(5).HeaderText = "รหัสลูกค้า"

    End Sub

    ' Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
    'strcell = DataGridView1.Rows.Item(e.RowIndex).Cells(0).Value.ToString
    'End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim str As String
        str = "delete Bill where Bill_id = '" + txtStdID.Text + "';"
        MessageBox.Show(str)
        Dim cmd = New SqlClient.SqlCommand(str, objConn)
        cmd.ExecuteNonQuery()
        MessageBox.Show("ลบข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
    End Sub




    Private Sub Data_Bill(sender As Object, e As DataGridViewCellEventArgs) Handles DataGrid_Bill.CellClick
        strcell = DataGrid_Bill.Rows.Item(e.RowIndex).Cells(0).Value.ToString()
        'Dim i As Integer = DataGrid_Bill.CurrentRow.Index
        'Dim amount As Integer = DataGrid_Bill.Item(3, i).Value
        'num_exit.Maximum = amount
    End Sub

    'Private Sub btnInsert_Click(sender As Object, e As EventArgs)

    'End Sub

    'Private Sub btnUpdate_Click(sender As Object, e As EventArgs)

    'End Sub

    Private Sub btnInsert_Click_1(sender As Object, e As EventArgs) Handles btnInsert.Click
        Insert_Bill.Show()
    End Sub

    'Private Sub btnUpdate_Click_1(sender As Object, e As EventArgs) Handles btnUpdate.Click
    '    Edit_Bill.Show()
    'End Sub

    'Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim Str As String = "update Product set product_amount=product_amount-" & num_exit.Value & "where product_id='" &
    '    DataGrid_Bill.Item(0, DataGrid_Bill.CurrentRow.Index).Value & "'"
    '    cmd = New SqlCommand(Str, objConn)
    '    If cmd.ExecuteNonQuery = 0 Then
    '        MsgBox("ผิดพลาด")
    '    Else
    '        MsgBox("สำเร็จ")
    '    End If
    '    keep_log("Exit")
    'End Sub
    'Friend Sub keep_log(log_work As String)
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim i As Integer = DataGrid_Bill.CurrentRow.Index
    '    Dim product_id As String = DataGrid_Bill.Item(, i).Value
    '    Dim product_amount As Integer
    '    If log_work = "Exit" Then
    '        product_amount = num_exit.Value
    '    Else
    '        product_amount = num_enter.Value
    '    End If

    '    Str = "insert into Log_product(log_product_id, log_amount, log_work) values(" &
    '        "'" & product_id & "','" & product_amount & "','" & log_work & "')"
    '    cmd = New SqlCommand(Str, objConn)
    '    cmd.ExecuteNonQuery()
    'End Sub

    'Friend Sub load_log()
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim i As Integer = DataGrid_Bill.CurrentRow.Index
    '    Dim product_id As String = DataGrid_Bill.Item(0, i).Value
    '    Str = "select * from Log_product where log_product_id='" & product_id & "'"
    '    da = New SqlDataAdapter(Str, objConn)
    '    Ds = New DataSet
    '    DA.Fill(Ds, "table")
    '    DataGridView2.DataSource = Ds.Tables("table")
    'End Sub

    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Str = "update product set product_amount=product_amount+" & num_enter.Value & "where product_id='" &
    '        DataGrid_Bill.Item(0, DataGrid_Bill.CurrentRow.Index).Value & "'"
    '    cmd = New SqlCommand(Str, objConn)
    '    If cmd.ExecuteNonQuery = 0 Then
    '        MsgBox("ผิดพลาด")
    '    Else
    '        MsgBox("สำเร็จ")

    '        keep_log("Enter")
    '        'load_product()
    '        'alert_product()
    '        'load_custom_alert()

    '    End If
    'End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Edit_Bill.Show()
    End Sub

    'Private Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
    '    Form_Report.Show()

    'End Sub
End Class