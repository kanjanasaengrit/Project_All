﻿Imports CrystalDecisions.CrystalReports.Engine

Public Class Form_Report

    Private Sub Form_Report_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        Dim rpt As New ReportDocument()
        Dim directory As String = My.Application.Info.DirectoryPath
        rpt.Load("D:\database_app\Lab8_583020377-5\Lab8_583020377-5\Bill_Re.rpt")
        'rpt.Load("D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport2.rpt")
        'D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport2.rpt
        rpt.SetParameterValue("cus", TextBox1.Text)
        Me.CrystalReportViewer1.ReportSource = rpt
        Me.CrystalReportViewer1.Refresh()
    End Sub

    Private Sub BillReportViewer_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Re_Bill1_InitReport(sender As Object, e As EventArgs)

    End Sub
End Class