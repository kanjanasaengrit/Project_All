﻿Imports System.Data.SqlClient
Public Class Insert_Cus
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        Dim str As String

        str = "insert into customer values('" + TxtldStudent.Text + "','" + TxtName.Text + "','" + Txtlastname.Text + "' );"

        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("เพิ่มข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        connection.Close()
        Form_Customer.show_data()
        Me.Close()
    End Sub

    'Private Sub InsertForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    If connection.State = ConnectionState.Closed Then
    '        connection.Open()
    '    End If

    '    Dim Str As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
    '    Dim com As New SqlCommand(Str, connection)
    '    Dim dr As SqlDataReader = com.ExecuteReader()

    '    Dim comboSource As New Dictionary(Of String, String)()
    '    comboSource.Add(0, "--เลือกประเภทสินค้า--")
    '    If dr.HasRows Then
    '        While dr.Read
    '            comboSource.Add(dr.Item(0), dr.Item(1))
    '        End While
    '        dr.Close()
    '    End If
    '    TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
    '    TxtMajor.DisplayMember = "Value"
    '    TxtMajor.ValueMember = "Key"
    'End Sub


End Class