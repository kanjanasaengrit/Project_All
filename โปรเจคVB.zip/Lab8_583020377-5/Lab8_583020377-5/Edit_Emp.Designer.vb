﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Edit_Emp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtamount_up = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txtstatus_up = New System.Windows.Forms.TextBox()
        Me.Txtprice1_up = New System.Windows.Forms.TextBox()
        Me.Txtexp_up = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Txtname_up = New System.Windows.Forms.TextBox()
        Me.Txtid_up = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Txtamount_up
        '
        Me.Txtamount_up.Location = New System.Drawing.Point(136, 161)
        Me.Txtamount_up.Name = "Txtamount_up"
        Me.Txtamount_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtamount_up.TabIndex = 110
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(65, 164)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 109
        Me.Label7.Text = "นามสกุล : "
        '
        'Txtstatus_up
        '
        Me.Txtstatus_up.Location = New System.Drawing.Point(136, 200)
        Me.Txtstatus_up.Name = "Txtstatus_up"
        Me.Txtstatus_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtstatus_up.TabIndex = 107
        '
        'Txtprice1_up
        '
        Me.Txtprice1_up.Location = New System.Drawing.Point(136, 266)
        Me.Txtprice1_up.Name = "Txtprice1_up"
        Me.Txtprice1_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtprice1_up.TabIndex = 106
        '
        'Txtexp_up
        '
        Me.Txtexp_up.Location = New System.Drawing.Point(136, 235)
        Me.Txtexp_up.Name = "Txtexp_up"
        Me.Txtexp_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtexp_up.TabIndex = 105
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(38, 266)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 13)
        Me.Label6.TabIndex = 104
        Me.Label6.Text = "เบอร์โทรศัพท์ : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(59, 235)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 103
        Me.Label5.Text = "เงินเดือน : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(84, 200)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 102
        Me.Label4.Text = "ที่อยู่ : "
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(190, 376)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(85, 35)
        Me.Button2.TabIndex = 100
        Me.Button2.Text = "แก้ไข"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Txtname_up
        '
        Me.Txtname_up.Location = New System.Drawing.Point(135, 124)
        Me.Txtname_up.Name = "Txtname_up"
        Me.Txtname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtname_up.TabIndex = 99
        '
        'Txtid_up
        '
        Me.Txtid_up.Location = New System.Drawing.Point(136, 88)
        Me.Txtid_up.Name = "Txtid_up"
        Me.Txtid_up.ReadOnly = True
        Me.Txtid_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtid_up.TabIndex = 98
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(53, 131)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 13)
        Me.Label16.TabIndex = 97
        Me.Label16.Text = "ชื่อพนักงาน :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(46, 88)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(73, 13)
        Me.Label17.TabIndex = 96
        Me.Label17.Text = "รหัสพนักงาน :"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(305, 36)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 34)
        Me.Button1.TabIndex = 95
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(151, 38)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(148, 20)
        Me.TxtSearch.TabIndex = 94
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(53, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 93
        Me.Label1.Text = "รหัสพนักงาน"
        '
        'Edit_Emp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(428, 474)
        Me.Controls.Add(Me.Txtamount_up)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txtstatus_up)
        Me.Controls.Add(Me.Txtprice1_up)
        Me.Controls.Add(Me.Txtexp_up)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Txtname_up)
        Me.Controls.Add(Me.Txtid_up)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtSearch)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Edit_Emp"
        Me.Text = "แก้ไขข้อมูลพนักงาน"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Txtamount_up As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txtstatus_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtprice1_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtexp_up As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Txtname_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtid_up As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TxtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
