﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Form_Employee
    Dim strConn As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim objConn As New SqlConnection(strConn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Dim strdel As String
    Public strcell As String
    Public Sub show_data()
        Dim Strquery As String
        Strquery = "Select * From Employee;"
        da = New SqlDataAdapter(Strquery, objConn)
        ds = New DataSet
        da.Fill(ds, "emp_TB")
        DataGrid_Emp.DataMember = "emp_TB"
        DataGrid_Emp.DataSource = ds

    End Sub
    Private Sub Form_Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If objConn.State = ConnectionState.Closed Then
            objConn.Open()
            'MessageBox.Show("Sql Connent")
        End If
        txtName.Text = ""
        txtStdID.Text = ""
        show_data()
        DataGrid_Emp.Columns(0).HeaderText = "รหัสพนักงาน"
        DataGrid_Emp.Columns(1).HeaderText = "ชื่อพนักงาน"
        DataGrid_Emp.Columns(2).HeaderText = "นามสกุล"
        DataGrid_Emp.Columns(3).HeaderText = "ที่อยู่"
        DataGrid_Emp.Columns(4).HeaderText = "เงินเดือน"
        DataGrid_Emp.Columns(5).HeaderText = "เบอร์โทรศัพท์"
    End Sub

    'Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
    'FormReport.Show()
    'End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Insert_Emp.Show()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Edit_Emp.Show()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim Strq As String
        Strq = "select * from Employee"
        If txtStdID.Text <> "" Then
            Strq = "select * from Employee WHERE Emp_ID like '%" + txtStdID.Text + "%';"
        End If
        If txtName.Text <> "" Then
            Strq = "select * from Employee  WHERE Emp_name like '%" + txtName.Text + "%';"
        End If

        da = New SqlDataAdapter(Strq, objConn)
        ds = New DataSet
        da.Fill(ds, "emp_TB")
        DataGrid_Emp.DataMember = "emp_TB"
        DataGrid_Emp.DataSource = ds

    End Sub

    'Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

    'End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim str As String
        str = "delete Employee where Emp_ID = '" + txtStdID.Text + "';"
        MessageBox.Show(str)
        Dim cmd = New SqlClient.SqlCommand(str, objConn)
        cmd.ExecuteNonQuery()
        MessageBox.Show("ลบข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
    End Sub

    Private Sub DataGrid_Emp_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGrid_Emp.CellClick
        strcell = DataGrid_Emp.Rows.Item(e.RowIndex).Cells(0).Value.ToStrings()
    End Sub
End Class