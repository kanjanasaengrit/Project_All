﻿Imports System.Data.SqlClient
Public Class Edit_Bill
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)

    Private Sub Edit_Bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        Dim Str As String = "SELECT Product.product_id FROM Product"
        Dim com As New SqlCommand(Str, connection)
        Dim dr As SqlDataReader = com.ExecuteReader()

        Dim comboSource As New Dictionary(Of String, String)()
        comboSource.Add(0, "--เลือกรหัสสินค้า--")
        If dr.HasRows Then
            While dr.Read
                comboSource.Add(dr.Item(0), dr.Item(0))
            End While
            dr.Close()
        End If
        cb.DataSource = New BindingSource(comboSource, Nothing)
        cb.DisplayMember = "Value"
        cb.ValueMember = "Key"

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim str As String
        str = "update Bill set Bill_No = '" + Txtname_up.Text + "', Pro_am = '" + Txtamount_up.Text + "',"
        str &= "Price_Am = '" + Txtexp_up.Text + "',"
        str &= "product_id = '" + cb.SelectedValue.ToString() + "',"
        str &= "cus_id = '" + TextBox1.Text + "'"
        str &= " where Bill_id = '" + TxtSearch.Text + "';"

        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("แก้ไขข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form_Employee.show_data()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str As String
        str = "select * from Bill where Bill_id = '" + TxtSearch.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read

                Txtid_up.Text = dr.Item(0)
                Txtname_up.Text = dr.Item(1)
                Txtamount_up.Text = dr.Item(2)
                'Txtmajor_up.SelectedIndex = dr.Item(3)
                Txtexp_up.Text = dr.Item(3)
                TextBox1.Text = dr.Item(4)

            End While
        Else
            MessageBox.Show("ไม่มีข้อมูล", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        dr.Close()
        Dim selec As String = "SELECT Product.product_id FROM Product"
        Dim cmd2 = New SqlClient.SqlCommand(selec, connection)
        Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        Dim comboSource As New Dictionary(Of String, String)()
        comboSource.Add(0, "--เลือกรหัสสินค้า--")
        If dr2.HasRows Then
            While dr2.Read
                comboSource.Add(dr2.Item(0), dr2.Item(0))
            End While
            dr2.Close()
        End If
        'TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        cb.DisplayMember = "Value"
        cb.ValueMember = "Key"
    End Sub


End Class