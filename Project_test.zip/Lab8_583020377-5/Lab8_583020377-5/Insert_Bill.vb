﻿Imports System.Data.SqlClient
Public Class Insert_Bill
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim str As String
        str = "insert into Bill values('" + TxtldStudent.Text + "','" + TxtName.Text + "','"
        str &= TxtAddress.Text + "','" + TxtEmail.Text + "','" + Tb2.Text + "','" + Tb.Text + "');"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("เพิ่มข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        connection.Close()
        Form_Bill.show_data()
        Me.Close()
    End Sub

    'Private Sub Insert_Bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    'If connection.State = ConnectionState.Closed Then
    'connection.Open()
    'End If

    'Dim Str As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
    'Dim com As New SqlCommand(Str, connection)
    ' Dim dr As SqlDataReader = com.ExecuteReader()

    'Dim comboSource As New Dictionary(Of String, String)()
    'comboSource.Add(0, "--เลือกประเภทสินค้า--")
    'If dr.HasRows Then
    ' While dr.Read
    '   comboSource.Add(dr.Item(0), dr.Item(1))
    'End While
    'dr.Close()
    'End If
    'TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
    'TxtMajor.DisplayMember = "Value"
    'TxtMajor.ValueMember = "Key"
    'End Sub


    Private Sub Insert_Bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        'Dim Str As String = "SELECT Product.product_id,Product.product_name FROM Product"
        'Dim com As New SqlCommand(Str, connection)
        'Dim dr As SqlDataReader = com.ExecuteReader()

        'Dim comboSource As New Dictionary(Of String, String)()
        'comboSource.Add(0, "--เลือกสินค้า--")
        'If dr.HasRows Then
        '    While dr.Read
        '        comboSource.Add(dr.Item(0), dr.Item(1))
        '    End While
        '    dr.Close()
        'End If
        'ComboBox1.DataSource = New BindingSource(comboSource, Nothing)
        'ComboBox1.DisplayMember = "Value"
        'ComboBox1.ValueMember = "Key"
    End Sub

    'Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    'End Sub
End Class