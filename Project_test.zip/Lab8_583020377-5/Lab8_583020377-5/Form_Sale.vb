﻿Public Class Form_Sale

    Private Sub Form_Sale_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class