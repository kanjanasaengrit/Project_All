﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Edit_Bill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtamount_up = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txtexp_up = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Txtname_up = New System.Windows.Forms.TextBox()
        Me.Txtid_up = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cb = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Txtamount_up
        '
        Me.Txtamount_up.Location = New System.Drawing.Point(130, 172)
        Me.Txtamount_up.Name = "Txtamount_up"
        Me.Txtamount_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtamount_up.TabIndex = 126
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 175)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 125
        Me.Label7.Text = "จำนวนสินค้าที่สั่ง : "
        '
        'Txtexp_up
        '
        Me.Txtexp_up.Location = New System.Drawing.Point(130, 204)
        Me.Txtexp_up.Name = "Txtexp_up"
        Me.Txtexp_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtexp_up.TabIndex = 122
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(38, 204)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 120
        Me.Label5.Text = "ราคารวม : "
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(152, 345)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(85, 35)
        Me.Button2.TabIndex = 118
        Me.Button2.Text = "แก้ไข"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Txtname_up
        '
        Me.Txtname_up.Location = New System.Drawing.Point(130, 139)
        Me.Txtname_up.Name = "Txtname_up"
        Me.Txtname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtname_up.TabIndex = 117
        '
        'Txtid_up
        '
        Me.Txtid_up.Location = New System.Drawing.Point(130, 99)
        Me.Txtid_up.Name = "Txtid_up"
        Me.Txtid_up.ReadOnly = True
        Me.Txtid_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtid_up.TabIndex = 116
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(32, 142)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(74, 13)
        Me.Label16.TabIndex = 115
        Me.Label16.Text = "ลำดับรายการ :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(25, 99)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(73, 13)
        Me.Label17.TabIndex = 114
        Me.Label17.Text = "เลขทีใบเสร็จ :"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(284, 47)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 34)
        Me.Button1.TabIndex = 113
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(130, 49)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(148, 20)
        Me.TxtSearch.TabIndex = 112
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "เลขที่ใบเสร็จ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 239)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 127
        Me.Label2.Text = "รหัสสินค้า : "
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(130, 273)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(177, 20)
        Me.TextBox1.TabIndex = 130
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 276)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 129
        Me.Label3.Text = "รหัสลูกค้า : "
        '
        'cb
        '
        Me.cb.FormattingEnabled = True
        Me.cb.Location = New System.Drawing.Point(130, 239)
        Me.cb.Name = "cb"
        Me.cb.Size = New System.Drawing.Size(177, 21)
        Me.cb.TabIndex = 131
        '
        'Edit_Bill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(373, 452)
        Me.Controls.Add(Me.cb)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Txtamount_up)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txtexp_up)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Txtname_up)
        Me.Controls.Add(Me.Txtid_up)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtSearch)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Edit_Bill"
        Me.Text = "แก้ไขรายการ"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Txtamount_up As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txtexp_up As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Txtname_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtid_up As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TxtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cb As System.Windows.Forms.ComboBox
End Class
