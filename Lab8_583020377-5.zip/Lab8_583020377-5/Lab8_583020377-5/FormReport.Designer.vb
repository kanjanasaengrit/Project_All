﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtStdID = New System.Windows.Forms.TextBox()
        Me.btn_print = New System.Windows.Forms.Button()
        Me.myCrytalReprotViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.CrystalReport21 = New Lab8_583020377_5.CrystalReport2()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(207, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "กรอกรหัสนักศึกษา"
        '
        'TxtStdID
        '
        Me.TxtStdID.Location = New System.Drawing.Point(309, 29)
        Me.TxtStdID.Name = "TxtStdID"
        Me.TxtStdID.Size = New System.Drawing.Size(157, 20)
        Me.TxtStdID.TabIndex = 1
        '
        'btn_print
        '
        Me.btn_print.Location = New System.Drawing.Point(547, 19)
        Me.btn_print.Name = "btn_print"
        Me.btn_print.Size = New System.Drawing.Size(91, 38)
        Me.btn_print.TabIndex = 2
        Me.btn_print.Text = "พิมพ์"
        Me.btn_print.UseVisualStyleBackColor = True
        '
        'myCrytalReprotViewer
        '
        Me.myCrytalReprotViewer.ActiveViewIndex = 0
        Me.myCrytalReprotViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.myCrytalReprotViewer.Cursor = System.Windows.Forms.Cursors.Default
        Me.myCrytalReprotViewer.Location = New System.Drawing.Point(22, 76)
        Me.myCrytalReprotViewer.Name = "myCrytalReprotViewer"
        Me.myCrytalReprotViewer.ReportSource = "D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport1.rpt"
        Me.myCrytalReprotViewer.Size = New System.Drawing.Size(819, 446)
        Me.myCrytalReprotViewer.TabIndex = 3
        Me.myCrytalReprotViewer.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
        '
        'FormReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(875, 534)
        Me.Controls.Add(Me.myCrytalReprotViewer)
        Me.Controls.Add(Me.btn_print)
        Me.Controls.Add(Me.TxtStdID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormReport"
        Me.Text = "FormReport"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TxtStdID As TextBox
    Friend WithEvents btn_print As Button
    Friend WithEvents myCrytalReprotViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents CrystalReport21 As Lab8_583020377_5.CrystalReport2
End Class
