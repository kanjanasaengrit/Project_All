﻿Imports CrystalDecisions.CrystalReports.Engine
Public Class FormReport
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles myCrytalReprotViewer.Load

    End Sub

    Private Sub btn_print_Click(sender As Object, e As EventArgs) Handles btn_print.Click
        Dim rpt As New ReportDocument()
        Dim directory As String = My.Application.Info.DirectoryPath
        rpt.Load("D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport1.rpt")
        'rpt.Load("D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport2.rpt")
        'D:\database_app\Lab8_583020377-5\Lab8_583020377-5\CrystalReport2.rpt
        Me.myCrytalReprotViewer.ReportSource = rpt
        Me.myCrytalReprotViewer.Refresh()
    End Sub

    Private Sub FormReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class