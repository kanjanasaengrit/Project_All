﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Form1
    Dim strConn As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim objConn As New SqlConnection(strConn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Dim strdel As String
    Public strcell As String
    Public Sub show_data()
        Dim Strquery As String
        Strquery = "Select Student.std_id,Student.std_name,Student.std_lastname,Department.dept_name,Student.std_address,Student.std_mail,Student.std_tel From Student INNER JOIN Department on (Student.dept_id = Department.dept_id);"
        da = New SqlDataAdapter(Strquery, objConn)
        ds = New DataSet
        da.Fill(ds, "Std_Dept")
        DataGridView1.DataMember = "Std_Dept"
        DataGridView1.DataSource = ds

    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If objConn.State = ConnectionState.Closed Then
            objConn.Open()
            'MessageBox.Show("Sql Connent")
        End If

        txtLastname.Text = ""
        txtName.Text = ""
        txtStdID.Text = ""
        show_data()
        DataGridView1.Columns(0).HeaderText = "รหัสนักศึกษา"
        DataGridView1.Columns(1).HeaderText = "ชื่อ"
        DataGridView1.Columns(2).HeaderText = "นามสกุล"
        DataGridView1.Columns(3).HeaderText = "ภาควิชา"
        DataGridView1.Columns(4).HeaderText = "ที่อยู่"
        DataGridView1.Columns(5).HeaderText = "อีเมลล์"
        DataGridView1.Columns(6).HeaderText = "เบอร์โทรศัพท์"

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        FormReport.Show()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        InsertForm.Show()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        EditForm.Show()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim Strq As String
        Strq = "select * from Student INNER JOIN Department on(Student.dept_id=Department.dept_id)"
        If txtStdID.Text <> "" Then
            Strq = "select * from Student INNER JOIN Department on(Student.dept_id=Department.dept_id) WHERE std_id like '%" + txtStdID.Text + "%';"
        End If
        If txtName.Text <> "" Then
            Strq = "select * from Student INNER JOIN Department on(Student.dept_id=Department.dept_id) WHERE std_name like '%" + txtName.Text + "%';"
        End If
        If txtLastname.Text <> "" Then
            Strq = "select * from Student INNER JOIN Department on(Student.dept_id=Department.dept_id) WHERE std_lastname like '%" + txtLastname.Text + "%';"
        End If
        da = New SqlDataAdapter(Strq, objConn)
        ds = New DataSet
        da.Fill(ds, "Std_Dept")
        DataGridView1.DataMember = "Std_Dept"
        DataGridView1.DataSource = ds

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        strcell = DataGridView1.Rows.Item(e.RowIndex).Cells(0).Value.ToString
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
         Dim str As String
        str = "delete Student where std_id = '" + txtStdID.Text + "';"
        MessageBox.Show(str)
        Dim cmd = New SqlClient.SqlCommand(str, objConn)
        cmd.ExecuteNonQuery()
        MessageBox.Show("ลบข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
    End Sub
End Class
