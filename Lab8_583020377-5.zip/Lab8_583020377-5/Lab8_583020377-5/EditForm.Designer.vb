﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Txtlasname_up = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txtmajor_up = New System.Windows.Forms.ComboBox()
        Me.Txtmail_up = New System.Windows.Forms.TextBox()
        Me.Txttel_up = New System.Windows.Forms.TextBox()
        Me.Txtadd_up = New System.Windows.Forms.TextBox()
        Me.Txtname_up = New System.Windows.Forms.TextBox()
        Me.Txtid_up = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(219, 277)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(85, 35)
        Me.Button2.TabIndex = 80
        Me.Button2.Text = "แก้ไข"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Txtlasname_up
        '
        Me.Txtlasname_up.Location = New System.Drawing.Point(116, 137)
        Me.Txtlasname_up.Name = "Txtlasname_up"
        Me.Txtlasname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtlasname_up.TabIndex = 79
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(64, 140)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 78
        Me.Label11.Text = "นามสกุล"
        '
        'Txtmajor_up
        '
        Me.Txtmajor_up.FormattingEnabled = True
        Me.Txtmajor_up.Location = New System.Drawing.Point(116, 161)
        Me.Txtmajor_up.Name = "Txtmajor_up"
        Me.Txtmajor_up.Size = New System.Drawing.Size(178, 21)
        Me.Txtmajor_up.TabIndex = 77
        '
        'Txtmail_up
        '
        Me.Txtmail_up.Location = New System.Drawing.Point(116, 215)
        Me.Txtmail_up.Name = "Txtmail_up"
        Me.Txtmail_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtmail_up.TabIndex = 76
        '
        'Txttel_up
        '
        Me.Txttel_up.Location = New System.Drawing.Point(116, 241)
        Me.Txttel_up.Name = "Txttel_up"
        Me.Txttel_up.Size = New System.Drawing.Size(177, 20)
        Me.Txttel_up.TabIndex = 75
        '
        'Txtadd_up
        '
        Me.Txtadd_up.Location = New System.Drawing.Point(116, 189)
        Me.Txtadd_up.Name = "Txtadd_up"
        Me.Txtadd_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtadd_up.TabIndex = 74
        '
        'Txtname_up
        '
        Me.Txtname_up.Location = New System.Drawing.Point(116, 111)
        Me.Txtname_up.Name = "Txtname_up"
        Me.Txtname_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtname_up.TabIndex = 73
        '
        'Txtid_up
        '
        Me.Txtid_up.Location = New System.Drawing.Point(116, 85)
        Me.Txtid_up.Name = "Txtid_up"
        Me.Txtid_up.ReadOnly = True
        Me.Txtid_up.Size = New System.Drawing.Size(177, 20)
        Me.Txtid_up.TabIndex = 72
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(37, 244)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(72, 13)
        Me.Label12.TabIndex = 71
        Me.Label12.Text = "เบอร์โทรศัพท์"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(77, 218)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 70
        Me.Label13.Text = "Email"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(82, 192)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(27, 13)
        Me.Label14.TabIndex = 69
        Me.Label14.Text = "ที่อยู่"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(79, 164)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 68
        Me.Label15.Text = "สาขา"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(89, 114)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 13)
        Me.Label16.TabIndex = 67
        Me.Label16.Text = "ชื่อ"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(40, 85)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 13)
        Me.Label17.TabIndex = 66
        Me.Label17.Text = "รหัสนักศึกษา"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(285, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 34)
        Me.Button1.TabIndex = 56
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(131, 35)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(148, 20)
        Me.TxtSearch.TabIndex = 55
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 54
        Me.Label1.Text = "รหัสนักศึกษา"
        '
        'EditForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(413, 431)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Txtlasname_up)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txtmajor_up)
        Me.Controls.Add(Me.Txtmail_up)
        Me.Controls.Add(Me.Txttel_up)
        Me.Controls.Add(Me.Txtadd_up)
        Me.Controls.Add(Me.Txtname_up)
        Me.Controls.Add(Me.Txtid_up)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtSearch)
        Me.Controls.Add(Me.Label1)
        Me.Name = "EditForm"
        Me.Text = "EditForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Txtlasname_up As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txtmajor_up As System.Windows.Forms.ComboBox
    Friend WithEvents Txtmail_up As System.Windows.Forms.TextBox
    Friend WithEvents Txttel_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtadd_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtname_up As System.Windows.Forms.TextBox
    Friend WithEvents Txtid_up As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TxtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
