﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lb_cicle_area = New System.Windows.Forms.Label()
        Me.Lb_cicle_perimeter = New System.Windows.Forms.Label()
        Me.txtB_cicle = New System.Windows.Forms.TextBox()
        Me.btn_cicle = New System.Windows.Forms.Button()
        Me.btn_edit_cicle = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(210, 292)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cicle Object 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(210, 327)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Radius"
        '
        'Lb_cicle_area
        '
        Me.Lb_cicle_area.AutoSize = True
        Me.Lb_cicle_area.Location = New System.Drawing.Point(210, 361)
        Me.Lb_cicle_area.Name = "Lb_cicle_area"
        Me.Lb_cicle_area.Size = New System.Drawing.Size(35, 13)
        Me.Lb_cicle_area.TabIndex = 2
        Me.Lb_cicle_area.Text = "Area :"
        '
        'Lb_cicle_perimeter
        '
        Me.Lb_cicle_perimeter.AutoSize = True
        Me.Lb_cicle_perimeter.Location = New System.Drawing.Point(210, 392)
        Me.Lb_cicle_perimeter.Name = "Lb_cicle_perimeter"
        Me.Lb_cicle_perimeter.Size = New System.Drawing.Size(57, 13)
        Me.Lb_cicle_perimeter.TabIndex = 3
        Me.Lb_cicle_perimeter.Text = "Perimeter :"
        '
        'txtB_cicle
        '
        Me.txtB_cicle.Location = New System.Drawing.Point(269, 319)
        Me.txtB_cicle.Multiline = True
        Me.txtB_cicle.Name = "txtB_cicle"
        Me.txtB_cicle.Size = New System.Drawing.Size(86, 31)
        Me.txtB_cicle.TabIndex = 4
        '
        'btn_cicle
        '
        Me.btn_cicle.Location = New System.Drawing.Point(406, 316)
        Me.btn_cicle.Name = "btn_cicle"
        Me.btn_cicle.Size = New System.Drawing.Size(75, 34)
        Me.btn_cicle.TabIndex = 5
        Me.btn_cicle.Text = "New Cicle"
        Me.btn_cicle.UseVisualStyleBackColor = True
        '
        'btn_edit_cicle
        '
        Me.btn_edit_cicle.Location = New System.Drawing.Point(406, 361)
        Me.btn_edit_cicle.Name = "btn_edit_cicle"
        Me.btn_edit_cicle.Size = New System.Drawing.Size(75, 30)
        Me.btn_edit_cicle.TabIndex = 6
        Me.btn_edit_cicle.Text = "Edit Value"
        Me.btn_edit_cicle.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(643, 447)
        Me.Controls.Add(Me.btn_edit_cicle)
        Me.Controls.Add(Me.btn_cicle)
        Me.Controls.Add(Me.txtB_cicle)
        Me.Controls.Add(Me.Lb_cicle_perimeter)
        Me.Controls.Add(Me.Lb_cicle_area)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lb_cicle_area As System.Windows.Forms.Label
    Friend WithEvents Lb_cicle_perimeter As System.Windows.Forms.Label
    Friend WithEvents txtB_cicle As System.Windows.Forms.TextBox
    Friend WithEvents btn_cicle As System.Windows.Forms.Button
    Friend WithEvents btn_edit_cicle As System.Windows.Forms.Button
End Class
