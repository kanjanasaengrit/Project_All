﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lb_square_area1 = New System.Windows.Forms.Label()
        Me.Lb_square_perimeter1 = New System.Windows.Forms.Label()
        Me.TxtB_width1 = New System.Windows.Forms.TextBox()
        Me.btn_square1 = New System.Windows.Forms.Button()
        Me.btn_edit1 = New System.Windows.Forms.Button()
        Me.btn_edit2 = New System.Windows.Forms.Button()
        Me.btn_square2 = New System.Windows.Forms.Button()
        Me.TxtB_width2 = New System.Windows.Forms.TextBox()
        Me.Lb_square_perimeter2 = New System.Windows.Forms.Label()
        Me.Lb_square_area2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 315)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Object 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(56, 345)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Width"
        '
        'Lb_square_area1
        '
        Me.Lb_square_area1.AutoSize = True
        Me.Lb_square_area1.Location = New System.Drawing.Point(56, 378)
        Me.Lb_square_area1.Name = "Lb_square_area1"
        Me.Lb_square_area1.Size = New System.Drawing.Size(35, 13)
        Me.Lb_square_area1.TabIndex = 2
        Me.Lb_square_area1.Text = "Area :"
        '
        'Lb_square_perimeter1
        '
        Me.Lb_square_perimeter1.AutoSize = True
        Me.Lb_square_perimeter1.Location = New System.Drawing.Point(56, 407)
        Me.Lb_square_perimeter1.Name = "Lb_square_perimeter1"
        Me.Lb_square_perimeter1.Size = New System.Drawing.Size(57, 13)
        Me.Lb_square_perimeter1.TabIndex = 3
        Me.Lb_square_perimeter1.Text = "Perimeter :"
        '
        'TxtB_width1
        '
        Me.TxtB_width1.Location = New System.Drawing.Point(122, 337)
        Me.TxtB_width1.Multiline = True
        Me.TxtB_width1.Name = "TxtB_width1"
        Me.TxtB_width1.Size = New System.Drawing.Size(83, 20)
        Me.TxtB_width1.TabIndex = 7
        '
        'btn_square1
        '
        Me.btn_square1.Location = New System.Drawing.Point(259, 337)
        Me.btn_square1.Name = "btn_square1"
        Me.btn_square1.Size = New System.Drawing.Size(86, 30)
        Me.btn_square1.TabIndex = 8
        Me.btn_square1.Text = "New Square 1"
        Me.btn_square1.UseVisualStyleBackColor = True
        '
        'btn_edit1
        '
        Me.btn_edit1.Location = New System.Drawing.Point(259, 397)
        Me.btn_edit1.Name = "btn_edit1"
        Me.btn_edit1.Size = New System.Drawing.Size(86, 36)
        Me.btn_edit1.TabIndex = 9
        Me.btn_edit1.Text = "Edit Value"
        Me.btn_edit1.UseVisualStyleBackColor = True
        '
        'btn_edit2
        '
        Me.btn_edit2.Location = New System.Drawing.Point(642, 397)
        Me.btn_edit2.Name = "btn_edit2"
        Me.btn_edit2.Size = New System.Drawing.Size(86, 36)
        Me.btn_edit2.TabIndex = 18
        Me.btn_edit2.Text = "Edit Value"
        Me.btn_edit2.UseVisualStyleBackColor = True
        '
        'btn_square2
        '
        Me.btn_square2.Location = New System.Drawing.Point(642, 337)
        Me.btn_square2.Name = "btn_square2"
        Me.btn_square2.Size = New System.Drawing.Size(86, 30)
        Me.btn_square2.TabIndex = 17
        Me.btn_square2.Text = "New Square 2"
        Me.btn_square2.UseVisualStyleBackColor = True
        '
        'TxtB_width2
        '
        Me.TxtB_width2.Location = New System.Drawing.Point(505, 337)
        Me.TxtB_width2.Multiline = True
        Me.TxtB_width2.Name = "TxtB_width2"
        Me.TxtB_width2.Size = New System.Drawing.Size(83, 20)
        Me.TxtB_width2.TabIndex = 16
        '
        'Lb_square_perimeter2
        '
        Me.Lb_square_perimeter2.AutoSize = True
        Me.Lb_square_perimeter2.Location = New System.Drawing.Point(439, 407)
        Me.Lb_square_perimeter2.Name = "Lb_square_perimeter2"
        Me.Lb_square_perimeter2.Size = New System.Drawing.Size(57, 13)
        Me.Lb_square_perimeter2.TabIndex = 13
        Me.Lb_square_perimeter2.Text = "Perimeter :"
        '
        'Lb_square_area2
        '
        Me.Lb_square_area2.AutoSize = True
        Me.Lb_square_area2.Location = New System.Drawing.Point(439, 378)
        Me.Lb_square_area2.Name = "Lb_square_area2"
        Me.Lb_square_area2.Size = New System.Drawing.Size(35, 13)
        Me.Lb_square_area2.TabIndex = 12
        Me.Lb_square_area2.Text = "Area :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(439, 345)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Width"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(439, 315)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 13)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "Object 2"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(799, 525)
        Me.Controls.Add(Me.btn_edit2)
        Me.Controls.Add(Me.btn_square2)
        Me.Controls.Add(Me.TxtB_width2)
        Me.Controls.Add(Me.Lb_square_perimeter2)
        Me.Controls.Add(Me.Lb_square_area2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btn_edit1)
        Me.Controls.Add(Me.btn_square1)
        Me.Controls.Add(Me.TxtB_width1)
        Me.Controls.Add(Me.Lb_square_perimeter1)
        Me.Controls.Add(Me.Lb_square_area1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lb_square_area1 As System.Windows.Forms.Label
    Friend WithEvents Lb_square_perimeter1 As System.Windows.Forms.Label
    Friend WithEvents TxtB_width1 As System.Windows.Forms.TextBox
    Friend WithEvents btn_square1 As System.Windows.Forms.Button
    Friend WithEvents btn_edit1 As System.Windows.Forms.Button
    Friend WithEvents btn_edit2 As System.Windows.Forms.Button
    Friend WithEvents btn_square2 As System.Windows.Forms.Button
    Friend WithEvents TxtB_width2 As System.Windows.Forms.TextBox
    Friend WithEvents Lb_square_perimeter2 As System.Windows.Forms.Label
    Friend WithEvents Lb_square_area2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class
