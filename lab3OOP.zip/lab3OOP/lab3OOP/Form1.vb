﻿Public Class Form1
    Dim MySquare1 As Square_class
    Dim MySquare2 As Square_class
    Private Sub btn_square1_Click(sender As Object, e As EventArgs) Handles btn_square1.Click
        MySquare1 = New Square_class()
        MySquare1.mywidth = TxtB_width1.Text
        Lb_square_area1.Text = "Area :" + CStr(MySquare1.Area(MySquare1.mywidth))
        Lb_square_perimeter1.Text = "Perimeter :" + CStr(MySquare1.Perimeter())
        MySquare1.Draw_square()
    End Sub

    Private Sub btn_edit1_Click(sender As Object, e As EventArgs) Handles btn_edit1.Click
        MySquare1.Clear_square()
        MySquare1.mywidth = TxtB_width1.Text
        Lb_square_area1.Text = "Area :" + CStr(MySquare1.Area(MySquare1.mywidth))
        Lb_square_perimeter1.Text = "Perimeter :" + CStr(MySquare1.Perimeter())
        MySquare1.Draw_square()
    End Sub

    Private Sub btn_square2_Click(sender As Object, e As EventArgs) Handles btn_square2.Click
        MySquare2 = New Square_class()
        MySquare2.mywidth = TxtB_width2.Text
        Lb_square_area2.Text = "Area :" + CStr(MySquare2.Area(MySquare2.mywidth))
        Lb_square_perimeter2.Text = "Perimeter :" + CStr(MySquare2.Perimeter())
        MySquare2.Draw_square()
    End Sub

    Private Sub btn_edit2_Click(sender As Object, e As EventArgs) Handles btn_edit2.Click
        MySquare2.Clear_square()
        MySquare2.mywidth = TxtB_width2.Text
        Lb_square_area2.Text = "Area :" + CStr(MySquare2.Area(MySquare2.mywidth))
        Lb_square_perimeter2.Text = "Perimeter :" + CStr(MySquare2.Perimeter())
        MySquare2.Draw_square()
    End Sub
End Class
