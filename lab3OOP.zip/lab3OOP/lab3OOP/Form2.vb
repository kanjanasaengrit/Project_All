﻿Public Class Form2
    Dim MyCicle As Square_class
    Private Sub btn_cicle_Click(sender As Object, e As EventArgs) Handles btn_cicle.Click
    End Sub
End Class