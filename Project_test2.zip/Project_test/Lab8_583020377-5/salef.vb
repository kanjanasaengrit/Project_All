﻿Imports System.Data.SqlClient
Public Class salef
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Dim str As String
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Friend cmd As New SqlCommand
    'Private Sub Button4_Click(sender As Object, e As EventArgs)
    '    Dim Strq As String
    '    Strq = "select * from pro_test"
    '    If Tb4.Text <> "" Then
    '        Strq = "select * from pro_test WHERE pro_id like '%" + Tb4.Text + "%';"
    '    End If

    '    da = New SqlDataAdapter(Strq, connection)
    '    ds = New DataSet
    '    da.Fill(ds, "pro_TB")
    '    Dg_s.DataMember = "pro_TB"
    '    Dg_s.DataSource = ds
    '    cdf()
    'End Sub
    'Public Sub show_data()
    '    Dim Strquery As String
    '    Strquery = "Select * from pro_test"
    '    da = New SqlDataAdapter(Strquery, connection)
    '    ds = New DataSet
    '    da.Fill(ds, "pro_TB")
    '    Dg_sl.DataMember = "pro_TB"
    '    Dg_sl.DataSource = ds

    'End Sub
    'Public Sub cdf()
    '    Tb4.Text = ""
    'End Sub
    'Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs)
    '    Dim srow As Integer = Dg_s.CurrentRow.Index
    '    Dim product_id As String = Dg_s.Item(0, srow).Value
    '    str = "select * from pro_test where pro_id ='" & product_id & "'"
    'End Sub


    'Private Sub salef_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    show_data()
    '    Dg_s.Columns(0).HeaderText = "รหัสสินค้า"
    '    Dg_s.Columns(1).HeaderText = "ชื่อสินค้า"
    '    Dg_s.Columns(2).HeaderText = "ราคาสินค้า"
    'End Sub

    'Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles Tid.TextChanged

    'End Sub

    'Private Sub Dg_s_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    'End Sub

    'Private Sub Dg_s_SelectionChanged(sender As Object, e As EventArgs)

    'End Sub

    'Private Sub btn_5_Click(sender As Object, e As EventArgs) Handles btn_5.Click
    '    Dim arr(6) As String
    '    arr(0) = Dg_sl.CurrentRow.Index + 1


    'End Sub

    'Private Sub Dg_sl_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dg_sl.CellClick
    '    Dim srow As Integer = Dg_sl.CurrentRow.Index
    '    Dim product_id As String = Dg_sl.Item(0, srow).Value
    '    str = "select * from pro_test where pro_id ='" & product_id & "'"
    'End Sub

    'Private Sub Dg_sl_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dg_sl.CellContentClick

    'End Sub

    'Private Sub Tid_Leave(sender As Object, e As EventArgs) Handles Tid.Leave

    'End Sub

    'Private Sub btn_5_Click(sender As Object, e As EventArgs) Handles btn_5.Click
    '    If connection.State = ConnectionState.Closed Then
    '        connection.Open()
    '    End If
    '    str = "update pro_test set pro_am=pro_am-" & num.Value & "where pro_id='" &
    '    Dg_sl.Item(0, Dg_sl.CurrentRow.Index).Value & "'"
    '    cmd = New SqlCommand(str, connection)

    'End Sub

    'Private Sub salef_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    show_data()
    'End Sub

    'Private Sub Dg_sl_CellClick(sender As Object, e As DataGridViewCellEventArgs)
    '    Dim i As Integer = Dg_sl.CurrentRow.Index
    '    Dim amount As Integer = Dg_sl.Item(2, i).Value
    '    num.Maximum = amount
    'End Sub
    Public Sub tot()
        Tb5.Text = Sum_Column_Currency(Listp, 5)
    End Sub
    Public Sub cc()
        Tid.Text = ""
        Tam.Text = ""

    End Sub
    Private Sub btn_5_Click(sender As Object, e As EventArgs) Handles btn_5.Click
        If Tam.Text = "" Or Not IsNumeric(Tam.Text) Then
            MessageBox.Show("กรุณากรอกข้อมูลให้ครบและใส่เป็นตัวเลขเท่านั้น")
            Return
        End If
        sql = "select * from pro_test where pro_id ='" & Tid.Text & "'"
        Dim dts As DataTable = cmd_excuteToDataTable()

        Dim arr(6) As String
        arr(0) = Listp.Items.Count + 1
        arr(1) = dts.Rows(0)("pro_id")
        arr(2) = dts.Rows(0)("pro_name")
        arr(3) = Tam.Text

        Dim price As Integer = 0
        price = dts.Rows(0)("pro_price")
        arr(4) = price
        arr(5) = arr(3) * arr(4)
        Dim itm As New ListViewItem(arr)
        Listp.Items.Add(itm)
        tot()
        cc()

    End Sub

    Private Sub Tid_Leave(sender As Object, e As EventArgs) Handles Tid.Leave

        sql = "select * from pro_test where pro_id ='" & Tid.Text & "'"
        Dim i As Integer = cmd_excuteScalar()
        If i <= 0 And Tid.Text <> "" Then
            MessageBox.Show("ไม่พบรหัสสินค้านี้กรุณาแก้ไข")
            Tid.Select()
        End If
    End Sub

    Private Sub Tb5_TextChanged(sender As Object, e As EventArgs) Handles Tb5.TextChanged

    End Sub

    Public Sub sale_id()
        Try
            sql = "select max(sale_id) from sale"
            Dim i As Integer = cmd_excuteScalar() + 1
            Lbid.Text = "IV-" & Date.Now.Year + 543 & "/" & i.ToString.PadLeft(5, "0")

        Catch ex As Exception
            Lbid.Text = "IV-" & Date.Now.Year + 543 & "/00001"
        End Try


    End Sub





    Public Sub datess()
        Lb_date.Text = Date.Today


    End Sub



    Private Sub salef_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        datess()
        sale_id()
    End Sub


    Private Sub Tid_KeyDown(sender As Object, e As KeyEventArgs) Handles Tid.KeyDown
        If e.KeyData = Keys.Enter Then Tam.Select()

    End Sub

    Private Sub Btn_d1_Click(sender As Object, e As EventArgs) Handles Btn_d1.Click
        If confirm("ต้องการยกเลิกรายการนี้หรือไม่ ?") = vbNo Then Return

        Listp.Items.Clear()
        Tb5.Text = "0"
    End Sub

    Private Sub Btn_d2_Click(sender As Object, e As EventArgs) Handles Btn_d2.Click
        If confirm("ต้องการยกเลิกรายการนี้หรือไม่ ?") = vbYes Then
            Listp.Items.Remove(Listp.FocusedItem)
            tot()

        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Btn_1.Click
        With SaleD

            .Tb5.Text = Tb5.Text
            .T2.Text = ""
            .T2.Select()
            .Show()
            .Activate()


        End With



        SaleD.Show()
    End Sub
End Class