﻿Imports System.Data.SqlClient

Class Product_test

    Private Sub Dg_Pro_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dg_Pro.CellClick
        Dim srow As Integer = Dg_Pro.CurrentRow.Index
        Dim product_id As String = Dg_Pro.Item(0, srow).Value
        str = "select * from pro_test where pro_id ='" & product_id & "'"
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dg_Pro.CellContentClick

    End Sub
    Dim strCon As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim connection As New SqlConnection(strCon)
    Dim str As String
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Friend cmd As New SqlCommand

    Public Sub show_data()
        Dim Strquery As String
        Strquery = "Select * from pro_test"
        da = New SqlDataAdapter(Strquery, connection)
        ds = New DataSet
        da.Fill(ds, "pro_TB")
        Dg_Pro.DataMember = "pro_TB"
        Dg_Pro.DataSource = ds

    End Sub
    Public Sub c_form()
        Txt_pid.Text = ""
        TxtName.Text = ""
        Txt_p1.Text = ""
        'Tba.Text = ""
    End Sub
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        If Txt_pid.Text = "" Or TxtName.Text = "" Or Txt_p1.Text = "" Then
            MessageBox.Show("กรุณากรอกข้อมูลให้ครบ")
            Return
        End If
        If Not IsNumeric(Txt_p1.Text) Then
            MessageBox.Show("กรุณากรอกเฉพาะตัวเลขเท่านั้น")
            Return
        End If
        str = "Insert into pro_test values ('" + Txt_pid.Text + "','" + TxtName.Text + "','" + Txt_p1.Text + "');"

        cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("เพิ่มข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
        c_form()
        connection.Close()
    End Sub


    '    Dim str As String

    '        str = "insert into Product values('" + TxtldStudent.Text + "','" + TxtName.Text + "','" + Txt_am.Text + "','"
    '        str &= Txt_st.Text + "','" + TxtEmail.Text + "','"
    '        str &= Txt_p1.Text + "','" + Txt_p2.Text + "','" + TxtMajor.SelectedValue.ToString() + "' );"

    '    Dim cmd = New SqlClient.SqlCommand(str, connection)
    '    cmd.ExecuteNonQuery()
    '    MessageBox.Show("เพิ่มข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    connection.Close()
    '    Form_Product.show_data()
    '    Me.Close()
    'End Sub

    'Private Sub InsertForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    If connection.State = ConnectionState.Closed Then
    '        connection.Open()
    '    End If

    '    Dim Str As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
    '    Dim com As New SqlCommand(Str, connection)
    '    Dim dr As SqlDataReader = com.ExecuteReader()

    '    Dim comboSource As New Dictionary(Of String, String)()
    '    comboSource.Add(0, "--เลือกประเภทสินค้า--")
    '    If dr.HasRows Then
    '        While dr.Read
    '            comboSource.Add(dr.Item(0), dr.Item(1))
    '        End While
    '        dr.Close()
    '    End If
    '    TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
    '    TxtMajor.DisplayMember = "Value"
    '    TxtMajor.ValueMember = "Key"
    'End Sub


    Private Sub Product_test_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        show_data()
        Dg_Pro.Columns(0).HeaderText = "รหัสสินค้า"
        Dg_Pro.Columns(1).HeaderText = "ชื่อสินค้า"
        Dg_Pro.Columns(2).HeaderText = "ราคาสินค้า"
    End Sub

    'Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
    '    If connection.State = ConnectionState.Closed Then
    '        connection.Open()
    '    End If
    '    str = "select * from pro_test where pro_id like'%" & TextBox1.Text & "%' or pro_name like '%" & TextBox1.Text & "%'"
    '    da = New SqlDataAdapter(str, connection)
    '    ds = New DataSet
    '    da.Fill(ds, "pro_TB")
    '    Dg_Pro.DataMember = "pro_TB"
    '    Dg_Pro.DataSource = ds
    '    show_data()
    '    connection.Close()
    'End Sub
    Public Sub cc_form()
        TextBox1.Text = ""
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Strq As String
        Strq = "select * from pro_test"
        If TextBox1.Text <> "" Then
            Strq = "select * from pro_test WHERE pro_id like '%" + TextBox1.Text + "%';"
        End If

        da = New SqlDataAdapter(Strq, connection)
        ds = New DataSet
        da.Fill(ds, "pro_TB")
        Dg_Pro.DataMember = "pro_TB"
        Dg_Pro.DataSource = ds
        cc_form()
    End Sub

    Private Sub btn_1_Click(sender As Object, e As EventArgs) Handles btn_1.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        Dim str As String
        str = "update pro_test set pro_name = '" + Txt_nup.Text + "', pro_price = '" + Txt_pup.Text + "'"
        str &= " where pro_id = '" + TxtSearch.Text + "';"

        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("แก้ไขข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
        cc()
    End Sub
    Public Sub cc()
        Txtid_up.Text = ""
        Txt_nup.Text = ""
        Txt_pup.Text = ""
        TxtSearch.Text = ""

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        Dim str As String
        str = "select * from pro_test where pro_id = '" + TxtSearch.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read

                Txtid_up.Text = dr.Item(0)
                Txt_nup.Text = dr.Item(1)
                Txt_pup.Text = dr.Item(2)
                'Txtmajor_up.SelectedIndex = dr.Item(3)
                'Txtstatus_up.Text = dr.Item(3)
                'Txtexp_up.Text = dr.Item(4)
                'Txtprice1_up.Text = dr.Item(5)

            End While
        Else
            MessageBox.Show("ไม่มีข้อมูล", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        dr.Close()
        'Dim selec As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
        'Dim cmd2 = New SqlClient.SqlCommand(selec, connection)
        'Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        'Dim comboSource As New Dictionary(Of String, String)()
        'comboSource.Add(0, "--เลือกประเภทสินค้า--")
        'If dr2.HasRows Then
        'While dr2.Read
        'comboSource.Add(dr2.Item(0), dr2.Item(1))
        'End While
        'dr2.Close()
        'End If
        ''TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        'TxtMajor.DisplayMember = "Value"
        'TxtMajor.ValueMember = "Key"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        Dim str As String
        str = "delete pro_test where pro_id = '" + T3.Text + "';"
        MessageBox.Show("คุณต้องการลบข้อมูลนี้")
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        cmd.ExecuteNonQuery()
        MessageBox.Show("ลบข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
        cd()
    End Sub
    Public Sub cd()
        T3.Text = ""
        T4.Text = ""
        T2.Text = ""
        T5.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        Dim str As String
        str = "select * from pro_test where pro_id = '" + T3.Text + "';"
        Dim cmd = New SqlClient.SqlCommand(str, connection)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read

                T2.Text = dr.Item(0)
                T5.Text = dr.Item(1)
                T4.Text = dr.Item(2)
                'Txtmajor_up.SelectedIndex = dr.Item(3)
                'Txtstatus_up.Text = dr.Item(3)
                'Txtexp_up.Text = dr.Item(4)
                'Txtprice1_up.Text = dr.Item(5)

            End While
        Else
            MessageBox.Show("ไม่มีข้อมูล", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        dr.Close()
        'Dim selec As String = "SELECT Pro_type.p_id,Pro_type.p_name FROM Pro_type"
        'Dim cmd2 = New SqlClient.SqlCommand(selec, connection)
        'Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        'Dim comboSource As New Dictionary(Of String, String)()
        'comboSource.Add(0, "--เลือกประเภทสินค้า--")
        'If dr2.HasRows Then
        'While dr2.Read
        'comboSource.Add(dr2.Item(0), dr2.Item(1))
        'End While
        'dr2.Close()
        'End If
        ''TxtMajor.DataSource = New BindingSource(comboSource, Nothing)
        'TxtMajor.DisplayMember = "Value"
        'TxtMajor.ValueMember = "Key"
    End Sub
End Class