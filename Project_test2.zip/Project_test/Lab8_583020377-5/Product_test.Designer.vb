﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Product_test
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Dg_Pro = New System.Windows.Forms.DataGridView()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.Txt_p1 = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.Txt_pid = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Txtid_up = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.btn_1 = New System.Windows.Forms.Button()
        Me.Txt_pup = New System.Windows.Forms.TextBox()
        Me.Txt_nup = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.T2 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.T3 = New System.Windows.Forms.TextBox()
        Me.T4 = New System.Windows.Forms.TextBox()
        Me.T5 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.Dg_Pro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Dg_Pro
        '
        Me.Dg_Pro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dg_Pro.Location = New System.Drawing.Point(28, 75)
        Me.Dg_Pro.Name = "Dg_Pro"
        Me.Dg_Pro.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dg_Pro.Size = New System.Drawing.Size(344, 314)
        Me.Dg_Pro.TabIndex = 0
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(65, 42)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(205, 20)
        Me.TextBox1.TabIndex = 1
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(378, 42)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(350, 450)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.BtnSave)
        Me.TabPage1.Controls.Add(Me.Txt_p1)
        Me.TabPage1.Controls.Add(Me.TxtName)
        Me.TabPage1.Controls.Add(Me.Txt_pid)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(342, 424)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "เพิ่มสินค้า"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(142, 282)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(98, 43)
        Me.BtnSave.TabIndex = 44
        Me.BtnSave.Text = "เพิ่ม"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'Txt_p1
        '
        Me.Txt_p1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Txt_p1.Location = New System.Drawing.Point(159, 200)
        Me.Txt_p1.Multiline = True
        Me.Txt_p1.Name = "Txt_p1"
        Me.Txt_p1.Size = New System.Drawing.Size(98, 45)
        Me.Txt_p1.TabIndex = 41
        '
        'TxtName
        '
        Me.TxtName.Location = New System.Drawing.Point(126, 150)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(165, 20)
        Me.TxtName.TabIndex = 39
        '
        'Txt_pid
        '
        Me.Txt_pid.Location = New System.Drawing.Point(126, 118)
        Me.Txt_pid.Name = "Txt_pid"
        Me.Txt_pid.Size = New System.Drawing.Size(165, 20)
        Me.Txt_pid.TabIndex = 38
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(86, 221)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "ราคาขาย : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(63, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "ชื่อสินค้า : "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(57, 125)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 13)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "รหัสสินค้า : "
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Txtid_up)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.TxtSearch)
        Me.TabPage2.Controls.Add(Me.btn_1)
        Me.TabPage2.Controls.Add(Me.Txt_pup)
        Me.TabPage2.Controls.Add(Me.Txt_nup)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(342, 424)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "แก้ไขสินค้า"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Txtid_up
        '
        Me.Txtid_up.Location = New System.Drawing.Point(104, 137)
        Me.Txtid_up.Name = "Txtid_up"
        Me.Txtid_up.ReadOnly = True
        Me.Txtid_up.Size = New System.Drawing.Size(165, 20)
        Me.Txtid_up.TabIndex = 117
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(258, 63)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(79, 34)
        Me.Button2.TabIndex = 115
        Me.Button2.Text = "Search"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(104, 65)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(148, 20)
        Me.TxtSearch.TabIndex = 114
        '
        'btn_1
        '
        Me.btn_1.Location = New System.Drawing.Point(124, 354)
        Me.btn_1.Name = "btn_1"
        Me.btn_1.Size = New System.Drawing.Size(98, 47)
        Me.btn_1.TabIndex = 48
        Me.btn_1.Text = "แก้ไข"
        Me.btn_1.UseVisualStyleBackColor = True
        '
        'Txt_pup
        '
        Me.Txt_pup.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Txt_pup.Location = New System.Drawing.Point(137, 219)
        Me.Txt_pup.Multiline = True
        Me.Txt_pup.Name = "Txt_pup"
        Me.Txt_pup.Size = New System.Drawing.Size(98, 45)
        Me.Txt_pup.TabIndex = 47
        '
        'Txt_nup
        '
        Me.Txt_nup.Location = New System.Drawing.Point(104, 169)
        Me.Txt_nup.Name = "Txt_nup"
        Me.Txt_nup.Size = New System.Drawing.Size(165, 20)
        Me.Txt_nup.TabIndex = 46
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(64, 240)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "ราคาขาย : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 172)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "ชื่อสินค้า : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(35, 144)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "รหัสสินค้า : "
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.T2)
        Me.TabPage3.Controls.Add(Me.Button3)
        Me.TabPage3.Controls.Add(Me.T3)
        Me.TabPage3.Controls.Add(Me.T4)
        Me.TabPage3.Controls.Add(Me.T5)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.Label7)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Controls.Add(Me.Button4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(342, 424)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "ลบข้อมูล"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'T2
        '
        Me.T2.Location = New System.Drawing.Point(100, 104)
        Me.T2.Name = "T2"
        Me.T2.ReadOnly = True
        Me.T2.Size = New System.Drawing.Size(165, 20)
        Me.T2.TabIndex = 126
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(254, 30)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(79, 34)
        Me.Button3.TabIndex = 125
        Me.Button3.Text = "Search"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'T3
        '
        Me.T3.Location = New System.Drawing.Point(100, 32)
        Me.T3.Name = "T3"
        Me.T3.Size = New System.Drawing.Size(148, 20)
        Me.T3.TabIndex = 124
        '
        'T4
        '
        Me.T4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.T4.Location = New System.Drawing.Point(133, 186)
        Me.T4.Multiline = True
        Me.T4.Name = "T4"
        Me.T4.Size = New System.Drawing.Size(98, 45)
        Me.T4.TabIndex = 123
        '
        'T5
        '
        Me.T5.Location = New System.Drawing.Point(100, 136)
        Me.T5.Name = "T5"
        Me.T5.Size = New System.Drawing.Size(165, 20)
        Me.T5.TabIndex = 122
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(60, 207)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 121
        Me.Label5.Text = "ราคาขาย : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(37, 139)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 120
        Me.Label7.Text = "ชื่อสินค้า : "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(31, 111)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 119
        Me.Label8.Text = "รหัสสินค้า : "
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(133, 273)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(79, 34)
        Me.Button4.TabIndex = 118
        Me.Button4.Text = "ลบข้อมูล"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(285, 40)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "ค้นหา"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Product_test
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 599)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Dg_Pro)
        Me.Name = "Product_test"
        Me.Text = "จัดการสินค้า"
        CType(Me.Dg_Pro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Dg_Pro As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents Txt_pid As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_p1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btn_1 As System.Windows.Forms.Button
    Friend WithEvents Txt_pup As System.Windows.Forms.TextBox
    Friend WithEvents Txt_nup As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TxtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Txtid_up As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents T2 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents T3 As System.Windows.Forms.TextBox
    Friend WithEvents T4 As System.Windows.Forms.TextBox
    Friend WithEvents T5 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
