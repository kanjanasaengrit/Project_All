﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Form_Product
    Dim strConn As String = "Data Source = 10.199.66.228; Initial Catalog = std5830203775;Uid = std5830203775; Pwd = std5830203775;"
    Dim objConn As New SqlConnection(strConn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Friend cmd As New SqlCommand
    Friend Str As String
    Dim strdel As String
    Public strcell As String
    Public Sub show_data()
        Dim Strquery As String
        Strquery = "Select Product.product_id,Product.product_name,Pro_type.p_name,Product.product_amount,Product.status,Product.product_Exp,Product.price_1,Product.price_2 From Product INNER JOIN Pro_type on (Product.p_id = Pro_type.p_id);"
        da = New SqlDataAdapter(Strquery, objConn)
        ds = New DataSet
        da.Fill(ds, "pro_TB")
        DataGridView1.DataMember = "pro_TB"
        DataGridView1.DataSource = ds

    End Sub
    Private Sub Form_Prouct_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If objConn.State = ConnectionState.Closed Then
            objConn.Open()
            'MessageBox.Show("Sql Connent")
        End If
        txtName.Text = ""
        txtStdID.Text = ""
        show_data()
        DataGridView1.Columns(0).HeaderText = "รหัสสินค้า"
        DataGridView1.Columns(1).HeaderText = "ชื่อสินค้า"
        DataGridView1.Columns(2).HeaderText = "ประเภทสินค้า"
        DataGridView1.Columns(3).HeaderText = "จำนวนสินค้า"
        DataGridView1.Columns(4).HeaderText = "แจ้งเตือน"
        DataGridView1.Columns(5).HeaderText = "วันหมดอายุ"
        DataGridView1.Columns(6).HeaderText = "ราคาขาย"
        DataGridView1.Columns(7).HeaderText = "ราคาทุน"
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs)
        'FormReport.Show()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        InsertForm.Show()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        EditForm.Show()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim Strq As String
        Strq = "select * from Product INNER JOIN Pro_type on(Product.p_id=Pro_type.p_id)"
        If txtStdID.Text <> "" Then
            Strq = "select * from Product INNER JOIN Pro_type on(Product.p_id=Pro_type.p_id) WHERE product_id like '%" + txtStdID.Text + "%';"
        End If
        If txtName.Text <> "" Then
            Strq = "select * from Product INNER JOIN Pro_type on(Product.p_id=Pro_type.p_id) WHERE product_name like '%" + txtName.Text + "%';"
        End If

        da = New SqlDataAdapter(Strq, objConn)
        ds = New DataSet
        da.Fill(ds, "pro_TB")
        DataGridView1.DataMember = "pro_TB"
        DataGridView1.DataSource = ds

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        strcell = DataGridView1.Rows.Item(e.RowIndex).Cells(0).Value.ToString()
        '    Dim i As Integer = DataGridView1.CurrentRow.Index
        '    Dim amount As Integer = DataGridView1.Item(3, i).Value
        '    num_exit.Maximum = amount
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim str As String
        str = "delete Product where product_id = '" + txtStdID.Text + "';"
        MessageBox.Show("คุณต้องการลบข้อมูล")
        Dim cmd = New SqlClient.SqlCommand(str, objConn)
        cmd.ExecuteNonQuery()
        MessageBox.Show("ลบข้อมูลได้สำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        show_data()
    End Sub

    'Private Sub btn_exit_Click(sender As Object, e As EventArgs)
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim Str As String = "update Product set product_amount=product_amount-" & num_exit.Value & "where product_id='" &
    '    DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value & "'"
    '    cmd = New SqlCommand(Str, objConn)
    '    If cmd.ExecuteNonQuery = 0 Then
    '        MsgBox("ผิดพลาด")
    '    Else
    '        MsgBox("สำเร็จ")
    '    End If
    '    keep_log("Exit")
    'End Sub
    'Friend Sub keep_log(log_work As String)
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim i As Integer = DataGridView1.CurrentRow.Index
    '    Dim product_id As String = DataGridView1.Item(, i).Value
    '    Dim product_amount As Integer
    '    If log_work = "Exit" Then
    '        product_amount = num_exit.Value
    '    Else
    '        product_amount = num_enter.Value
    '    End If

    '    Str = "insert into Log_product(log_product_id, log_amount, log_work) values(" &
    '        "'" & product_id & "','" & product_amount & "','" & log_work & "')"
    '    cmd = New SqlCommand(Str, objConn)
    '    cmd.ExecuteNonQuery()
    'End Sub
    'Friend Sub load_log()
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Dim i As Integer = DataGridView1.CurrentRow.Index
    '    Dim product_id As String = DataGridView1.Item(0, i).Value
    '    Str = "select * from Log_product where log_product_id='" & product_id & "'"
    '    da = New SqlDataAdapter(Str, objConn)
    '    ds = New DataSet
    '    da.Fill(ds, "table")
    '    DataGridView2.DataSource = ds.Tables("table")
    'End Sub

    'Private Sub Button1_Click(sender As Object, e As EventArgs)
    '    If objConn.State = ConnectionState.Closed Then
    '        objConn.Open()
    '        'MessageBox.Show("Sql Connent")
    '    End If
    '    Str = "update product set product_amount=product_amount+" & num_enter.Value & "where product_id='" &
    '        DataGridView1.Item(0, DataGridView1.CurrentRow.Index).Value & "'"
    '    cmd = New SqlCommand(Str, objConn)
    '    If cmd.ExecuteNonQuery = 0 Then
    '        MsgBox("ผิดพลาด")
    '    Else
    '        MsgBox("สำเร็จ")

    '        keep_log("Enter")
    '        'load_product()
    '        'alert_product()
    '        'load_custom_alert()

    '    End If
    'End Sub
End Class
