﻿Public Class SaleD

    Private Sub SaleD_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'PrintPreviewDialog1.Document = PrintDocument1
        'PrintPreviewDialog1.ShowDialog()

    End Sub

    Private Sub B2_Click(sender As Object, e As EventArgs) Handles B2.Click
        Me.Close()
    End Sub

    'Private Sub T2_KeyDown(sender As Object, e As KeyEventArgs)
    '    If e.KeyData = Keys.Enter Then
    '        If Not IsNumeric(T2.Text) Then
    '            MessageBox.Show("กรุณากรอกข้อมูลเป็นตัวเลขเท่านั้น")
    '            T2.Text = ""
    '            T2.Select()
    '            Return
    '        End If
    '        If Val(T2.Text) < Val(Tb5.Text) Then
    '            MessageBox.Show("จำนวนเงินที่รับมาไม่พอ")
    '            T2.Text = ""
    '            T2.Select()
    '            Return
    '        End If


    '        Dim tot As Integer = Tb5.Text
    '        Dim rec As Integer = T2.Text
    '        Dim rtot As Integer = rec - tot
    '        T3.Text = rtot

    '    End If
    'End Sub

    Private Sub B1_Click(sender As Object, e As EventArgs)
        '    sql = "insert into sale(sale_id,sale.pro_id,sale_to,dcount) values"
        '    Dim i As Integer = salef.Listp.Items.Count - 1
        '    For j As Integer = 0 To i
        '        Dim pro_id As String = salef.Listp.Items(j).SubItems(1).Text
        '        Dim pro_am As Integer = salef.Listp.Items(j).SubItems(1).Text

        '    Next
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim col(6) As Integer
        col(0) = 35
        col(1) = 90
        col(2) = 180
        col(3) = 300
        col(4) = 390
        col(5) = 470
        Dim fnt As New Font("Cordia New", 16)
        Dim fnt1 As New Font("Cordia New", 30,FontStyle.Bold)
        Dim line As Integer = 100

        e.Graphics.DrawString("ร้านบูตัสเอ็กเพลส", fnt1, Brushes.Black, col(0), 20)
        e.Graphics.DrawLine(Pens.RosyBrown, col(0), 80, 650, 80)

        e.Graphics.DrawString("ลำดับ", fnt, Brushes.Black, col(0), line)
        e.Graphics.DrawString("รหัสสินค้า", fnt, Brushes.Black, col(1), line)
        e.Graphics.DrawString("รายการสินค้า", fnt, Brushes.Black, col(2), line)
        e.Graphics.DrawString("จำนวน", fnt, Brushes.Black, col(3), line)
        e.Graphics.DrawString("ราคา", fnt, Brushes.Black, col(4), line)
        e.Graphics.DrawString("ราคารวม", fnt, Brushes.Black, col(5), line)

        For i As Integer = 0 To salef.Listp.Items.Count - 1
            line += 30
            Dim print(6) As String
            With salef.Listp
                print(0) = .Items(i).SubItems(0).Text
                print(1) = .Items(i).SubItems(1).Text
                print(2) = .Items(i).SubItems(2).Text
                print(3) = .Items(i).SubItems(3).Text
                print(4) = .Items(i).SubItems(4).Text
                print(5) = .Items(i).SubItems(5).Text

            End With
            e.Graphics.DrawString(print(0), fnt, Brushes.Black, col(0), line)
            e.Graphics.DrawString(print(1), fnt, Brushes.Black, col(1), line)
            e.Graphics.DrawString(print(2), fnt, Brushes.Black, col(2), line)
            e.Graphics.DrawString(print(3), fnt, Brushes.Black, col(3), line)
            e.Graphics.DrawString(print(4), fnt, Brushes.Black, col(4), line)
            e.Graphics.DrawString(print(5), fnt, Brushes.Black, col(5), line)

        Next
        line += 80
        e.Graphics.DrawString("ราคารวมทั้งหมด  " & salef.Tb5.Text & "  บาท", fnt, Brushes.Black, col(1), line)
        line += 40
        e.Graphics.DrawString("จำนวนเงินที่รับมา  " & T2.Text & "  บาท", fnt, Brushes.Black, col(1), line)
        line += 40
        e.Graphics.DrawString("เงินทอน  " & T3.Text & "  บาท", fnt, Brushes.Black, col(1), line)
        line += 40
        e.Graphics.DrawString("ขอบคุณที่ใช้บริการค่ะ><", fnt, Brushes.Black, col(1), line)



    End Sub

    Private Sub B1_Click_1(sender As Object, e As EventArgs) Handles B1.Click
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub

    'Private Sub T2_KeyDown_1(sender As Object, e As KeyEventArgs) Handles T2.KeyDown

    'End Sub

    Private Sub T2_KeyDown(sender As Object, e As KeyEventArgs) Handles T2.KeyDown
        If e.KeyData = Keys.Enter Then
            If Not IsNumeric(T2.Text) Then
                MessageBox.Show("กรุณากรอกข้อมูลเป็นตัวเลขเท่านั้น")
                T2.Text = ""
                T2.Select()
                Return
            End If
            If Val(T2.Text) < Val(Tb5.Text) Then
                MessageBox.Show("จำนวนเงินที่รับมาไม่พอ")
                T2.Text = ""
                T2.Select()
                Return
            End If


            Dim tot As Integer = Tb5.Text
            Dim rec As Integer = T2.Text
            Dim rtot As Integer = rec - tot
            T3.Text = rtot

        End If
    End Sub
End Class