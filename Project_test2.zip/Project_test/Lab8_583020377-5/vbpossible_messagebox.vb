﻿Module vbpossible_messagebox
    'สำหรับช่วยให้ MessageBox ใช้งานได้ง่าย และรวดเร็วขึ้น
#Region "code ที่ใช้เกี่ยวกับ MessageBox"

    ''' <summary>
    ''' ใช้สำหรับการถามยืนยัน
    ''' </summary>
    ''' <param name="your_text">ข้อความถามยืนยันที่จะปรากฏบน MsgBox</param>
    ''' <param name="your_title">หัวข้อของ MsgBox หากไม่กำหนดจะมีค่า Default เป็น "Confirm ?"</param>
    ''' <returns>DialogResult VbYes/vbNo</returns>
    ''' <remarks></remarks>
    Friend Function confirm(your_text As String, Optional your_title As String = "Confirm ?") As DialogResult
        Return MsgBox(your_text, vbQuestion + vbYesNo, your_title)
    End Function

    ''' <summary>
    ''' ใช้แสดงข้อความผิดพลาด
    ''' </summary>
    ''' <param name="your_error_message">ข้อความผิดพลาดที่ต้องการแสดง</param>
    ''' <param name="your_error_title">หัวข้อความผิดพลาด หากไม่กำหนดจะมีค่า Default เป็น "Error"</param>
    ''' <remarks></remarks>
    Friend Sub error_message(your_error_message As String, Optional your_error_title As String = "Error")
        MsgBox(your_error_message, vbCritical + vbOKOnly, your_error_title)
    End Sub

    ''' <summary>
    ''' ใช้แสดงข้อความสำเร็จ
    ''' </summary>
    ''' <param name="your_ok_message">ข้อความสำเร็จที่ต้องการแสดง</param>
    ''' <param name="your_ok_title">หัวข้อสำเร็จ หากไม่กำหนดจะมีค่า Default เป็น "Success"</param>
    ''' <remarks></remarks>
    Friend Sub ok_message(your_ok_message As String, Optional your_ok_title As String = "Success")
        MsgBox(your_ok_message, vbInformation + vbOKOnly, your_ok_title)
    End Sub
    ''' <summary>
    ''' ใช้แสดงข้อความแจ้งเตือนให้ระวัง
    ''' </summary>
    ''' <param name="your_warning_message">ข้อความแจ้งเตือนให้ระวัง</param>
    ''' <param name="your_warning_title">หัวข้อแจ้งเตือนให้ระวัง หากไม่กำหนดจะมีค่า Default เป็น "Warning"</param>
    ''' <remarks></remarks>
    Friend Sub warning_message(your_warning_message As String, Optional your_warning_title As String = "Warning")
        MsgBox(your_warning_message, vbExclamation + vbOKOnly, your_warning_title)
    End Sub

#End Region
End Module
