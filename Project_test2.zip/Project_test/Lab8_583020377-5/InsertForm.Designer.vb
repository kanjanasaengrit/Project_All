﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InsertForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtlastname = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.TxtMajor = New System.Windows.Forms.ComboBox()
        Me.TxtAddress = New System.Windows.Forms.TextBox()
        Me.TxtTel = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtldStudent = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Tb_1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Txtlastname
        '
        Me.Txtlastname.Location = New System.Drawing.Point(110, 108)
        Me.Txtlastname.Name = "Txtlastname"
        Me.Txtlastname.Size = New System.Drawing.Size(165, 20)
        Me.Txtlastname.TabIndex = 29
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(27, 111)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "จำนวนสินค้า : "
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(133, 330)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(98, 43)
        Me.BtnSave.TabIndex = 27
        Me.BtnSave.Text = "เพิ่ม"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'TxtMajor
        '
        Me.TxtMajor.FormattingEnabled = True
        Me.TxtMajor.Location = New System.Drawing.Point(110, 282)
        Me.TxtMajor.Name = "TxtMajor"
        Me.TxtMajor.Size = New System.Drawing.Size(165, 21)
        Me.TxtMajor.TabIndex = 26
        '
        'TxtAddress
        '
        Me.TxtAddress.Location = New System.Drawing.Point(110, 147)
        Me.TxtAddress.Name = "TxtAddress"
        Me.TxtAddress.Size = New System.Drawing.Size(165, 20)
        Me.TxtAddress.TabIndex = 25
        '
        'TxtTel
        '
        Me.TxtTel.Location = New System.Drawing.Point(110, 213)
        Me.TxtTel.Name = "TxtTel"
        Me.TxtTel.Size = New System.Drawing.Size(165, 20)
        Me.TxtTel.TabIndex = 24
        '
        'TxtEmail
        '
        Me.TxtEmail.Location = New System.Drawing.Point(110, 182)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(165, 20)
        Me.TxtEmail.TabIndex = 23
        '
        'TxtName
        '
        Me.TxtName.Location = New System.Drawing.Point(110, 76)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(165, 20)
        Me.TxtName.TabIndex = 22
        '
        'TxtldStudent
        '
        Me.TxtldStudent.Location = New System.Drawing.Point(110, 44)
        Me.TxtldStudent.Name = "TxtldStudent"
        Me.TxtldStudent.Size = New System.Drawing.Size(165, 20)
        Me.TxtldStudent.TabIndex = 21
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(45, 213)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "ราคาขาย : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 13)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "วันหมดอายุ : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(41, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "แจ้งเตือน : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 282)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "ประเภทสินค้า : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "ชื่อสินค้า : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "รหัสสินค้า : "
        '
        'Tb_1
        '
        Me.Tb_1.Location = New System.Drawing.Point(110, 246)
        Me.Tb_1.Name = "Tb_1"
        Me.Tb_1.Size = New System.Drawing.Size(165, 20)
        Me.Tb_1.TabIndex = 31
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(48, 246)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "ราคาทุน : "
        '
        'InsertForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(331, 395)
        Me.Controls.Add(Me.Tb_1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Txtlastname)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.TxtMajor)
        Me.Controls.Add(Me.TxtAddress)
        Me.Controls.Add(Me.TxtTel)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtName)
        Me.Controls.Add(Me.TxtldStudent)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "InsertForm"
        Me.Text = "เพิ่มข้อมูลสินค้า"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Txtlastname As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents TxtMajor As System.Windows.Forms.ComboBox
    Friend WithEvents TxtAddress As System.Windows.Forms.TextBox
    Friend WithEvents TxtTel As System.Windows.Forms.TextBox
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents TxtldStudent As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Tb_1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label

End Class
