﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class salef
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_d2 = New System.Windows.Forms.Button()
        Me.Btn_d1 = New System.Windows.Forms.Button()
        Me.Btn_1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Tb5 = New System.Windows.Forms.TextBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Tid = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btn_5 = New System.Windows.Forms.Button()
        Me.Tam = New System.Windows.Forms.TextBox()
        Me.Listp = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lbid = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lb_date = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_d2
        '
        Me.Btn_d2.Location = New System.Drawing.Point(36, 528)
        Me.Btn_d2.Name = "Btn_d2"
        Me.Btn_d2.Size = New System.Drawing.Size(85, 34)
        Me.Btn_d2.TabIndex = 2
        Me.Btn_d2.Text = "ลบรายการที่เลือก"
        Me.Btn_d2.UseVisualStyleBackColor = True
        '
        'Btn_d1
        '
        Me.Btn_d1.Location = New System.Drawing.Point(138, 528)
        Me.Btn_d1.Name = "Btn_d1"
        Me.Btn_d1.Size = New System.Drawing.Size(74, 34)
        Me.Btn_d1.TabIndex = 3
        Me.Btn_d1.Text = "ลบทั้งหมด"
        Me.Btn_d1.UseVisualStyleBackColor = True
        '
        'Btn_1
        '
        Me.Btn_1.Location = New System.Drawing.Point(398, 528)
        Me.Btn_1.Name = "Btn_1"
        Me.Btn_1.Size = New System.Drawing.Size(80, 34)
        Me.Btn_1.TabIndex = 4
        Me.Btn_1.Text = "คิดเงิน"
        Me.Btn_1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Tb5)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(540, 78)
        Me.Panel3.TabIndex = 11
        '
        'Tb5
        '
        Me.Tb5.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Tb5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Tb5.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Tb5.ForeColor = System.Drawing.Color.Lime
        Me.Tb5.Location = New System.Drawing.Point(0, 0)
        Me.Tb5.Name = "Tb5"
        Me.Tb5.Size = New System.Drawing.Size(540, 80)
        Me.Tb5.TabIndex = 0
        Me.Tb5.Text = "0"
        Me.Tb5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel5
        '
        Me.Panel5.Location = New System.Drawing.Point(6, 12)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(456, 67)
        Me.Panel5.TabIndex = 1
        '
        'Tid
        '
        Me.Tid.Location = New System.Drawing.Point(73, 113)
        Me.Tid.Name = "Tid"
        Me.Tid.Size = New System.Drawing.Size(100, 20)
        Me.Tid.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "รหัสสินค้า"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(206, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "จำนวน"
        '
        'btn_5
        '
        Me.btn_5.Location = New System.Drawing.Point(380, 110)
        Me.btn_5.Name = "btn_5"
        Me.btn_5.Size = New System.Drawing.Size(98, 41)
        Me.btn_5.TabIndex = 18
        Me.btn_5.Text = "เพิ่ม"
        Me.btn_5.UseVisualStyleBackColor = True
        '
        'Tam
        '
        Me.Tam.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Tam.Location = New System.Drawing.Point(265, 112)
        Me.Tam.Name = "Tam"
        Me.Tam.Size = New System.Drawing.Size(58, 22)
        Me.Tam.TabIndex = 21
        '
        'Listp
        '
        Me.Listp.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6})
        Me.Listp.FullRowSelect = True
        Me.Listp.GridLines = True
        Me.Listp.Location = New System.Drawing.Point(48, 230)
        Me.Listp.Name = "Listp"
        Me.Listp.Size = New System.Drawing.Size(460, 246)
        Me.Listp.TabIndex = 22
        Me.Listp.UseCompatibleStateImageBehavior = False
        Me.Listp.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "*"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "รหัสสินค้า"
        Me.ColumnHeader2.Width = 78
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "รายการ"
        Me.ColumnHeader3.Width = 139
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "จำนวน"
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "ราคา"
        Me.ColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "ราคารวม"
        Me.ColumnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 165)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "รหัสการขาย :"
        '
        'Lbid
        '
        Me.Lbid.AutoSize = True
        Me.Lbid.Location = New System.Drawing.Point(90, 165)
        Me.Lbid.Name = "Lbid"
        Me.Lbid.Size = New System.Drawing.Size(22, 13)
        Me.Lbid.TabIndex = 24
        Me.Lbid.Text = "....."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(249, 165)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 13)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "วัน/เดือน/ปี ขาย :"
        '
        'Lb_date
        '
        Me.Lb_date.AutoSize = True
        Me.Lb_date.Location = New System.Drawing.Point(346, 165)
        Me.Lb_date.Name = "Lb_date"
        Me.Lb_date.Size = New System.Drawing.Size(22, 13)
        Me.Lb_date.TabIndex = 26
        Me.Lb_date.Text = "....."
        '
        'salef
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(540, 577)
        Me.Controls.Add(Me.Lb_date)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Lbid)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Listp)
        Me.Controls.Add(Me.Tam)
        Me.Controls.Add(Me.btn_5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Tid)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Btn_1)
        Me.Controls.Add(Me.Btn_d1)
        Me.Controls.Add(Me.Btn_d2)
        Me.Name = "salef"
        Me.Text = "โปรแกรมขายสินค้า"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Btn_d2 As System.Windows.Forms.Button
    Friend WithEvents Btn_d1 As System.Windows.Forms.Button
    Friend WithEvents Btn_1 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Tid As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Tb5 As System.Windows.Forms.TextBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btn_5 As System.Windows.Forms.Button
    Friend WithEvents Tam As System.Windows.Forms.TextBox
    Friend WithEvents Listp As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbid As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Lb_date As System.Windows.Forms.Label
End Class
