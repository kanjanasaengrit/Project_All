﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class index
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.show_data()
    End Sub

    Sub show_data()
        Dim constr As New SqlConnection(ConfigurationManager.ConnectionStrings("dbconnection").ConnectionString)
        If constr.State = ConnectionState.Closed Then
            constr.Open()
        End If
        Dim cmd As New SqlCommand("SELECT student.Std_id, student.std_name, student.std_lastname,department.dept_name,Subject.subj_name, Enroll.year FROM Enroll INNER JOIN student on (student.std_id=enroll.std_id) INNER JOIN department on(student.dept_id=department.dept_id) INNER JOIN subject on (subject.subj_id=enroll.subj_id) ORDER BY student.std_id", constr)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                Lbno.Text += (i + 1).ToString() + "<br>"
                LbId.Text += dt.Rows(i)("std_id").ToString() + "<br/>"
                LbFname.Text += dt.Rows(i)("std_name").ToString() + "<br/>"
                LbLname.Text += dt.Rows(i)("std_lastname").ToString() + "<br/>"
                LbDeptname.Text += dt.Rows(i)("dept_name").ToString() + "<br/>"
                LbSubjname.Text += dt.Rows(i)("subj_name").ToString() + "<br/>"
                LbDate.Text += dt.Rows(i)("year").ToString() + "<br/>"
            Next
        End If
    End Sub

End Class