﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class InsertEnroll
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("dbconnection").ConnectionString
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim query As String = "SELECT * FROM Subject"
            Using con As New SqlConnection(constr)
                Using cmd As New SqlCommand(query)
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    con.Open()
                    Using sdr As SqlDataReader = cmd.ExecuteReader()
                        While sdr.Read()
                            Dim item As New ListItem()
                            item.Text = sdr("subj_name").ToString()
                            item.Value = sdr("subj_id").ToString()
                            txtsubject.Items.Add(item)
                        End While
                    End Using
                    con.Close()
                End Using
            End Using
            txtsubject.Items.Insert(0, New ListItem("--Select--", "0"))
        End If
    End Sub


    Protected Sub btnSaveEnroll_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim UserId As Integer = 0
        Dim message As String = String.Empty
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("Insert_Enroll")
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@subj_id", txtsubject.SelectedValue.ToString)
                    cmd.Parameters.AddWithValue("@std_id", txtStdId.Text.Trim())
                    cmd.Parameters.AddWithValue("@term", txtTerm.Text.Trim())
                    cmd.Parameters.AddWithValue("@year", txtYear.Text.Trim())
                    cmd.Connection = con
                    con.Open()
                    UserId = Convert.ToInt32(cmd.ExecuteNonQuery())
                    con.Close()
                End Using
            End Using

            Select Case UserId
                Case -1
                    message = "Insert Successful"
                    Exit Select
                Case Else
                    message = "Student Id already exists." + UserId.ToString
                    Exit Select
            End Select
            ClientScript.RegisterStartupScript([GetType](), "alert", (Convert.ToString("alert('") & message) + "');", True)
        End Using
    End Sub
End Class