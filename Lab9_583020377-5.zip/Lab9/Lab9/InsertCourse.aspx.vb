﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class InsertCourse
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("dbconnection").ConnectionString
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim UserId As Integer = 0
        Dim message As String = String.Empty
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("Insert_Course")
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@subj_id", txtSubjId.Text.Trim())
                    cmd.Parameters.AddWithValue("@subj_name", txtSubjName.Text.Trim())
                    cmd.Parameters.AddWithValue("@unit", txtunit.Text.Trim())
                    cmd.Connection = con
                    con.Open()
                    UserId = Convert.ToInt32(cmd.ExecuteNonQuery())
                    con.Close()
                End Using
            End Using
            Select Case UserId
                Case -1
                    message = "Insert Successful"
                    Exit Select
                Case Else
                    message = "Student Id already exists." + UserId.ToString
                    Exit Select
            End Select
            ClientScript.RegisterStartupScript([GetType](), "alert", (Convert.ToString("alert('") & message) + "');", True)
        End Using
    End Sub

End Class