﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class Insertdata
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("dbconnection").ConnectionString
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim query As String = "SELECT * FROM Department"
            Using con As New SqlConnection(constr)
                Using cmd As New SqlCommand(query)
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    con.Open()
                    Using sdr As SqlDataReader = cmd.ExecuteReader()
                        While sdr.Read()
                            Dim item As New ListItem()
                            item.Text = sdr("dept_name").ToString
                            item.Value = sdr("dept_id").ToString
                            txtdeptid.Items.Add(item)
                        End While
                    End Using
                    con.Close()
                End Using
            End Using
            txtdeptid.Items.Insert(0, New ListItem("--Select--", "0"))
        End If
    End Sub

    Protected Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim UserId As Integer = 0
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("Insert_User")
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@std_id", txtIdStd.Text.Trim())
                    cmd.Parameters.AddWithValue("@std_name", txtFname.Text.Trim())
                    cmd.Parameters.AddWithValue("@std_lastname", txtLname.Text.Trim())
                    cmd.Parameters.AddWithValue("@dept_id", txtdeptid.Text.Trim())
                    cmd.Parameters.AddWithValue("@std_address", txtAdd.Text.Trim())
                    cmd.Parameters.AddWithValue("@std_mail", txtemail.Text.Trim())
                    cmd.Parameters.AddWithValue("@std_tel", txttel.Text.Trim())
                    cmd.Connection = con
                    con.Open()
                    UserId = Convert.ToInt32(cmd.ExecuteNonQuery())
                    con.Close()

                End Using
            End Using
            Dim message As String = String.Empty
            Select Case UserId
                Case -1
                    message = "Insert Successful"
                    Exit Select
                Case Else
                    message = "Student Id already exists." + UserId.ToString
                    Exit Select
            End Select
            ClientScript.RegisterStartupScript([GetType](), "alert", (Convert.ToString("alert('") & message) + "');", True)
        End Using
    End Sub
End Class